﻿using System;

// Token: 0x0200011E RID: 286
internal class Banshee_ProcessedByFody
{
	// Token: 0x04000301 RID: 769
	internal const string FodyVersion = "6.8.0.0";

	// Token: 0x04000302 RID: 770
	internal const string Costura = "5.7.0";
}
