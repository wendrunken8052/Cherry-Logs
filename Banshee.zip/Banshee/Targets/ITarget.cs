﻿using System;
using Banshee.Helper.Data;

namespace Banshee.Targets
{
	// Token: 0x02000027 RID: 39
	public interface ITarget
	{
		// Token: 0x06000052 RID: 82
		void Collect(InMemoryZip zip, Counter counter);
	}
}
