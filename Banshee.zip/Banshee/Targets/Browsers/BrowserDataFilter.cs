﻿using System;
using System.Linq;

namespace Banshee.Targets.Browsers
{
	// Token: 0x0200006B RID: 107
	internal static class BrowserDataFilter
	{
		// Token: 0x0600013D RID: 317 RVA: 0x00009810 File Offset: 0x00009810
		public static bool ShouldExclude(string hostOrUrl)
		{
			if (string.IsNullOrWhiteSpace(hostOrUrl))
			{
				return false;
			}
			string text = hostOrUrl.ToLowerInvariant();
			return BrowserDataFilter.SensitiveDomains.Any((string domain) => text.Contains(domain));
		}

		// Token: 0x040000E8 RID: 232
		private static readonly string[] SensitiveDomains = new string[]
		{
			"avito",
			"ozon",
			"wildberries",
			"gosuslugi",
			"sberbank",
			"tinkoff",
			"tbank"
		};
	}
}
