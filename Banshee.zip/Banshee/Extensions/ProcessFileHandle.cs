﻿using System;

namespace Banshee.Extensions
{
	// Token: 0x02000020 RID: 32
	public readonly struct ProcessFileHandle
	{
		// Token: 0x0600003C RID: 60 RVA: 0x00002CB4 File Offset: 0x00002CB4
		public ProcessFileHandle(string processName, int processId, string fileName, int fileHandleId)
		{
			this.ProcessName = processName;
			this.ProcessID = processId;
			this.FileName = fileName;
			this.FileHandleID = fileHandleId;
		}

		// Token: 0x17000006 RID: 6
		// (get) Token: 0x0600003D RID: 61 RVA: 0x00002CD3 File Offset: 0x00002CD3
		public string ProcessName { get; }

		// Token: 0x17000007 RID: 7
		// (get) Token: 0x0600003E RID: 62 RVA: 0x00002CDB File Offset: 0x00002CDB
		public int ProcessID { get; }

		// Token: 0x17000008 RID: 8
		// (get) Token: 0x0600003F RID: 63 RVA: 0x00002CE3 File Offset: 0x00002CE3
		public string FileName { get; }

		// Token: 0x17000009 RID: 9
		// (get) Token: 0x06000040 RID: 64 RVA: 0x00002CEB File Offset: 0x00002CEB
		public int FileHandleID { get; }
	}
}
