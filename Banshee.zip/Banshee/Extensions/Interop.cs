﻿using System;
using System.Runtime.InteropServices;
using System.Text;

namespace Banshee.Extensions
{
	// Token: 0x0200000A RID: 10
	internal static class Interop
	{
		// Token: 0x0200000B RID: 11
		internal enum NtStatus : uint
		{
			// Token: 0x0400000A RID: 10
			STATUS_SUCCESS,
			// Token: 0x0400000B RID: 11
			STATUS_INFO_LENGTH_MISMATCH = 3221225476U
		}

		// Token: 0x0200000C RID: 12
		internal enum SYSTEM_INFORMATION_CLASS
		{
			// Token: 0x0400000D RID: 13
			SystemHandleInformation = 16
		}

		// Token: 0x0200000D RID: 13
		internal struct SystemHandleInformation
		{
			// Token: 0x0400000E RID: 14
			public int ProcessId;

			// Token: 0x0400000F RID: 15
			public byte ObjectTypeNumber;

			// Token: 0x04000010 RID: 16
			public byte Flags;

			// Token: 0x04000011 RID: 17
			public ushort HandleValue;

			// Token: 0x04000012 RID: 18
			public IntPtr ObjectPointer;

			// Token: 0x04000013 RID: 19
			public uint GrantedAccess;
		}

		// Token: 0x0200000E RID: 14
		internal struct UnicodeString
		{
			// Token: 0x06000018 RID: 24 RVA: 0x00002413 File Offset: 0x00002413
			public override string ToString()
			{
				string result;
				if (!(this.Buffer == IntPtr.Zero))
				{
					if ((result = Marshal.PtrToStringUni(this.Buffer, (int)(this.Length / 2))) == null)
					{
						return string.Empty;
					}
				}
				else
				{
					result = string.Empty;
				}
				return result;
			}

			// Token: 0x04000014 RID: 20
			public ushort Length;

			// Token: 0x04000015 RID: 21
			public ushort MaximumLength;

			// Token: 0x04000016 RID: 22
			public IntPtr Buffer;
		}

		// Token: 0x0200000F RID: 15
		internal struct ObjectNameInformation
		{
			// Token: 0x04000017 RID: 23
			public Interop.UnicodeString Name;
		}

		// Token: 0x02000010 RID: 16
		[Flags]
		internal enum ProcessAccessFlags : uint
		{
			// Token: 0x04000019 RID: 25
			Terminate = 1U,
			// Token: 0x0400001A RID: 26
			CreateThread = 2U,
			// Token: 0x0400001B RID: 27
			VirtualMemoryOperation = 8U,
			// Token: 0x0400001C RID: 28
			VirtualMemoryRead = 16U,
			// Token: 0x0400001D RID: 29
			VirtualMemoryWrite = 32U,
			// Token: 0x0400001E RID: 30
			DuplicateHandle = 64U,
			// Token: 0x0400001F RID: 31
			CreateProcess = 128U,
			// Token: 0x04000020 RID: 32
			SetQuota = 256U,
			// Token: 0x04000021 RID: 33
			SetInformation = 512U,
			// Token: 0x04000022 RID: 34
			QueryInformation = 1024U,
			// Token: 0x04000023 RID: 35
			QueryLimitedInformation = 4096U,
			// Token: 0x04000024 RID: 36
			Synchronize = 1048576U,
			// Token: 0x04000025 RID: 37
			All = 2035711U
		}

		// Token: 0x02000011 RID: 17
		[Flags]
		internal enum DuplicateOptions : uint
		{
			// Token: 0x04000027 RID: 39
			DUPLICATE_CLOSE_SOURCE = 1U,
			// Token: 0x04000028 RID: 40
			DUPLICATE_SAME_ACCESS = 2U
		}

		// Token: 0x02000012 RID: 18
		internal enum FileType : uint
		{
			// Token: 0x0400002A RID: 42
			Unknown,
			// Token: 0x0400002B RID: 43
			Disk,
			// Token: 0x0400002C RID: 44
			Char,
			// Token: 0x0400002D RID: 45
			Pipe,
			// Token: 0x0400002E RID: 46
			Remote = 32768U
		}

		// Token: 0x02000013 RID: 19
		[Flags]
		internal enum FileMapProtection : uint
		{
			// Token: 0x04000030 RID: 48
			PageReadonly = 2U,
			// Token: 0x04000031 RID: 49
			PageReadWrite = 4U,
			// Token: 0x04000032 RID: 50
			PageWriteCopy = 8U,
			// Token: 0x04000033 RID: 51
			PageExecuteRead = 32U,
			// Token: 0x04000034 RID: 52
			PageExecuteReadWrite = 64U
		}

		// Token: 0x02000014 RID: 20
		[Flags]
		internal enum FileMapAccess : uint
		{
			// Token: 0x04000036 RID: 54
			FileMapCopy = 1U,
			// Token: 0x04000037 RID: 55
			FileMapWrite = 2U,
			// Token: 0x04000038 RID: 56
			FileMapRead = 4U,
			// Token: 0x04000039 RID: 57
			FileMapAllAccess = 983071U,
			// Token: 0x0400003A RID: 58
			FileMapExecute = 32U
		}

		// Token: 0x02000015 RID: 21
		internal static class Kernel32
		{
			// Token: 0x06000019 RID: 25
			[DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
			internal static extern int QueryDosDevice(string lpDeviceName, StringBuilder lpTargetPath, int ucchMax);

			// Token: 0x0600001A RID: 26
			[DllImport("kernel32.dll", SetLastError = true)]
			internal static extern IntPtr OpenProcess(Interop.ProcessAccessFlags dwDesiredAccess, bool bInheritHandle, uint dwProcessId);

			// Token: 0x0600001B RID: 27
			[DllImport("kernel32.dll", SetLastError = true)]
			internal static extern bool DuplicateHandle(IntPtr hSourceProcessHandle, IntPtr hSourceHandle, IntPtr hTargetProcessHandle, out IntPtr lpTargetHandle, uint dwDesiredAccess, bool bInheritHandle, Interop.DuplicateOptions dwOptions);

			// Token: 0x0600001C RID: 28
			[DllImport("kernel32.dll", SetLastError = true)]
			internal static extern IntPtr GetCurrentProcess();

			// Token: 0x0600001D RID: 29
			[DllImport("kernel32.dll", SetLastError = true)]
			internal static extern Interop.FileType GetFileType(IntPtr hFile);

			// Token: 0x0600001E RID: 30
			[DllImport("kernel32.dll", SetLastError = true)]
			internal static extern bool CloseHandle(IntPtr hObject);

			// Token: 0x0600001F RID: 31
			[DllImport("kernel32.dll", SetLastError = true)]
			internal static extern bool GetFileSizeEx(IntPtr hFile, out long lpFileSize);

			// Token: 0x06000020 RID: 32
			[DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
			internal static extern IntPtr CreateFileMapping(IntPtr hFile, IntPtr lpFileMappingAttributes, Interop.FileMapProtection flProtect, uint dwMaximumSizeHigh, uint dwMaximumSizeLow, string lpName);

			// Token: 0x06000021 RID: 33
			[DllImport("kernel32.dll", SetLastError = true)]
			internal static extern IntPtr MapViewOfFile(IntPtr hFileMappingObject, Interop.FileMapAccess dwDesiredAccess, uint dwFileOffsetHigh, uint dwFileOffsetLow, uint dwNumberOfBytesToMap);

			// Token: 0x06000022 RID: 34
			[DllImport("kernel32.dll", SetLastError = true)]
			internal static extern bool UnmapViewOfFile(IntPtr lpBaseAddress);
		}

		// Token: 0x02000016 RID: 22
		internal static class Ntdll
		{
			// Token: 0x06000023 RID: 35
			[DllImport("ntdll.dll")]
			internal static extern Interop.NtStatus NtQuerySystemInformation(Interop.SYSTEM_INFORMATION_CLASS systemInformationClass, IntPtr systemInformation, int systemInformationLength, out int returnLength);

			// Token: 0x06000024 RID: 36
			[DllImport("ntdll.dll")]
			internal static extern Interop.NtStatus NtQueryObject(IntPtr handle, Interop.OBJECT_INFORMATION_CLASS objectInformationClass, IntPtr objectInformation, int objectInformationLength, out int returnLength);
		}

		// Token: 0x02000017 RID: 23
		internal enum OBJECT_INFORMATION_CLASS
		{
			// Token: 0x0400003C RID: 60
			ObjectBasicInformation,
			// Token: 0x0400003D RID: 61
			ObjectNameInformation,
			// Token: 0x0400003E RID: 62
			ObjectTypeInformation
		}
	}
}
