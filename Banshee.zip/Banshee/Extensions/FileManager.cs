﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Banshee.Extensions
{
	// Token: 0x02000008 RID: 8
	public static class FileManager
	{
		// Token: 0x06000014 RID: 20 RVA: 0x00002338 File Offset: 0x00002338
		public static List<string> EnumerateFiles(string currentDirectory, string searchPattern, int maxDepth, int currentDepth = 0)
		{
			List<string> list = new List<string>();
			if (currentDepth >= maxDepth)
			{
				return list;
			}
			try
			{
				string[] files = Directory.GetFiles(currentDirectory, searchPattern);
				list.AddRange(files);
				foreach (string currentDirectory2 in Directory.GetDirectories(currentDirectory))
				{
					list.AddRange(FileManager.EnumerateFiles(currentDirectory2, searchPattern, maxDepth, currentDepth + 1));
				}
			}
			catch (UnauthorizedAccessException)
			{
			}
			catch (PathTooLongException)
			{
			}
			catch (DirectoryNotFoundException)
			{
			}
			return list;
		}

		// Token: 0x06000015 RID: 21 RVA: 0x000023C4 File Offset: 0x000023C4
		public static byte[] ReadFile(string filePath)
		{
			return NullableValue.Call<byte[]>(() => File.ReadAllBytes(filePath)) ?? LockHelper.ReadFile(filePath);
		}
	}
}
