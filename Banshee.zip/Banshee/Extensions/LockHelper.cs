﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Management;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using System.Text;

namespace Banshee.Extensions
{
	// Token: 0x02000018 RID: 24
	public class LockHelper
	{
		// Token: 0x06000025 RID: 37
		[DllImport("rstrtmgr.dll", CharSet = CharSet.Unicode)]
		private static extern int RmRegisterResources(uint pSessionHandle, uint nFiles, string[] rgsFilenames, uint nApplications, [In] LockHelper.RM_UNIQUE_PROCESS[] rgApplications, uint nServices, string[] rgsServiceNames);

		// Token: 0x06000026 RID: 38
		[DllImport("rstrtmgr.dll", CharSet = CharSet.Auto)]
		private static extern int RmStartSession(out uint pSessionHandle, int dwSessionFlags, string strSessionKey);

		// Token: 0x06000027 RID: 39
		[DllImport("rstrtmgr.dll")]
		private static extern int RmEndSession(uint pSessionHandle);

		// Token: 0x06000028 RID: 40
		[DllImport("rstrtmgr.dll")]
		private static extern int RmGetList(uint dwSessionHandle, out uint pnProcInfoNeeded, ref uint pnProcInfo, [In] [Out] LockHelper.RM_PROCESS_INFO[] rgAffectedApps, ref uint lpdwRebootReasons);

		// Token: 0x06000029 RID: 41 RVA: 0x0000244C File Offset: 0x0000244C
		public static IEnumerable<Process> GetLockingProcesses(string path)
		{
			string strSessionKey = Guid.NewGuid().ToString();
			List<Process> list = new List<Process>();
			uint num2;
			int num = LockHelper.RmStartSession(out num2, 0, strSessionKey);
			if (num != 0)
			{
				return new List<Process>();
			}
			try
			{
				uint num3 = 0U;
				uint num4 = 0U;
				string[] array = new string[]
				{
					path
				};
				num = LockHelper.RmRegisterResources(num2, (uint)array.Length, array, 0U, null, 0U, null);
				if (num != 0)
				{
					return new List<Process>();
				}
				uint num5;
				num = LockHelper.RmGetList(num2, out num5, ref num3, null, ref num4);
				if (num == 234)
				{
					LockHelper.RM_PROCESS_INFO[] array2 = new LockHelper.RM_PROCESS_INFO[num5];
					num3 = num5;
					if (LockHelper.RmGetList(num2, out num5, ref num3, array2, ref num4) != 0)
					{
						return new List<Process>();
					}
					list = new List<Process>((int)num3);
					int num6 = 0;
					while ((long)num6 < (long)((ulong)num3))
					{
						try
						{
							list.Add(Process.GetProcessById(array2[num6].Process.dwProcessId));
						}
						catch (ArgumentException)
						{
						}
						num6++;
					}
				}
				else if (num != 0)
				{
					return new List<Process>();
				}
			}
			finally
			{
				LockHelper.RmEndSession(num2);
			}
			return list;
		}

		// Token: 0x0600002A RID: 42 RVA: 0x00002570 File Offset: 0x00002570
		public static Process GetOwnerProcess(int childProcessId)
		{
			Process result = null;
			string queryString = string.Format("SELECT * FROM Win32_Process WHERE ProcessId = {0}", childProcessId);
			foreach (ManagementBaseObject managementBaseObject in new ManagementObjectSearcher("root\\CIMV2", queryString).Get())
			{
				uint processId = (uint)((ManagementObject)managementBaseObject)["ParentProcessId"];
				try
				{
					result = Process.GetProcessById((int)processId);
				}
				catch
				{
				}
			}
			return result;
		}

		// Token: 0x0600002B RID: 43 RVA: 0x00002600 File Offset: 0x00002600
		private static Dictionary<string, string> BuildDeviceMap()
		{
			string[] logicalDrives = Environment.GetLogicalDrives();
			Dictionary<string, string> dictionary = new Dictionary<string, string>(logicalDrives.Length);
			StringBuilder stringBuilder = new StringBuilder(260);
			string[] array = logicalDrives;
			for (int i = 0; i < array.Length; i++)
			{
				string text = array[i].Substring(0, 2);
				Interop.Kernel32.QueryDosDevice(text, stringBuilder, 260);
				dictionary.Add(LockHelper.NormalizeDeviceName(stringBuilder.ToString()), text);
			}
			dictionary.Add("\\\\Device\\\\LanmanRedirector\\\\".Substring(0, "\\\\Device\\\\LanmanRedirector\\\\".Length - 1), "\\");
			return dictionary;
		}

		// Token: 0x0600002C RID: 44 RVA: 0x00002688 File Offset: 0x00002688
		private static string NormalizeDeviceName(string deviceName)
		{
			if (string.Compare(deviceName, 0, "\\\\Device\\\\LanmanRedirector\\\\", 0, "\\\\Device\\\\LanmanRedirector\\\\".Length, StringComparison.InvariantCulture) != 0)
			{
				return deviceName;
			}
			string str = deviceName.Substring(deviceName.IndexOf('\\', "\\\\Device\\\\LanmanRedirector\\\\".Length) + 1);
			return "\\\\Device\\\\LanmanRedirector\\\\" + str;
		}

		// Token: 0x0600002D RID: 45 RVA: 0x000026D8 File Offset: 0x000026D8
		private static Dictionary<int, string> ConvertDevicePathsToDosPaths(Dictionary<int, string> devicePaths)
		{
			Dictionary<int, string> dictionary = new Dictionary<int, string>();
			foreach (KeyValuePair<int, string> keyValuePair in devicePaths)
			{
				Dictionary<string, string> dictionary2 = LockHelper.BuildDeviceMap();
				int num = keyValuePair.Value.Length;
				while (num > 0 && (num = keyValuePair.Value.LastIndexOf('\\', num - 1)) != -1)
				{
					string str;
					if (dictionary2.TryGetValue(keyValuePair.Value.Substring(0, num), out str))
					{
						dictionary.Add(keyValuePair.Key, str + keyValuePair.Value.Substring(num));
					}
				}
			}
			return dictionary;
		}

		// Token: 0x0600002E RID: 46 RVA: 0x00002794 File Offset: 0x00002794
		private static Dictionary<int, string> GetHandleNames(int targetPid)
		{
			Dictionary<int, string> dictionary = new Dictionary<int, string>();
			int num = 65536;
			IntPtr intPtr = IntPtr.Zero;
			try
			{
				for (;;)
				{
					intPtr = Marshal.AllocHGlobal(num);
					int val;
					Interop.NtStatus ntStatus = Interop.Ntdll.NtQuerySystemInformation(Interop.SYSTEM_INFORMATION_CLASS.SystemHandleInformation, intPtr, num, out val);
					if (ntStatus != (Interop.NtStatus)3221225476U)
					{
						break;
					}
					num = Math.Max(num, val);
					Marshal.FreeHGlobal(intPtr);
					intPtr = IntPtr.Zero;
				}
				long num2 = intPtr.ToInt64();
				num2 += (long)IntPtr.Size;
				int num3 = Marshal.SizeOf(typeof(Interop.SystemHandleInformation));
				int num4 = (IntPtr.Size == 4) ? Marshal.ReadInt32(intPtr) : ((int)Marshal.ReadInt64(intPtr));
				IntPtr intPtr2 = Interop.Kernel32.OpenProcess(Interop.ProcessAccessFlags.DuplicateHandle, true, (uint)targetPid);
				IntPtr currentProcess = Interop.Kernel32.GetCurrentProcess();
				for (int i = 0; i < num4; i++)
				{
					if (Marshal.ReadInt32((IntPtr)num2) == targetPid)
					{
						Interop.SystemHandleInformation systemHandleInformation = (Interop.SystemHandleInformation)Marshal.PtrToStructure(new IntPtr(num2), typeof(Interop.SystemHandleInformation));
						IntPtr intPtr3;
						bool flag = Interop.Kernel32.DuplicateHandle(intPtr2, new IntPtr((int)systemHandleInformation.HandleValue), currentProcess, out intPtr3, 0U, false, Interop.DuplicateOptions.DUPLICATE_SAME_ACCESS);
						if (Interop.Kernel32.GetFileType(intPtr3) == Interop.FileType.Disk && flag)
						{
							IntPtr intPtr4 = Marshal.AllocHGlobal(512);
							int num5;
							if (Interop.Ntdll.NtQueryObject(intPtr3, Interop.OBJECT_INFORMATION_CLASS.ObjectNameInformation, intPtr4, 512, out num5) == Interop.NtStatus.STATUS_SUCCESS)
							{
								Interop.ObjectNameInformation objectNameInformation = (Interop.ObjectNameInformation)Marshal.PtrToStructure(intPtr4, typeof(Interop.ObjectNameInformation));
								if (!string.IsNullOrEmpty(objectNameInformation.Name.ToString()) && !string.IsNullOrEmpty(objectNameInformation.Name.ToString().Trim()))
								{
									dictionary.Add((int)systemHandleInformation.HandleValue, objectNameInformation.Name.ToString().Trim());
								}
							}
							Marshal.FreeHGlobal(intPtr4);
						}
						Interop.Kernel32.CloseHandle(intPtr3);
					}
					num2 += (long)num3;
				}
				Interop.Kernel32.CloseHandle(intPtr2);
			}
			finally
			{
				if (intPtr != IntPtr.Zero)
				{
					Marshal.FreeHGlobal(intPtr);
				}
			}
			return LockHelper.ConvertDevicePathsToDosPaths(dictionary);
		}

		// Token: 0x0600002F RID: 47 RVA: 0x00002994 File Offset: 0x00002994
		public static ProcessFileHandle FindFileHandle(string targetFile, Process candidateProcesses)
		{
			List<Process> list = new List<Process>();
			List<Process> list2 = list;
			IEnumerable<Process> collection;
			if (candidateProcesses != null)
			{
				IEnumerable<Process> enumerable = new Process[]
				{
					candidateProcesses
				};
				collection = enumerable;
			}
			else
			{
				collection = from p in Process.GetProcesses()
				where p.HandleCount != 0
				select p;
			}
			list2.AddRange(collection);
			Func<KeyValuePair<int, string>, bool> <>9__1;
			foreach (Process process in list)
			{
				IEnumerable<KeyValuePair<int, string>> handleNames = LockHelper.GetHandleNames(process.Id);
				Func<KeyValuePair<int, string>, bool> predicate;
				if ((predicate = <>9__1) == null)
				{
					predicate = (<>9__1 = ((KeyValuePair<int, string> handle) => handle.Value.EndsWith(targetFile, StringComparison.CurrentCultureIgnoreCase)));
				}
				using (IEnumerator<KeyValuePair<int, string>> enumerator2 = handleNames.Where(predicate).GetEnumerator())
				{
					if (enumerator2.MoveNext())
					{
						KeyValuePair<int, string> keyValuePair = enumerator2.Current;
						return new ProcessFileHandle(process.ProcessName, process.Id, keyValuePair.Value, keyValuePair.Key);
					}
				}
			}
			return default(ProcessFileHandle);
		}

		// Token: 0x06000030 RID: 48 RVA: 0x00002AD0 File Offset: 0x00002AD0
		public static byte[] ReadFile(string path)
		{
			Process[] array = LockHelper.GetLockingProcesses(path).ToArray<Process>();
			try
			{
				IEnumerable<Process> source = array;
				Func<Process, ProcessFileHandle> <>9__0;
				Func<Process, ProcessFileHandle> selector;
				if ((selector = <>9__0) == null)
				{
					selector = (<>9__0 = ((Process process) => LockHelper.FindFileHandle(path, process)));
				}
				using (IEnumerator<ProcessFileHandle> enumerator = (from foundHandle in source.Select(selector)
				where foundHandle.ProcessID != 0
				select foundHandle).GetEnumerator())
				{
					if (enumerator.MoveNext())
					{
						return LockHelper.ReadLockedFile(enumerator.Current);
					}
				}
			}
			catch
			{
				return null;
			}
			return null;
		}

		// Token: 0x06000031 RID: 49 RVA: 0x00002B98 File Offset: 0x00002B98
		public static byte[] ReadLockedFile(ProcessFileHandle fileHandle)
		{
			byte[] array = null;
			IntPtr intPtr = Interop.Kernel32.OpenProcess(Interop.ProcessAccessFlags.DuplicateHandle, true, (uint)fileHandle.ProcessID);
			IntPtr currentProcess = Interop.Kernel32.GetCurrentProcess();
			IntPtr intPtr2;
			long num;
			if (Interop.Kernel32.DuplicateHandle(intPtr, new IntPtr(fileHandle.FileHandleID), currentProcess, out intPtr2, 0U, false, Interop.DuplicateOptions.DUPLICATE_SAME_ACCESS) && Interop.Kernel32.GetFileSizeEx(intPtr2, out num))
			{
				int num2 = (num > 2147483647L) ? int.MaxValue : ((int)num);
				if (num2 > 0)
				{
					IntPtr intPtr3 = Interop.Kernel32.MapViewOfFile(Interop.Kernel32.CreateFileMapping(intPtr2, IntPtr.Zero, Interop.FileMapProtection.PageReadonly, 0U, 0U, null), Interop.FileMapAccess.FileMapRead, 0U, 0U, 0U);
					array = new byte[num2];
					Marshal.Copy(intPtr3, array, 0, num2);
					Interop.Kernel32.UnmapViewOfFile(intPtr3);
					Interop.Kernel32.CloseHandle(intPtr2);
				}
			}
			Interop.Kernel32.CloseHandle(intPtr);
			return array;
		}

		// Token: 0x0400003F RID: 63
		private const int CCH_RM_MAX_APP_NAME = 255;

		// Token: 0x04000040 RID: 64
		private const int CCH_RM_MAX_SVC_NAME = 63;

		// Token: 0x02000019 RID: 25
		private struct RM_UNIQUE_PROCESS
		{
			// Token: 0x04000041 RID: 65
			public int dwProcessId;

			// Token: 0x04000042 RID: 66
			public System.Runtime.InteropServices.ComTypes.FILETIME ProcessStartTime;
		}

		// Token: 0x0200001A RID: 26
		private enum RM_APP_TYPE
		{
			// Token: 0x04000044 RID: 68
			RmUnknownApp,
			// Token: 0x04000045 RID: 69
			RmMainWindow,
			// Token: 0x04000046 RID: 70
			RmOtherWindow,
			// Token: 0x04000047 RID: 71
			RmService,
			// Token: 0x04000048 RID: 72
			RmExplorer,
			// Token: 0x04000049 RID: 73
			RmConsole,
			// Token: 0x0400004A RID: 74
			RmCritical = 1000
		}

		// Token: 0x0200001B RID: 27
		[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
		private struct RM_PROCESS_INFO
		{
			// Token: 0x0400004B RID: 75
			public LockHelper.RM_UNIQUE_PROCESS Process;

			// Token: 0x0400004C RID: 76
			[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)]
			public string strAppName;

			// Token: 0x0400004D RID: 77
			[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 64)]
			public string strServiceShortName;

			// Token: 0x0400004E RID: 78
			public LockHelper.RM_APP_TYPE ApplicationType;

			// Token: 0x0400004F RID: 79
			public uint AppStatus;

			// Token: 0x04000050 RID: 80
			public uint TSSessionId;

			// Token: 0x04000051 RID: 81
			[MarshalAs(UnmanagedType.Bool)]
			public bool bRestartable;
		}
	}
}
