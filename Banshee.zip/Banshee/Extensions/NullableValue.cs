﻿using System;

namespace Banshee.Extensions
{
	// Token: 0x0200001F RID: 31
	public static class NullableValue
	{
		// Token: 0x0600003B RID: 59 RVA: 0x00002C80 File Offset: 0x00002C80
		public static T Call<T>(Func<T> func)
		{
			T result;
			try
			{
				result = func();
			}
			catch
			{
				result = default(T);
			}
			return result;
		}
	}
}
