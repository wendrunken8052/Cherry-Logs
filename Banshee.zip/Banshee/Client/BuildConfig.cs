﻿using System;

namespace Banshee.Client
{
	// Token: 0x02000100 RID: 256
	internal static class BuildConfig
	{
		// Token: 0x0400029D RID: 669
		public const string BuildTag = "cherry140";
	}
}
