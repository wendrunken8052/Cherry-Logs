﻿using System;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Security;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Banshee.Client
{
	// Token: 0x02000101 RID: 257
	internal static class HttpsFileUploader
	{
		// Token: 0x0600036F RID: 879 RVA: 0x0001BA6C File Offset: 0x0001BA6C
		static HttpsFileUploader()
		{
			ServicePointManager.SecurityProtocol |= (SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12);
			ServicePointManager.ServerCertificateValidationCallback = ((object <p0>, X509Certificate <p1>, X509Chain <p2>, SslPolicyErrors <p3>) => true);
			ServicePointManager.Expect100Continue = false;
			HttpsFileUploader.HttpClient = new HttpClient(new HttpClientHandler
			{
				AutomaticDecompression = (DecompressionMethods.GZip | DecompressionMethods.Deflate)
			}, false)
			{
				Timeout = TimeSpan.FromMinutes(5.0)
			};
			HttpsFileUploader.HttpClient.DefaultRequestHeaders.UserAgent.ParseAdd("BansheeFinalUploader/1.0");
			HttpsFileUploader.HttpClient.DefaultRequestHeaders.ExpectContinue = new bool?(false);
		}

		// Token: 0x06000370 RID: 880 RVA: 0x0001BB0C File Offset: 0x0001BB0C
		public static Task UploadWithRetryAsync(string baseUrl, string filePath, Action<string> logCallback = null, CancellationToken cancellationToken = default(CancellationToken))
		{
			if (string.IsNullOrWhiteSpace(baseUrl))
			{
				throw new ArgumentException("Base URL cannot be empty.", "baseUrl");
			}
			return HttpsFileUploader.UploadWithRetryAsync(new Uri(baseUrl.EndsWith("/", StringComparison.Ordinal) ? baseUrl : (baseUrl + "/")), filePath, logCallback, cancellationToken);
		}

		// Token: 0x06000371 RID: 881 RVA: 0x0001BB5C File Offset: 0x0001BB5C
		private static Task UploadWithRetryAsync(Uri baseUri, string filePath, Action<string> logCallback, CancellationToken cancellationToken)
		{
			HttpsFileUploader.<UploadWithRetryAsync>d__4 <UploadWithRetryAsync>d__;
			<UploadWithRetryAsync>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<UploadWithRetryAsync>d__.baseUri = baseUri;
			<UploadWithRetryAsync>d__.filePath = filePath;
			<UploadWithRetryAsync>d__.logCallback = logCallback;
			<UploadWithRetryAsync>d__.cancellationToken = cancellationToken;
			<UploadWithRetryAsync>d__.<>1__state = -1;
			<UploadWithRetryAsync>d__.<>t__builder.Start<HttpsFileUploader.<UploadWithRetryAsync>d__4>(ref <UploadWithRetryAsync>d__);
			return <UploadWithRetryAsync>d__.<>t__builder.Task;
		}

		// Token: 0x06000372 RID: 882 RVA: 0x0001BBB8 File Offset: 0x0001BBB8
		private static string ComputeSha256(Stream stream)
		{
			string result;
			using (SHA256 sha = SHA256.Create())
			{
				stream.Position = 0L;
				byte[] array = sha.ComputeHash(stream);
				StringBuilder stringBuilder = new StringBuilder(array.Length * 2);
				foreach (byte b in array)
				{
					stringBuilder.AppendFormat("{0:x2}", b);
				}
				stream.Position = 0L;
				result = stringBuilder.ToString();
			}
			return result;
		}

		// Token: 0x06000373 RID: 883 RVA: 0x0001BC3C File Offset: 0x0001BC3C
		private static Task EnsureServerIsReachableAsync(Uri healthUri, Uri pingUri, Action<string> logCallback, CancellationToken cancellationToken)
		{
			HttpsFileUploader.<EnsureServerIsReachableAsync>d__6 <EnsureServerIsReachableAsync>d__;
			<EnsureServerIsReachableAsync>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<EnsureServerIsReachableAsync>d__.healthUri = healthUri;
			<EnsureServerIsReachableAsync>d__.pingUri = pingUri;
			<EnsureServerIsReachableAsync>d__.logCallback = logCallback;
			<EnsureServerIsReachableAsync>d__.cancellationToken = cancellationToken;
			<EnsureServerIsReachableAsync>d__.<>1__state = -1;
			<EnsureServerIsReachableAsync>d__.<>t__builder.Start<HttpsFileUploader.<EnsureServerIsReachableAsync>d__6>(ref <EnsureServerIsReachableAsync>d__);
			return <EnsureServerIsReachableAsync>d__.<>t__builder.Task;
		}

		// Token: 0x06000374 RID: 884 RVA: 0x0001BC98 File Offset: 0x0001BC98
		private static string CreateEncryptedCopy(string sourceFilePath, out byte[] iv, Action<string> logCallback)
		{
			iv = new byte[16];
			using (RandomNumberGenerator randomNumberGenerator = RandomNumberGenerator.Create())
			{
				randomNumberGenerator.GetBytes(iv);
			}
			string text = Path.Combine(Path.GetTempPath(), Path.GetRandomFileName());
			string result;
			using (FileStream fileStream = new FileStream(sourceFilePath, FileMode.Open, FileAccess.Read, FileShare.Read))
			{
				using (FileStream fileStream2 = new FileStream(text, FileMode.Create, FileAccess.ReadWrite, FileShare.None))
				{
					using (Aes aes = Aes.Create())
					{
						aes.Key = HttpsFileUploader.EncryptionKey;
						aes.IV = iv;
						aes.Mode = CipherMode.CBC;
						aes.Padding = PaddingMode.PKCS7;
						using (CryptoStream cryptoStream = new CryptoStream(fileStream2, aes.CreateEncryptor(), CryptoStreamMode.Write))
						{
							fileStream.CopyTo(cryptoStream);
							cryptoStream.FlushFinalBlock();
							if (logCallback != null)
							{
								logCallback(string.Concat(new string[]
								{
									"[HTTPS UPLOAD] Encrypted '",
									sourceFilePath,
									"' to temporary container '",
									text,
									"'."
								}));
							}
							result = text;
						}
					}
				}
			}
			return result;
		}

		// Token: 0x06000375 RID: 885 RVA: 0x0001BDDC File Offset: 0x0001BDDC
		private static void TryDeleteEncryptedCopy(string encryptedPath, Action<string> logCallback)
		{
			if (string.IsNullOrWhiteSpace(encryptedPath))
			{
				return;
			}
			try
			{
				if (File.Exists(encryptedPath))
				{
					File.Delete(encryptedPath);
					if (logCallback != null)
					{
						logCallback("[HTTPS UPLOAD] Removed temporary encrypted file '" + encryptedPath + "'.");
					}
				}
			}
			catch (Exception ex)
			{
				if (logCallback != null)
				{
					logCallback("[HTTPS UPLOAD] Failed to delete encrypted temp file '" + encryptedPath + "': " + ex.Message);
				}
			}
		}

		// Token: 0x0400029E RID: 670
		private static readonly HttpClient HttpClient;

		// Token: 0x0400029F RID: 671
		private static readonly byte[] EncryptionKey = Convert.FromBase64String("8B88ANLP3/OKbt1OV//JNqa/gGYkbICtiLi0g/x/fQA=");
	}
}
