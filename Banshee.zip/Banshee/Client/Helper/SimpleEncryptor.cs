﻿using System;
using System.Security.Cryptography;
using System.Text;
using System.Web;

namespace Banshee.Client.Helper
{
	// Token: 0x02000112 RID: 274
	public class SimpleEncryptor
	{
		// Token: 0x060003B2 RID: 946 RVA: 0x0001E760 File Offset: 0x0001E760
		public static string Encrypt(string data)
		{
			return HttpUtility.UrlEncode(Convert.ToBase64String(SimpleEncryptor.XorEncrypt(Encoding.UTF8.GetBytes(data))));
		}

		// Token: 0x060003B3 RID: 947 RVA: 0x0001E77C File Offset: 0x0001E77C
		public static string EncryptNonEnc(string data)
		{
			return Convert.ToBase64String(SimpleEncryptor.XorEncrypt(Encoding.UTF8.GetBytes(data)));
		}

		// Token: 0x060003B4 RID: 948 RVA: 0x0001E793 File Offset: 0x0001E793
		public static string Decrypt(string data)
		{
			return Encoding.UTF8.GetString(SimpleEncryptor.XorEncrypt(Convert.FromBase64String(data)));
		}

		// Token: 0x060003B5 RID: 949 RVA: 0x0001E7AC File Offset: 0x0001E7AC
		public static string Hash(string data)
		{
			string result;
			using (MD5 md = MD5.Create())
			{
				byte[] array = md.ComputeHash(Encoding.UTF8.GetBytes(data));
				StringBuilder stringBuilder = new StringBuilder();
				foreach (byte b in array)
				{
					stringBuilder.Append(b.ToString("x2"));
				}
				result = HttpUtility.UrlEncode(stringBuilder.ToString().Substring(0, 10));
			}
			return result;
		}

		// Token: 0x060003B6 RID: 950 RVA: 0x0001E830 File Offset: 0x0001E830
		public static byte[] XorEncryptMyKey(byte[] data, byte key)
		{
			byte[] array = new byte[data.Length];
			for (int i = 0; i < data.Length; i++)
			{
				array[i] = (data[i] ^ key);
			}
			return array;
		}

		// Token: 0x060003B7 RID: 951 RVA: 0x0001E860 File Offset: 0x0001E860
		public static byte[] XorEncrypt(byte[] dataBytes)
		{
			byte[] bytes = Encoding.UTF8.GetBytes(SimpleEncryptor.secretKey);
			for (int i = 0; i < dataBytes.Length; i++)
			{
				int num = i;
				dataBytes[num] ^= bytes[i % bytes.Length];
			}
			return dataBytes;
		}

		// Token: 0x040002EE RID: 750
		public static readonly string secretKey = "cvls0";
	}
}
