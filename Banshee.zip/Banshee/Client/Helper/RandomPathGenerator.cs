﻿using System;
using System.Text;

namespace Banshee.Client.Helper
{
	// Token: 0x02000110 RID: 272
	internal class RandomPathGenerator
	{
		// Token: 0x060003A7 RID: 935 RVA: 0x0001E3FC File Offset: 0x0001E3FC
		public static string GenerateCompletelyRandomPath()
		{
			int num = RandomPathGenerator.random.Next(1, 11);
			StringBuilder stringBuilder = new StringBuilder();
			for (int i = 0; i < num; i++)
			{
				int length = RandomPathGenerator.random.Next(3, 20);
				stringBuilder.Append('/');
				stringBuilder.Append(RandomPathGenerator.GenerateRandomString(length));
			}
			if (RandomPathGenerator.random.Next(2) == 1)
			{
				stringBuilder.Append(RandomPathGenerator.extensions[RandomPathGenerator.random.Next(RandomPathGenerator.extensions.Length)]);
			}
			return stringBuilder.ToString();
		}

		// Token: 0x060003A8 RID: 936 RVA: 0x0001E480 File Offset: 0x0001E480
		private static string GenerateRandomString(int length)
		{
			StringBuilder stringBuilder = new StringBuilder(length);
			for (int i = 0; i < length; i++)
			{
				stringBuilder.Append(RandomPathGenerator.chars[RandomPathGenerator.random.Next(RandomPathGenerator.chars.Length)]);
			}
			return stringBuilder.ToString();
		}

		// Token: 0x040002EA RID: 746
		private static readonly Random random = new Random();

		// Token: 0x040002EB RID: 747
		private static readonly string chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

		// Token: 0x040002EC RID: 748
		private static readonly string[] extensions = new string[]
		{
			"",
			".txt",
			".png",
			".jpg",
			".html",
			".json",
			""
		};
	}
}
