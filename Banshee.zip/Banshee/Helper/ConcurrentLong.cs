﻿using System;
using System.Threading;

namespace Banshee.Helper
{
	// Token: 0x020000AD RID: 173
	public struct ConcurrentLong
	{
		// Token: 0x1700001E RID: 30
		// (get) Token: 0x06000210 RID: 528 RVA: 0x0001140F File Offset: 0x0001140F
		// (set) Token: 0x06000211 RID: 529 RVA: 0x0001141C File Offset: 0x0001141C
		public long Value
		{
			get
			{
				return Interlocked.Read(ref this._value);
			}
			set
			{
				Interlocked.Exchange(ref this._value, value);
			}
		}

		// Token: 0x06000212 RID: 530 RVA: 0x0001142B File Offset: 0x0001142B
		public ConcurrentLong(long initial)
		{
			this._value = initial;
		}

		// Token: 0x06000213 RID: 531 RVA: 0x00011434 File Offset: 0x00011434
		public static ConcurrentLong operator ++(ConcurrentLong x)
		{
			Interlocked.Increment(ref x._value);
			return x;
		}

		// Token: 0x06000214 RID: 532 RVA: 0x00011444 File Offset: 0x00011444
		public static ConcurrentLong operator --(ConcurrentLong x)
		{
			Interlocked.Decrement(ref x._value);
			return x;
		}

		// Token: 0x06000215 RID: 533 RVA: 0x00011454 File Offset: 0x00011454
		public static implicit operator long(ConcurrentLong x)
		{
			return x.Value;
		}

		// Token: 0x06000216 RID: 534 RVA: 0x0001145D File Offset: 0x0001145D
		public static implicit operator ConcurrentLong(long v)
		{
			return new ConcurrentLong(v);
		}

		// Token: 0x06000217 RID: 535 RVA: 0x00011465 File Offset: 0x00011465
		public static ConcurrentLong operator +(ConcurrentLong x, long y)
		{
			Interlocked.Add(ref x._value, y);
			return x;
		}

		// Token: 0x06000218 RID: 536 RVA: 0x00011476 File Offset: 0x00011476
		public static ConcurrentLong operator -(ConcurrentLong x, long y)
		{
			Interlocked.Add(ref x._value, -y);
			return x;
		}

		// Token: 0x0400018B RID: 395
		private long _value;
	}
}
