﻿using System;
using System.Threading;

namespace Banshee.Helper
{
	// Token: 0x020000B5 RID: 181
	public static class MutexControl
	{
		// Token: 0x06000238 RID: 568 RVA: 0x0001214F File Offset: 0x0001214F
		public static bool CreateMutex(string mtx)
		{
			MutexControl.currentApp = new Mutex(false, mtx, ref MutexControl.createdNew);
			return MutexControl.createdNew;
		}

		// Token: 0x040001A0 RID: 416
		public static Mutex currentApp;

		// Token: 0x040001A1 RID: 417
		public static bool createdNew;
	}
}
