﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Banshee.Helper.Encrypted
{
	// Token: 0x020000DB RID: 219
	public class Asn1DerObject
	{
		// Token: 0x17000030 RID: 48
		// (get) Token: 0x060002D3 RID: 723 RVA: 0x00016299 File Offset: 0x00016299
		// (set) Token: 0x060002D4 RID: 724 RVA: 0x000162A1 File Offset: 0x000162A1
		public Asn1Der.Type Type { get; set; }

		// Token: 0x17000031 RID: 49
		// (get) Token: 0x060002D5 RID: 725 RVA: 0x000162AA File Offset: 0x000162AA
		// (set) Token: 0x060002D6 RID: 726 RVA: 0x000162B2 File Offset: 0x000162B2
		public int Lenght { get; set; }

		// Token: 0x17000032 RID: 50
		// (get) Token: 0x060002D7 RID: 727 RVA: 0x000162BB File Offset: 0x000162BB
		public List<Asn1DerObject> Objects { get; }

		// Token: 0x17000033 RID: 51
		// (get) Token: 0x060002D8 RID: 728 RVA: 0x000162C3 File Offset: 0x000162C3
		// (set) Token: 0x060002D9 RID: 729 RVA: 0x000162CB File Offset: 0x000162CB
		public byte[] Data { get; set; }

		// Token: 0x060002DA RID: 730 RVA: 0x000162D4 File Offset: 0x000162D4
		public Asn1DerObject()
		{
			this.Objects = new List<Asn1DerObject>();
		}

		// Token: 0x060002DB RID: 731 RVA: 0x000162E8 File Offset: 0x000162E8
		public override string ToString()
		{
			StringBuilder stringBuilder = new StringBuilder();
			StringBuilder stringBuilder2 = new StringBuilder();
			Asn1Der.Type type = this.Type;
			switch (type)
			{
			case Asn1Der.Type.Integer:
			{
				foreach (byte b in this.Data)
				{
					stringBuilder2.AppendFormat("{0:X2}", b);
				}
				StringBuilder stringBuilder3 = stringBuilder;
				string str = "\tINTEGER ";
				StringBuilder stringBuilder4 = stringBuilder2;
				stringBuilder3.AppendLine(str + ((stringBuilder4 != null) ? stringBuilder4.ToString() : null));
				break;
			}
			case (Asn1Der.Type)3:
			case (Asn1Der.Type)5:
				break;
			case Asn1Der.Type.OctetString:
			{
				foreach (byte b2 in this.Data)
				{
					stringBuilder2.AppendFormat("{0:X2}", b2);
				}
				StringBuilder stringBuilder5 = stringBuilder;
				string str2 = "\tOCTETSTRING ";
				StringBuilder stringBuilder6 = stringBuilder2;
				stringBuilder5.AppendLine(str2 + ((stringBuilder6 != null) ? stringBuilder6.ToString() : null));
				break;
			}
			case Asn1Der.Type.ObjectIdentifier:
			{
				foreach (byte b3 in this.Data)
				{
					stringBuilder2.AppendFormat("{0:X2}", b3);
				}
				StringBuilder stringBuilder7 = stringBuilder;
				string str3 = "\tOBJECTIDENTIFIER ";
				StringBuilder stringBuilder8 = stringBuilder2;
				stringBuilder7.AppendLine(str3 + ((stringBuilder8 != null) ? stringBuilder8.ToString() : null));
				break;
			}
			default:
				if (type == Asn1Der.Type.Sequence)
				{
					stringBuilder.AppendLine("SEQUENCE {");
				}
				break;
			}
			foreach (Asn1DerObject value in this.Objects)
			{
				stringBuilder.Append(value);
			}
			if (this.Type.Equals(Asn1Der.Type.Sequence))
			{
				stringBuilder.AppendLine("}");
			}
			return stringBuilder.ToString();
		}
	}
}
