﻿using System;
using System.Text;

namespace Banshee.Helper.Encrypted
{
	// Token: 0x020000EF RID: 239
	public static class Xor
	{
		// Token: 0x0600032D RID: 813 RVA: 0x0001927C File Offset: 0x0001927C
		public static string DecryptString(string input, byte key)
		{
			byte[] bytes = Encoding.UTF8.GetBytes(input);
			for (int i = 0; i < bytes.Length; i++)
			{
				byte[] array = bytes;
				int num = i;
				array[num] ^= key;
			}
			return Encoding.UTF8.GetString(bytes);
		}
	}
}
