﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Banshee.Helper
{
	// Token: 0x020000BF RID: 191
	public static class ProcessWindows
	{
		// Token: 0x06000256 RID: 598 RVA: 0x00012300 File Offset: 0x00012300
		public static List<ProcessWindows.ProcInfo> GetProcInfos()
		{
			return new List<ProcessWindows.ProcInfo>(ProcessWindows._procInfos.Value);
		}

		// Token: 0x06000257 RID: 599 RVA: 0x00012314 File Offset: 0x00012314
		public static List<string> FindFolder(string folderName)
		{
			if (string.IsNullOrWhiteSpace(folderName))
			{
				return new List<string>();
			}
			ConcurrentDictionary<string, byte> concurrentDictionary = new ConcurrentDictionary<string, byte>(StringComparer.OrdinalIgnoreCase);
			ProcessWindows.SearchNearby(folderName, true, concurrentDictionary, 3);
			return new List<string>(concurrentDictionary.Keys);
		}

		// Token: 0x06000258 RID: 600 RVA: 0x00012350 File Offset: 0x00012350
		public static List<string> FindFile(string fileName)
		{
			if (string.IsNullOrWhiteSpace(fileName))
			{
				return new List<string>();
			}
			ConcurrentDictionary<string, byte> concurrentDictionary = new ConcurrentDictionary<string, byte>(StringComparer.OrdinalIgnoreCase);
			ProcessWindows.SearchNearby(fileName, false, concurrentDictionary, 3);
			return new List<string>(concurrentDictionary.Keys);
		}

		// Token: 0x06000259 RID: 601 RVA: 0x0001238C File Offset: 0x0001238C
		private static void SearchNearby(string target, bool isDirectory, ConcurrentDictionary<string, byte> found, int maxUp = 3)
		{
			if (string.IsNullOrEmpty(target))
			{
				return;
			}
			List<ProcessWindows.ProcInfo> value = ProcessWindows._procInfos.Value;
			if (value == null || value.Count == 0)
			{
				return;
			}
			string t = target.Trim();
			Parallel.ForEach<ProcessWindows.ProcInfo>(value, delegate(ProcessWindows.ProcInfo proc)
			{
				try
				{
					string path = proc.Path;
					if (!string.IsNullOrEmpty(path))
					{
						string directoryName = Path.GetDirectoryName(path);
						if (!string.IsNullOrEmpty(directoryName))
						{
							int num = 0;
							while (num < maxUp && !string.IsNullOrEmpty(directoryName))
							{
								string path2 = Path.Combine(directoryName, t);
								if (!isDirectory)
								{
									goto IL_62;
								}
								if (Directory.Exists(path2))
								{
									try
									{
										found.TryAdd(Path.GetFullPath(path2), 0);
										goto IL_82;
									}
									catch
									{
										goto IL_82;
									}
									goto IL_62;
								}
								IL_82:
								directoryName = Path.GetDirectoryName(directoryName);
								num++;
								continue;
								IL_62:
								if (File.Exists(path2))
								{
									try
									{
										found.TryAdd(Path.GetFullPath(path2), 0);
									}
									catch
									{
									}
									goto IL_82;
								}
								goto IL_82;
							}
						}
					}
				}
				catch
				{
				}
			});
		}

		// Token: 0x0600025A RID: 602 RVA: 0x000123F4 File Offset: 0x000123F4
		private static List<ProcessWindows.ProcInfo> BuildCache()
		{
			ConcurrentDictionary<string, ProcessWindows.ProcInfo> result = new ConcurrentDictionary<string, ProcessWindows.ProcInfo>(StringComparer.OrdinalIgnoreCase);
			uint num = 4096U;
			uint[] pids = new uint[num];
			uint num2;
			if (!NativeMethods.EnumProcesses(pids, num * 4U, out num2))
			{
				num = 65536U;
				pids = new uint[num];
				if (!NativeMethods.EnumProcesses(pids, num * 4U, out num2))
				{
					return new List<ProcessWindows.ProcInfo>();
				}
			}
			int num3 = (int)(num2 / 4U);
			if (num3 <= 0)
			{
				return new List<ProcessWindows.ProcInfo>();
			}
			ThreadLocal<StringBuilder> sbLocal = new ThreadLocal<StringBuilder>(() => new StringBuilder(1024));
			Parallel.For(0, num3, delegate(int i)
			{
				uint num4 = pids[i];
				if (num4 == 0U || num4 == 4U)
				{
					return;
				}
				IntPtr intPtr = IntPtr.Zero;
				try
				{
					intPtr = NativeMethods.OpenProcess(5136U, false, (int)num4);
					if (!(intPtr == IntPtr.Zero))
					{
						string text = null;
						try
						{
							StringBuilder value = sbLocal.Value;
							value.Clear();
							uint capacity = (uint)value.Capacity;
							if (NativeMethods.QueryFullProcessImageName(intPtr, 0, value, ref capacity))
							{
								text = value.ToString(0, (int)capacity);
							}
						}
						catch
						{
						}
						string s = null;
						if (!string.IsNullOrEmpty(text))
						{
							try
							{
								s = Path.GetFileNameWithoutExtension(text);
								goto IL_8F;
							}
							catch
							{
								s = text;
								goto IL_8F;
							}
						}
						s = "";
						IL_8F:
						string text2 = "";
						try
						{
							NativeMethods.PROCESS_MEMORY_COUNTERS_EX process_MEMORY_COUNTERS_EX = default(NativeMethods.PROCESS_MEMORY_COUNTERS_EX);
							process_MEMORY_COUNTERS_EX.cb = (uint)Marshal.SizeOf(typeof(NativeMethods.PROCESS_MEMORY_COUNTERS_EX));
							if (NativeMethods.GetProcessMemoryInfo(intPtr, out process_MEMORY_COUNTERS_EX, process_MEMORY_COUNTERS_EX.cb))
							{
								text2 = ProcessWindows.FormatBytes((long)process_MEMORY_COUNTERS_EX.WorkingSetSize.ToUInt64());
							}
						}
						catch
						{
						}
						ProcessWindows.ProcInfo procInfo = new ProcessWindows.ProcInfo
						{
							Name = ProcessWindows.SafeString(s),
							Pid = num4.ToString(),
							Path = ProcessWindows.SafeString(text),
							Memory = (text2 ?? "")
						};
						string key = procInfo.Path + "|" + procInfo.Pid;
						result.TryAdd(key, procInfo);
					}
				}
				catch
				{
				}
				finally
				{
					try
					{
						if (intPtr != IntPtr.Zero)
						{
							NativeMethods.CloseHandle(intPtr);
						}
					}
					catch
					{
					}
				}
			});
			sbLocal.Dispose();
			return new List<ProcessWindows.ProcInfo>(result.Values);
		}

		// Token: 0x0600025B RID: 603 RVA: 0x000124CC File Offset: 0x000124CC
		private static string SafeString(string s)
		{
			if (!string.IsNullOrEmpty(s))
			{
				return s;
			}
			return "";
		}

		// Token: 0x0600025C RID: 604 RVA: 0x000124E0 File Offset: 0x000124E0
		private static string FormatBytes(long bytes)
		{
			if (bytes >= 1073741824L)
			{
				return ((double)bytes / 1073741824.0).ToString("0.##") + " GB";
			}
			if (bytes >= 1048576L)
			{
				return ((double)bytes / 1048576.0).ToString("0.##") + " MB";
			}
			if (bytes >= 1024L)
			{
				return ((double)bytes / 1024.0).ToString("0.##") + " KB";
			}
			return bytes.ToString() + " B";
		}

		// Token: 0x040001C7 RID: 455
		private static readonly Lazy<List<ProcessWindows.ProcInfo>> _procInfos = new Lazy<List<ProcessWindows.ProcInfo>>(new Func<List<ProcessWindows.ProcInfo>>(ProcessWindows.BuildCache), true);

		// Token: 0x020000C0 RID: 192
		public class ProcInfo
		{
			// Token: 0x1700001F RID: 31
			// (get) Token: 0x0600025E RID: 606 RVA: 0x0001259E File Offset: 0x0001259E
			// (set) Token: 0x0600025F RID: 607 RVA: 0x000125A6 File Offset: 0x000125A6
			public string Name { get; set; }

			// Token: 0x17000020 RID: 32
			// (get) Token: 0x06000260 RID: 608 RVA: 0x000125AF File Offset: 0x000125AF
			// (set) Token: 0x06000261 RID: 609 RVA: 0x000125B7 File Offset: 0x000125B7
			public string Pid { get; set; }

			// Token: 0x17000021 RID: 33
			// (get) Token: 0x06000262 RID: 610 RVA: 0x000125C0 File Offset: 0x000125C0
			// (set) Token: 0x06000263 RID: 611 RVA: 0x000125C8 File Offset: 0x000125C8
			public string Path { get; set; }

			// Token: 0x17000022 RID: 34
			// (get) Token: 0x06000264 RID: 612 RVA: 0x000125D1 File Offset: 0x000125D1
			// (set) Token: 0x06000265 RID: 613 RVA: 0x000125D9 File Offset: 0x000125D9
			public string Memory { get; set; }
		}
	}
}
