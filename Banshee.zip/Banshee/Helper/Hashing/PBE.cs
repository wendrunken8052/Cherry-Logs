﻿using System;
using System.Security.Cryptography;

namespace Banshee.Helper.Hashing
{
	// Token: 0x020000D5 RID: 213
	public class PBE
	{
		// Token: 0x17000028 RID: 40
		// (get) Token: 0x060002B2 RID: 690 RVA: 0x00015040 File Offset: 0x00015040
		private byte[] Ciphertext { get; }

		// Token: 0x17000029 RID: 41
		// (get) Token: 0x060002B3 RID: 691 RVA: 0x00015048 File Offset: 0x00015048
		private byte[] GlobalSalt { get; }

		// Token: 0x1700002A RID: 42
		// (get) Token: 0x060002B4 RID: 692 RVA: 0x00015050 File Offset: 0x00015050
		private byte[] MasterPass { get; }

		// Token: 0x1700002B RID: 43
		// (get) Token: 0x060002B5 RID: 693 RVA: 0x00015058 File Offset: 0x00015058
		private byte[] EntrySalt { get; }

		// Token: 0x1700002C RID: 44
		// (get) Token: 0x060002B6 RID: 694 RVA: 0x00015060 File Offset: 0x00015060
		private byte[] PartIv { get; }

		// Token: 0x060002B7 RID: 695 RVA: 0x00015068 File Offset: 0x00015068
		public PBE(byte[] ciphertext, byte[] globalSalt, byte[] masterPassword, byte[] entrySalt, byte[] partIv)
		{
			this.Ciphertext = ciphertext;
			this.GlobalSalt = globalSalt;
			this.MasterPass = masterPassword;
			this.EntrySalt = entrySalt;
			this.PartIv = partIv;
		}

		// Token: 0x060002B8 RID: 696 RVA: 0x00015098 File Offset: 0x00015098
		public byte[] Compute()
		{
			byte[] array = new byte[this.GlobalSalt.Length + this.MasterPass.Length];
			Buffer.BlockCopy(this.GlobalSalt, 0, array, 0, this.GlobalSalt.Length);
			Buffer.BlockCopy(this.MasterPass, 0, array, this.GlobalSalt.Length, this.MasterPass.Length);
			byte[] password = new SHA1Managed().ComputeHash(array);
			byte[] array2 = new byte[]
			{
				4,
				14
			};
			byte[] array3 = new byte[array2.Length + this.PartIv.Length];
			Buffer.BlockCopy(array2, 0, array3, 0, array2.Length);
			Buffer.BlockCopy(this.PartIv, 0, array3, array2.Length, this.PartIv.Length);
			byte[] bytes = new PBKDF2(new HMACSHA256(), password, this.EntrySalt, 1).GetBytes(32);
			return new AesManaged
			{
				Mode = CipherMode.CBC,
				BlockSize = 128,
				KeySize = 256,
				Padding = PaddingMode.Zeros
			}.CreateDecryptor(bytes, array3).TransformFinalBlock(this.Ciphertext, 0, this.Ciphertext.Length);
		}
	}
}
