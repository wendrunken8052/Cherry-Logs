﻿using System;

namespace Banshee.Helper
{
	// Token: 0x020000AC RID: 172
	public class BlobParsedData
	{
		// Token: 0x17000019 RID: 25
		// (get) Token: 0x06000205 RID: 517 RVA: 0x000113BA File Offset: 0x000113BA
		// (set) Token: 0x06000206 RID: 518 RVA: 0x000113C2 File Offset: 0x000113C2
		public byte Flag { get; set; }

		// Token: 0x1700001A RID: 26
		// (get) Token: 0x06000207 RID: 519 RVA: 0x000113CB File Offset: 0x000113CB
		// (set) Token: 0x06000208 RID: 520 RVA: 0x000113D3 File Offset: 0x000113D3
		public byte[] Iv { get; set; }

		// Token: 0x1700001B RID: 27
		// (get) Token: 0x06000209 RID: 521 RVA: 0x000113DC File Offset: 0x000113DC
		// (set) Token: 0x0600020A RID: 522 RVA: 0x000113E4 File Offset: 0x000113E4
		public byte[] Ciphertext { get; set; }

		// Token: 0x1700001C RID: 28
		// (get) Token: 0x0600020B RID: 523 RVA: 0x000113ED File Offset: 0x000113ED
		// (set) Token: 0x0600020C RID: 524 RVA: 0x000113F5 File Offset: 0x000113F5
		public byte[] Tag { get; set; }

		// Token: 0x1700001D RID: 29
		// (get) Token: 0x0600020D RID: 525 RVA: 0x000113FE File Offset: 0x000113FE
		// (set) Token: 0x0600020E RID: 526 RVA: 0x00011406 File Offset: 0x00011406
		public byte[] EncryptedAesKey { get; set; }
	}
}
