﻿using System;
using System.Runtime.CompilerServices;

namespace Banshee.Helper
{
	// Token: 0x020000AF RID: 175
	public static class DebugLogger
	{
		// Token: 0x0600021B RID: 539 RVA: 0x00011540 File Offset: 0x00011540
		public static void Configure(Action<string> logger)
		{
			DebugLogger._logger = logger;
		}

		// Token: 0x0600021C RID: 540 RVA: 0x00011548 File Offset: 0x00011548
		public static void Log(string message)
		{
			Action<string> logger = DebugLogger._logger;
			if (logger == null)
			{
				return;
			}
			logger(message);
		}

		// Token: 0x0400018C RID: 396
		[Nullable(new byte[]
		{
			2,
			0
		})]
		private static Action<string> _logger;
	}
}
