﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net.NetworkInformation;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace Banshee.Helper
{
	// Token: 0x020000B0 RID: 176
	public static class HwidGenerator
	{
		// Token: 0x0600021D RID: 541 RVA: 0x0001155C File Offset: 0x0001155C
		public static string GetHwid()
		{
			if (HwidGenerator._hwid != null)
			{
				return HwidGenerator._hwid;
			}
			object @lock = HwidGenerator._lock;
			bool flag = false;
			string hwid;
			try
			{
				Monitor.Enter(@lock, ref flag);
				if (HwidGenerator._hwid != null)
				{
					hwid = HwidGenerator._hwid;
				}
				else
				{
					List<string> list = new List<string>();
					string mg = null;
					string cpuName = null;
					List<string> vols = null;
					List<string> macs = null;
					Task task = Task.Run(delegate()
					{
						mg = HwidGenerator.GetMachineGuid();
					});
					Task task2 = Task.Run(delegate()
					{
						cpuName = HwidGenerator.GetCpuName();
					});
					Task task3 = Task.Run(delegate()
					{
						vols = HwidGenerator.GetFixedVolumeSerials();
					});
					Task task4 = Task.Run(delegate()
					{
						macs = HwidGenerator.GetMacAddresses();
					});
					Task.WaitAll(new Task[]
					{
						task,
						task2,
						task3,
						task4
					});
					if (!string.IsNullOrEmpty(mg))
					{
						list.Add("MG:" + mg);
					}
					if (!string.IsNullOrEmpty(cpuName))
					{
						list.Add("CPU:" + cpuName);
					}
					list.Add("Cores:" + Environment.ProcessorCount.ToString());
					if (vols != null && vols.Count > 0)
					{
						list.Add("VOLS:" + string.Join(",", vols));
					}
					if (macs != null && macs.Count > 0)
					{
						list.Add("MACS:" + string.Join(",", macs));
					}
					list.Add("MN:" + Environment.MachineName);
					HwidGenerator._hwid = HwidGenerator.ComputeSha256(string.Join("|", list));
					hwid = HwidGenerator._hwid;
				}
			}
			finally
			{
				if (flag)
				{
					Monitor.Exit(@lock);
				}
			}
			return hwid;
		}

		// Token: 0x0600021E RID: 542 RVA: 0x00011758 File Offset: 0x00011758
		private static string ComputeSha256(string input)
		{
			string result;
			using (SHA256 sha = SHA256.Create())
			{
				byte[] array = sha.ComputeHash(Encoding.UTF8.GetBytes(input));
				StringBuilder stringBuilder = new StringBuilder(array.Length * 2);
				foreach (byte b in array)
				{
					stringBuilder.Append(b.ToString("x2"));
				}
				result = stringBuilder.ToString();
			}
			return result;
		}

		// Token: 0x0600021F RID: 543 RVA: 0x000117D4 File Offset: 0x000117D4
		private static string GetMachineGuid()
		{
			string result;
			try
			{
				using (RegistryKey registryKey = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64).OpenSubKey("SOFTWARE\\Microsoft\\Cryptography"))
				{
					string text = ((registryKey != null) ? registryKey.GetValue("MachineGuid") : null) as string;
					if (!string.IsNullOrEmpty(text))
					{
						return text.Trim();
					}
				}
				using (RegistryKey registryKey2 = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry32).OpenSubKey("SOFTWARE\\Microsoft\\Cryptography"))
				{
					string text2 = ((registryKey2 != null) ? registryKey2.GetValue("MachineGuid") : null) as string;
					result = (((text2 != null) ? text2.Trim() : null) ?? "");
				}
			}
			catch
			{
				result = "";
			}
			return result;
		}

		// Token: 0x06000220 RID: 544 RVA: 0x000118B4 File Offset: 0x000118B4
		private static string GetCpuName()
		{
			string result;
			try
			{
				using (RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0"))
				{
					string text = ((registryKey != null) ? registryKey.GetValue("ProcessorNameString") : null) as string;
					if (!string.IsNullOrEmpty(text))
					{
						result = text.Trim();
					}
					else
					{
						string text2 = ((registryKey != null) ? registryKey.GetValue("VendorIdentifier") : null) as string;
						result = (((text2 != null) ? text2.Trim() : null) ?? "");
					}
				}
			}
			catch
			{
				result = "";
			}
			return result;
		}

		// Token: 0x06000221 RID: 545 RVA: 0x00011958 File Offset: 0x00011958
		private static List<string> GetFixedVolumeSerials()
		{
			List<string> list = new List<string>();
			try
			{
				foreach (DriveInfo driveInfo in DriveInfo.GetDrives())
				{
					if (driveInfo.DriveType == DriveType.Fixed && driveInfo.IsReady)
					{
						StringBuilder stringBuilder = new StringBuilder(261);
						StringBuilder stringBuilder2 = new StringBuilder(261);
						uint num;
						uint num2;
						uint num3;
						if (NativeMethods.GetVolumeInformation(driveInfo.RootDirectory.FullName, stringBuilder, stringBuilder.Capacity, out num, out num2, out num3, stringBuilder2, stringBuilder2.Capacity))
						{
							list.Add(num.ToString("X8").ToLowerInvariant());
						}
					}
				}
			}
			catch
			{
			}
			return list;
		}

		// Token: 0x06000222 RID: 546 RVA: 0x00011A04 File Offset: 0x00011A04
		private static List<string> GetMacAddresses()
		{
			List<string> list = new List<string>();
			try
			{
				foreach (NetworkInterface networkInterface in NetworkInterface.GetAllNetworkInterfaces())
				{
					if (networkInterface.OperationalStatus == OperationalStatus.Up)
					{
						byte[] addressBytes = networkInterface.GetPhysicalAddress().GetAddressBytes();
						if (addressBytes.Length != 0)
						{
							StringBuilder stringBuilder = new StringBuilder();
							for (int j = 0; j < addressBytes.Length; j++)
							{
								if (j > 0)
								{
									stringBuilder.Append(':');
								}
								stringBuilder.Append(addressBytes[j].ToString("x2"));
							}
							list.Add(stringBuilder.ToString());
						}
					}
				}
			}
			catch
			{
			}
			return list;
		}

		// Token: 0x0400018D RID: 397
		private static string _hwid;

		// Token: 0x0400018E RID: 398
		private static readonly object _lock = new object();
	}
}
