﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;

namespace Banshee.Helper.Data
{
	// Token: 0x020000F7 RID: 247
	internal sealed class DomainDetector
	{
		// Token: 0x06000349 RID: 841 RVA: 0x0001A1CC File Offset: 0x0001A1CC
		public DomainDetector()
		{
			this._patterns = DomainDetector.CreatePatterns();
		}

		// Token: 0x0600034A RID: 842 RVA: 0x0001A1E0 File Offset: 0x0001A1E0
		public void TrackPassword(string origin)
		{
			if (string.IsNullOrWhiteSpace(origin))
			{
				return;
			}
			string host = DomainDetector.ExtractHost(origin);
			string haystack = origin ?? string.Empty;
			foreach (DomainDetector.DomainPattern domainPattern in this._patterns)
			{
				if (domainPattern.Matches(host, haystack))
				{
					Interlocked.Increment(ref domainPattern.PasswordHits);
				}
			}
		}

		// Token: 0x0600034B RID: 843 RVA: 0x0001A23C File Offset: 0x0001A23C
		public void TrackCookie(string hostValue, string path)
		{
			if (string.IsNullOrWhiteSpace(hostValue) && string.IsNullOrWhiteSpace(path))
			{
				return;
			}
			string text = DomainDetector.NormalizeHost(hostValue);
			string haystack = string.Concat(new string[]
			{
				hostValue ?? string.Empty,
				" ",
				text ?? string.Empty,
				" ",
				path ?? string.Empty
			});
			foreach (DomainDetector.DomainPattern domainPattern in this._patterns)
			{
				if (domainPattern.Matches(text, haystack))
				{
					Interlocked.Increment(ref domainPattern.CookieHits);
				}
			}
		}

		// Token: 0x0600034C RID: 844 RVA: 0x0001A2D8 File Offset: 0x0001A2D8
		public string BuildReport()
		{
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.AppendLine("PDD:");
			foreach (DomainDetector.DomainPattern domainPattern in this._patterns)
			{
				int num = Thread.VolatileRead(ref domainPattern.PasswordHits);
				if (num > 0)
				{
					stringBuilder.AppendLine(DomainDetector.FormatLine(domainPattern.Label, domainPattern.Pattern, num));
				}
			}
			stringBuilder.AppendLine("CDD:");
			foreach (DomainDetector.DomainPattern domainPattern2 in this._patterns)
			{
				int num2 = Thread.VolatileRead(ref domainPattern2.CookieHits);
				if (num2 > 0)
				{
					stringBuilder.AppendLine(DomainDetector.FormatLine(domainPattern2.Label, domainPattern2.Pattern, num2));
				}
			}
			return stringBuilder.ToString().TrimEnd(Array.Empty<char>());
		}

		// Token: 0x0600034D RID: 845 RVA: 0x0001A3A1 File Offset: 0x0001A3A1
		private static string FormatLine(string label, string pattern, int count)
		{
			return string.Concat(new string[]
			{
				"[",
				label,
				"] ",
				pattern,
				" (",
				count.ToString(),
				")"
			});
		}

		// Token: 0x0600034E RID: 846 RVA: 0x0001A3E0 File Offset: 0x0001A3E0
		private static bool Contains(string haystack, string pattern)
		{
			return !string.IsNullOrEmpty(haystack) && !string.IsNullOrEmpty(pattern) && haystack.IndexOf(pattern, StringComparison.OrdinalIgnoreCase) >= 0;
		}

		// Token: 0x0600034F RID: 847 RVA: 0x0001A402 File Offset: 0x0001A402
		private static bool HostMatches(string host, string pattern)
		{
			return !string.IsNullOrEmpty(host) && !string.IsNullOrEmpty(pattern) && (host.Equals(pattern, StringComparison.OrdinalIgnoreCase) || host.EndsWith("." + pattern, StringComparison.OrdinalIgnoreCase));
		}

		// Token: 0x06000350 RID: 848 RVA: 0x0001A434 File Offset: 0x0001A434
		private static string ExtractHost(string value)
		{
			if (string.IsNullOrWhiteSpace(value))
			{
				return null;
			}
			value = value.Trim();
			Uri uri;
			if (Uri.TryCreate(value, UriKind.Absolute, out uri))
			{
				return DomainDetector.NormalizeHost(uri.Host);
			}
			Uri uri2;
			if (value.IndexOf("://", StringComparison.Ordinal) >= 0 && Uri.TryCreate(value, UriKind.RelativeOrAbsolute, out uri2) && uri2.IsAbsoluteUri)
			{
				return DomainDetector.NormalizeHost(uri2.Host);
			}
			int num = value.IndexOf('/');
			if (num > -1)
			{
				value = value.Substring(0, num);
			}
			return DomainDetector.NormalizeHost(value);
		}

		// Token: 0x06000351 RID: 849 RVA: 0x0001A4B8 File Offset: 0x0001A4B8
		private static string NormalizeHost(string host)
		{
			if (string.IsNullOrWhiteSpace(host))
			{
				return null;
			}
			host = host.Trim();
			if (host.StartsWith(".", StringComparison.Ordinal))
			{
				host = host.TrimStart(new char[]
				{
					'.'
				});
			}
			int num = host.IndexOf(':');
			if (num > -1)
			{
				host = host.Substring(0, num);
			}
			host = host.Trim(new char[]
			{
				'.'
			});
			if (host.Length == 0)
			{
				return null;
			}
			return host;
		}

		// Token: 0x06000352 RID: 850 RVA: 0x0001A530 File Offset: 0x0001A530
		private static DomainDetector.DomainPattern[] CreatePatterns()
		{
			DomainDetector.<>c__DisplayClass12_0 CS$<>8__locals1;
			CS$<>8__locals1.list = new List<DomainDetector.DomainPattern>();
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("Pornhub", new string[]
			{
				"pornhub.com"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("EA", new string[]
			{
				"ea.com"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("Epicgames", new string[]
			{
				"epicgames.com"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("Riotgames", new string[]
			{
				"riotgames.com"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("Playstation", new string[]
			{
				"playstation.com"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("Xbox", new string[]
			{
				"xbox.com"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("Steam", new string[]
			{
				"steamcommunity.com",
				"steam.com"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("Minecraft", new string[]
			{
				"minecraft.net"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("Roblox", new string[]
			{
				"roblox.com"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("YouTube", new string[]
			{
				"youtube.com"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("Netflix", new string[]
			{
				"netflix.com"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("HBO", new string[]
			{
				"hbo.com"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("Crunchyroll", new string[]
			{
				"crunchyroll.com"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("Disney", new string[]
			{
				"disney.com"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("Twitch", new string[]
			{
				"twitch.com"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("Spotify", new string[]
			{
				"spotify.com"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("Instagram", new string[]
			{
				"instagram.com"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("Twitter", new string[]
			{
				"twitter.com"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("Amazon", new string[]
			{
				"amazon.com"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("Ebay", new string[]
			{
				"ebay.com"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("Aliexpress", new string[]
			{
				"aliexpress.com"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("Booking", new string[]
			{
				"booking.com"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("PayPal", new string[]
			{
				"paypal.com"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("Sellix", new string[]
			{
				"sellix.io"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("Stormgain", new string[]
			{
				"stormgain.com"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("Ledger", new string[]
			{
				"ledger.com"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("Trezor", new string[]
			{
				"trezor.io"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("Wallet.atomex", new string[]
			{
				"wallet.atomex.me"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("Web.lumiwallet", new string[]
			{
				"web.lumiwallet.com"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("Coin", new string[]
			{
				"blockchain.info",
				"upbit.com",
				"blockchain.com",
				"poloniex.com",
				"metamask.io",
				"korbit.co.kr",
				"binance.com",
				"etorox.com",
				"bybit.com",
				"cex.io",
				"exmo.me",
				"coinbase.com",
				"yobit.net",
				"bitforex.com",
				"myetherwallet.com",
				"primexbt.com",
				"probit.com",
				"binance.us",
				"ftx.com",
				"jaxx.io",
				"bitmex.com",
				"bitfinex.com",
				"huobi.com",
				"kucoin.com",
				"okx.com",
				"atomicwallet.io",
				"exodus.com",
				"crypto.com",
				"trustwallet.com",
				"walletconnect.com",
				"guarda.co",
				"coin.space",
				"freewallet.org",
				"ownrwallet.com",
				"wx.network",
				"dogechain.info",
				"thorwallet.org",
				"zerion.io",
				"ambire.com"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("ProtonMail", new string[]
			{
				"protonmail.com"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("Outlook", new string[]
			{
				"outlook.live.com",
				"outlook.com"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("iCloud", new string[]
			{
				"icloud.com"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("Zoho", new string[]
			{
				"zoho.com"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("GMX", new string[]
			{
				"gmx.com",
				"gmx.de"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("Tutanota", new string[]
			{
				"tutanota.com"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("Fastmail", new string[]
			{
				"fastmail.com"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("Yahoo", new string[]
			{
				"mail.yahoo.com"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("Gmail", new string[]
			{
				"mail.google.com",
				"gmail.com"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("web.de", new string[]
			{
				"web.de"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("GoDaddy", new string[]
			{
				"godaddy.com"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("Namecheap", new string[]
			{
				"namecheap.com"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("Namesilo", new string[]
			{
				"namesilo.com"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("Bluehost", new string[]
			{
				"bluehost.com"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("Hostgator", new string[]
			{
				"hostgator.com"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("Domain.com", new string[]
			{
				"domain.com"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("Freenom", new string[]
			{
				"freenom.com"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("Akname", new string[]
			{
				"akname.com"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("Dynadot", new string[]
			{
				"dynadot.com"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("ExpressVPN", new string[]
			{
				"expressvpn.com"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddSubstrings|12_1("Wordpress", new string[]
			{
				"/wp-admin"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddSubstrings|12_1("Citrix", new string[]
			{
				"/vpn/index.html",
				"/vpn/tmindex.html",
				"/logonpoint/tmindex.html",
				"/citrix/",
				"/logonpoint/index.html",
				"XenApp1/auth/login.aspx",
				"auth/silentDetection.aspx",
				"RDWeb",
				"remote/login",
				"/global-protect/",
				"/dana-na/",
				"+cscoe+",
				"sslvpn",
				"/virtualworkspace",
				"XenDesktop",
				"/owa/",
				"/pulse/",
				"/forti/",
				"/cisco/",
				"/nf/auth/doAuthentication.do"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("Citrix", new string[]
			{
				"screenconnect.com",
				"atlassian.com"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("Google Ads", new string[]
			{
				"ads.google.com"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddSubstrings|12_1("Manager", new string[]
			{
				"/admin/",
				"/manager/"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("Melonity", new string[]
			{
				"melonity.gg"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("masgl.store", new string[]
			{
				"masgl.store"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddSubstrings|12_1("Port", new string[]
			{
				":8040",
				":2083",
				":2082"
			}, ref CS$<>8__locals1);
			DomainDetector.<CreatePatterns>g__AddHosts|12_0("Origin", new string[]
			{
				"origin.com"
			}, ref CS$<>8__locals1);
			return CS$<>8__locals1.list.ToArray();
		}

		// Token: 0x06000353 RID: 851 RVA: 0x0001AD88 File Offset: 0x0001AD88
		[CompilerGenerated]
		internal static void <CreatePatterns>g__AddHosts|12_0(string label, string[] hosts, ref DomainDetector.<>c__DisplayClass12_0 A_2)
		{
			if (hosts == null)
			{
				return;
			}
			foreach (string text in hosts)
			{
				if (!string.IsNullOrWhiteSpace(text))
				{
					A_2.list.Add(new DomainDetector.DomainPattern(label, text.Trim(), DomainDetector.MatchKind.HostSuffix));
				}
			}
		}

		// Token: 0x06000354 RID: 852 RVA: 0x0001ADD0 File Offset: 0x0001ADD0
		[CompilerGenerated]
		internal static void <CreatePatterns>g__AddSubstrings|12_1(string label, string[] fragments, ref DomainDetector.<>c__DisplayClass12_0 A_2)
		{
			if (fragments == null)
			{
				return;
			}
			foreach (string text in fragments)
			{
				if (!string.IsNullOrWhiteSpace(text))
				{
					A_2.list.Add(new DomainDetector.DomainPattern(label, text.Trim(), DomainDetector.MatchKind.Substring));
				}
			}
		}

		// Token: 0x04000289 RID: 649
		private readonly DomainDetector.DomainPattern[] _patterns;

		// Token: 0x020000F8 RID: 248
		private enum MatchKind
		{
			// Token: 0x0400028B RID: 651
			HostSuffix,
			// Token: 0x0400028C RID: 652
			Substring
		}

		// Token: 0x020000F9 RID: 249
		private sealed class DomainPattern
		{
			// Token: 0x06000355 RID: 853 RVA: 0x0001AE15 File Offset: 0x0001AE15
			public DomainPattern(string label, string pattern, DomainDetector.MatchKind kind)
			{
				this.Label = label;
				this.Pattern = pattern;
				this.Kind = kind;
			}

			// Token: 0x1700003A RID: 58
			// (get) Token: 0x06000356 RID: 854 RVA: 0x0001AE32 File Offset: 0x0001AE32
			public string Label { get; }

			// Token: 0x1700003B RID: 59
			// (get) Token: 0x06000357 RID: 855 RVA: 0x0001AE3A File Offset: 0x0001AE3A
			public string Pattern { get; }

			// Token: 0x1700003C RID: 60
			// (get) Token: 0x06000358 RID: 856 RVA: 0x0001AE42 File Offset: 0x0001AE42
			public DomainDetector.MatchKind Kind { get; }

			// Token: 0x06000359 RID: 857 RVA: 0x0001AE4A File Offset: 0x0001AE4A
			public bool Matches(string host, string haystack)
			{
				if (this.Kind == DomainDetector.MatchKind.HostSuffix)
				{
					return DomainDetector.HostMatches(host, this.Pattern);
				}
				return DomainDetector.Contains(haystack, this.Pattern);
			}

			// Token: 0x04000290 RID: 656
			public int PasswordHits;

			// Token: 0x04000291 RID: 657
			public int CookieHits;
		}
	}
}
