﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Text;

namespace Banshee.Helper.Data
{
	// Token: 0x020000FB RID: 251
	public sealed class InMemoryZip : IDisposable
	{
		// Token: 0x1700003D RID: 61
		// (get) Token: 0x0600035A RID: 858 RVA: 0x0001AE6D File Offset: 0x0001AE6D
		public int Count
		{
			get
			{
				return this._entries.Count;
			}
		}

		// Token: 0x0600035B RID: 859 RVA: 0x0001AE7C File Offset: 0x0001AE7C
		private static string NormalizeEntryName(string name)
		{
			if (string.IsNullOrWhiteSpace(name))
			{
				throw new ArgumentException("Entry name is null or empty", "name");
			}
			name = name.Replace('\\', '/').Trim(new char[]
			{
				'/'
			});
			if (name.Length != 0)
			{
				return name;
			}
			throw new ArgumentException("Invalid entry name", "name");
		}

		// Token: 0x0600035C RID: 860 RVA: 0x0001AED8 File Offset: 0x0001AED8
		public void AddFile(string entryPath, byte[] content)
		{
			if (this._disposed)
			{
				throw new ObjectDisposedException("InMemoryZip");
			}
			if (content != null)
			{
				string key = InMemoryZip.NormalizeEntryName(entryPath);
				byte[] copy = new byte[content.Length];
				if (content.Length != 0)
				{
					Buffer.BlockCopy(content, 0, copy, 0, content.Length);
				}
				this._entries.AddOrUpdate(key, copy, (string text, byte[] old) => copy);
			}
		}

		// Token: 0x0600035D RID: 861 RVA: 0x0001AF4A File Offset: 0x0001AF4A
		public void AddTextFile(string entryPath, string text)
		{
			if (!string.IsNullOrEmpty(text))
			{
				this.AddFile(entryPath, Encoding.UTF8.GetBytes(text));
			}
		}

		// Token: 0x0600035E RID: 862 RVA: 0x0001AF68 File Offset: 0x0001AF68
		public void AppendTextFile(string entryPath, string text)
		{
			if (this._disposed)
			{
				throw new ObjectDisposedException("InMemoryZip");
			}
			if (text == null)
			{
				return;
			}
			string key = InMemoryZip.NormalizeEntryName(entryPath);
			byte[] appendBytes = Encoding.UTF8.GetBytes(text);
			this._entries.AddOrUpdate(key, appendBytes, delegate(string _, byte[] existing)
			{
				if (existing == null || existing.Length == 0)
				{
					byte[] array = new byte[appendBytes.Length];
					Buffer.BlockCopy(appendBytes, 0, array, 0, appendBytes.Length);
					return array;
				}
				byte[] array2 = new byte[existing.Length + appendBytes.Length];
				Buffer.BlockCopy(existing, 0, array2, 0, existing.Length);
				Buffer.BlockCopy(appendBytes, 0, array2, existing.Length, appendBytes.Length);
				return array2;
			});
		}

		// Token: 0x0600035F RID: 863 RVA: 0x0001AFCC File Offset: 0x0001AFCC
		public void AddDirectoryFiles(string sourceDirectory, string targetEntryDirectory = "", bool recursive = true)
		{
			if (this._disposed)
			{
				throw new ObjectDisposedException("InMemoryZip");
			}
			if (string.IsNullOrEmpty(sourceDirectory))
			{
				throw new ArgumentException("sourceDirectory");
			}
			if (!Directory.Exists(sourceDirectory))
			{
				return;
			}
			SearchOption searchOption = recursive ? SearchOption.AllDirectories : SearchOption.TopDirectoryOnly;
			foreach (string text in Directory.GetFiles(sourceDirectory, "*", searchOption))
			{
				string text2 = text.Substring(sourceDirectory.Length).TrimStart(new char[]
				{
					Path.DirectorySeparatorChar,
					Path.AltDirectorySeparatorChar
				});
				string text3 = string.IsNullOrEmpty(targetEntryDirectory) ? text2 : Path.Combine(targetEntryDirectory, text2);
				text3 = text3.Replace('\\', '/');
				try
				{
					byte[] content = File.ReadAllBytes(text);
					this.AddFile(text3, content);
				}
				catch
				{
				}
			}
		}

		// Token: 0x06000360 RID: 864 RVA: 0x0001B0A4 File Offset: 0x0001B0A4
		public byte[] ToArray(CompressionLevel compression = CompressionLevel.Fastest)
		{
			if (this._disposed)
			{
				throw new ObjectDisposedException("InMemoryZip");
			}
			object buildLock = this._buildLock;
			byte[] result;
			lock (buildLock)
			{
				using (MemoryStream memoryStream = new MemoryStream())
				{
					using (ZipArchive zipArchive = new ZipArchive(memoryStream, ZipArchiveMode.Create, true, Encoding.UTF8))
					{
						foreach (KeyValuePair<string, byte[]> keyValuePair in this._entries)
						{
							using (Stream stream = zipArchive.CreateEntry(keyValuePair.Key, compression).Open())
							{
								byte[] value = keyValuePair.Value;
								stream.Write(value, 0, value.Length);
							}
						}
					}
					result = memoryStream.ToArray();
				}
			}
			return result;
		}

		// Token: 0x06000361 RID: 865 RVA: 0x0001B1BC File Offset: 0x0001B1BC
		public void Clear()
		{
			this._entries.Clear();
		}

		// Token: 0x06000362 RID: 866 RVA: 0x0001B1C9 File Offset: 0x0001B1C9
		public void Dispose()
		{
			if (!this._disposed)
			{
				this._disposed = true;
				this._entries.Clear();
			}
		}

		// Token: 0x04000293 RID: 659
		private readonly ConcurrentDictionary<string, byte[]> _entries = new ConcurrentDictionary<string, byte[]>(StringComparer.OrdinalIgnoreCase);

		// Token: 0x04000294 RID: 660
		private readonly object _buildLock = new object();

		// Token: 0x04000295 RID: 661
		private bool _disposed;
	}
}
