﻿using System;

namespace Banshee.Helper.Data
{
	// Token: 0x020000F1 RID: 241
	public static class CollectionFolders
	{
		// Token: 0x0600032F RID: 815 RVA: 0x00019470 File Offset: 0x00019470
		public static string Messengers(string relativePath)
		{
			return CollectionFolders.EnsureCategory("Messengers", relativePath);
		}

		// Token: 0x06000330 RID: 816 RVA: 0x0001947D File Offset: 0x0001947D
		public static string Games(string relativePath)
		{
			return CollectionFolders.EnsureCategory("Games", relativePath);
		}

		// Token: 0x06000331 RID: 817 RVA: 0x0001948C File Offset: 0x0001948C
		private static string EnsureCategory(string category, string relativePath)
		{
			if (string.IsNullOrWhiteSpace(category))
			{
				throw new ArgumentException("category");
			}
			string text = CollectionFolders.NormalizeSegment(category);
			string text2 = CollectionFolders.NormalizeSegment(relativePath);
			if (string.IsNullOrEmpty(text2))
			{
				return text;
			}
			if (text2.StartsWith(text + "/", StringComparison.OrdinalIgnoreCase) || string.Equals(text2, text, StringComparison.OrdinalIgnoreCase))
			{
				return text2;
			}
			return text + "/" + text2;
		}

		// Token: 0x06000332 RID: 818 RVA: 0x000194F0 File Offset: 0x000194F0
		private static string NormalizeSegment(string input)
		{
			if (string.IsNullOrEmpty(input))
			{
				return string.Empty;
			}
			string text = input.Trim(CollectionFolders.TrimChars).Replace('\\', '/');
			while (text.Contains("//"))
			{
				text = text.Replace("//", "/");
			}
			return text;
		}

		// Token: 0x04000265 RID: 613
		private static readonly char[] TrimChars = new char[]
		{
			'\\',
			'/'
		};
	}
}
