﻿using System;
using Microsoft.Win32;

namespace Banshee.Helper
{
	// Token: 0x020000CF RID: 207
	public static class WindowsInfo
	{
		// Token: 0x0600029C RID: 668 RVA: 0x00013CE0 File Offset: 0x00013CE0
		public static string GetProductName()
		{
			string result;
			try
			{
				using (RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion"))
				{
					if (registryKey == null)
					{
						result = "Unknown";
					}
					else
					{
						string str = (registryKey.GetValue("ProductName") as string) ?? "Unknown";
						string text;
						if ((text = (registryKey.GetValue("ReleaseId") as string)) == null)
						{
							text = ((registryKey.GetValue("DisplayVersion") as string) ?? "");
						}
						string str2 = text;
						result = (str + " " + str2).Trim();
					}
				}
			}
			catch
			{
				result = "Unknown";
			}
			return result;
		}

		// Token: 0x0600029D RID: 669 RVA: 0x00013D94 File Offset: 0x00013D94
		public static string GetBuildNumber()
		{
			string result;
			try
			{
				using (RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion"))
				{
					if (registryKey == null)
					{
						result = "Unknown";
					}
					else
					{
						object value = registryKey.GetValue("CurrentBuild");
						string text;
						if ((text = ((value != null) ? value.ToString() : null)) == null)
						{
							object value2 = registryKey.GetValue("CurrentBuildNumber");
							text = (((value2 != null) ? value2.ToString() : null) ?? "Unknown");
						}
						result = text;
					}
				}
			}
			catch
			{
				result = "Unknown";
			}
			return result;
		}

		// Token: 0x0600029E RID: 670 RVA: 0x00013E2C File Offset: 0x00013E2C
		public static string GetArchitecture()
		{
			string result;
			try
			{
				result = (Environment.Is64BitOperatingSystem ? "x64" : "x86");
			}
			catch
			{
				result = "Unknown";
			}
			return result;
		}

		// Token: 0x0600029F RID: 671 RVA: 0x00013E6C File Offset: 0x00013E6C
		public static string GetVersion()
		{
			string result;
			try
			{
				using (RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion"))
				{
					if (registryKey == null)
					{
						result = "Unknown";
					}
					else
					{
						object value = registryKey.GetValue("CurrentMajorVersionNumber");
						object value2 = registryKey.GetValue("CurrentMinorVersionNumber");
						if (value != null && value2 != null)
						{
							result = string.Format("{0}.{1}", value, value2);
						}
						else
						{
							string text = registryKey.GetValue("CurrentVersion") as string;
							if (!string.IsNullOrEmpty(text))
							{
								result = text;
							}
							else
							{
								result = "Unknown";
							}
						}
					}
				}
			}
			catch
			{
				result = "Unknown";
			}
			return result;
		}

		// Token: 0x060002A0 RID: 672 RVA: 0x00013F1C File Offset: 0x00013F1C
		public static string GetFullInfo()
		{
			return string.Concat(new string[]
			{
				"OS Product: ",
				WindowsInfo.GetProductName(),
				"\nOS Build: ",
				WindowsInfo.GetBuildNumber(),
				"\nOS Arch: ",
				WindowsInfo.GetArchitecture()
			});
		}
	}
}
