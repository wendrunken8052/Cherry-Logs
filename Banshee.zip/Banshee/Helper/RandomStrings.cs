﻿using System;
using System.Linq;

namespace Banshee.Helper
{
	// Token: 0x020000C4 RID: 196
	public static class RandomStrings
	{
		// Token: 0x0600026E RID: 622 RVA: 0x000128D4 File Offset: 0x000128D4
		public static string GenerateHashTag()
		{
			return " #" + RandomStrings.GenerateString();
		}

		// Token: 0x0600026F RID: 623 RVA: 0x000128E5 File Offset: 0x000128E5
		public static string GenerateString()
		{
			return RandomStrings.GenerateString(5);
		}

		// Token: 0x06000270 RID: 624 RVA: 0x000128F0 File Offset: 0x000128F0
		public static string GenerateString(int length)
		{
			char c = "abcdefghijklmnopqrstuvwxyz"[RandomStrings.Random.Next("abcdefghijklmnopqrstuvwxyz".Length)];
			char[] value = (from s in Enumerable.Repeat<string>("abcdefghijklmnopqrstuvwxyz", length - 1)
			select s[RandomStrings.Random.Next(s.Length)]).ToArray<char>();
			return c.ToString() + new string(value);
		}

		// Token: 0x040001D5 RID: 469
		private const string Ascii = "abcdefghijklmnopqrstuvwxyz";

		// Token: 0x040001D6 RID: 470
		private static readonly Random Random = new Random();
	}
}
