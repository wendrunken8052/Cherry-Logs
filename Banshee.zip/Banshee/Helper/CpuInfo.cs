﻿using System;
using Microsoft.Win32;

namespace Banshee.Helper
{
	// Token: 0x020000AE RID: 174
	public static class CpuInfo
	{
		// Token: 0x06000219 RID: 537 RVA: 0x00011488 File Offset: 0x00011488
		public static string GetName()
		{
			string result;
			try
			{
				using (RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0"))
				{
					string text;
					if ((text = (((registryKey != null) ? registryKey.GetValue("ProcessorNameString") : null) as string)) == null)
					{
						text = ((((registryKey != null) ? registryKey.GetValue("VendorIdentifier") : null) as string) ?? "Unknown");
					}
					result = text;
				}
			}
			catch
			{
				result = "Unknown";
			}
			return result;
		}

		// Token: 0x0600021A RID: 538 RVA: 0x00011514 File Offset: 0x00011514
		public static int GetLogicalCores()
		{
			int result;
			try
			{
				result = Environment.ProcessorCount;
			}
			catch
			{
				result = 0;
			}
			return result;
		}
	}
}
