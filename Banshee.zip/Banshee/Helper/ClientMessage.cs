﻿using System;

namespace Banshee.Helper
{
	// Token: 0x020000CE RID: 206
	public class ClientMessage
	{
		// Token: 0x17000024 RID: 36
		// (get) Token: 0x06000295 RID: 661 RVA: 0x00013CAA File Offset: 0x00013CAA
		// (set) Token: 0x06000296 RID: 662 RVA: 0x00013CB2 File Offset: 0x00013CB2
		public string Type { get; set; }

		// Token: 0x17000025 RID: 37
		// (get) Token: 0x06000297 RID: 663 RVA: 0x00013CBB File Offset: 0x00013CBB
		// (set) Token: 0x06000298 RID: 664 RVA: 0x00013CC3 File Offset: 0x00013CC3
		public byte[] Payload { get; set; }

		// Token: 0x17000026 RID: 38
		// (get) Token: 0x06000299 RID: 665 RVA: 0x00013CCC File Offset: 0x00013CCC
		// (set) Token: 0x0600029A RID: 666 RVA: 0x00013CD4 File Offset: 0x00013CD4
		public string FileName { get; set; }
	}
}
