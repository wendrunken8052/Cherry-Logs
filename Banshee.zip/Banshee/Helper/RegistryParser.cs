﻿using System;
using System.Collections.Generic;
using Microsoft.Win32;

namespace Banshee.Helper
{
	// Token: 0x020000C6 RID: 198
	public static class RegistryParser
	{
		// Token: 0x06000275 RID: 629 RVA: 0x00012998 File Offset: 0x00012998
		public static List<string> ParseKey(RegistryKey key)
		{
			List<string> list = new List<string>();
			if (key == null)
			{
				return list;
			}
			string[] valueNames = key.GetValueNames();
			int i = 0;
			while (i < valueNames.Length)
			{
				string text = valueNames[i];
				object value = key.GetValue(text);
				string str;
				switch (key.GetValueKind(text))
				{
				case RegistryValueKind.String:
				case RegistryValueKind.ExpandString:
					str = (((value != null) ? value.ToString() : null) ?? "null");
					break;
				case RegistryValueKind.Binary:
				{
					byte[] array = value as byte[];
					str = ((array == null) ? "null" : BitConverter.ToString(array).Replace("-", ""));
					break;
				}
				case RegistryValueKind.DWord:
				case RegistryValueKind.QWord:
					str = value.ToString();
					break;
				case (RegistryValueKind)5:
				case (RegistryValueKind)6:
				case (RegistryValueKind)8:
				case (RegistryValueKind)9:
				case (RegistryValueKind)10:
					goto IL_DE;
				case RegistryValueKind.MultiString:
				{
					string[] array2 = value as string[];
					str = ((array2 == null) ? "null" : string.Join(", ", array2));
					break;
				}
				default:
					goto IL_DE;
				}
				IL_F7:
				list.Add(text + ": " + str);
				i++;
				continue;
				IL_DE:
				str = (((value != null) ? value.ToString() : null) ?? "null");
				goto IL_F7;
			}
			return list;
		}
	}
}
