﻿using System;
using System.Collections;
using System.Net;
using System.Net.Sockets;
using System.Text.RegularExpressions;
using Newtonsoft.Json.Linq;

namespace Banshee.Helper
{
	// Token: 0x020000B4 RID: 180
	public static class IpApi
	{
		// Token: 0x0600022F RID: 559 RVA: 0x00011D24 File Offset: 0x00011D24
		public static string GetPublicIp()
		{
			if (!string.IsNullOrEmpty(IpApi._cachedIp))
			{
				return IpApi._cachedIp;
			}
			object @lock = IpApi._lock;
			string cachedIp;
			lock (@lock)
			{
				if (!string.IsNullOrEmpty(IpApi._cachedIp))
				{
					cachedIp = IpApi._cachedIp;
				}
				else
				{
					string[] ipv4Endpoints = IpApi.Ipv4Endpoints;
					for (int i = 0; i < ipv4Endpoints.Length; i++)
					{
						string cachedIp2;
						if (IpApi.TryFetchIpv4(ipv4Endpoints[i], out cachedIp2))
						{
							IpApi._cachedIp = cachedIp2;
							break;
						}
					}
					if (string.IsNullOrEmpty(IpApi._cachedIp))
					{
						IpApi._cachedIp = "0.0.0.0";
					}
					cachedIp = IpApi._cachedIp;
				}
			}
			return cachedIp;
		}

		// Token: 0x06000230 RID: 560 RVA: 0x00011DD0 File Offset: 0x00011DD0
		public static string GetCountryName()
		{
			if (!string.IsNullOrEmpty(IpApi._cachedCountry))
			{
				return IpApi._cachedCountry;
			}
			object countryLock = IpApi._countryLock;
			string cachedCountry;
			lock (countryLock)
			{
				if (!string.IsNullOrEmpty(IpApi._cachedCountry))
				{
					cachedCountry = IpApi._cachedCountry;
				}
				else
				{
					string[] countryEndpoints = IpApi.CountryEndpoints;
					for (int i = 0; i < countryEndpoints.Length; i++)
					{
						string cachedCountry2;
						if (IpApi.TryFetchCountry(countryEndpoints[i], out cachedCountry2))
						{
							IpApi._cachedCountry = cachedCountry2;
							break;
						}
					}
					if (string.IsNullOrEmpty(IpApi._cachedCountry))
					{
						IpApi._cachedCountry = "UnknownCountry";
					}
					cachedCountry = IpApi._cachedCountry;
				}
			}
			return cachedCountry;
		}

		// Token: 0x06000231 RID: 561 RVA: 0x00011E7C File Offset: 0x00011E7C
		private static bool TryFetchCountry(string endpoint, out string country)
		{
			country = null;
			try
			{
				using (WebClient webClient = new WebClient())
				{
					webClient.Headers[HttpRequestHeader.UserAgent] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64)";
					string text;
					if (IpApi.TryExtractCountry(webClient.DownloadString(endpoint), out text))
					{
						country = text;
						return true;
					}
				}
			}
			catch
			{
			}
			return false;
		}

		// Token: 0x06000232 RID: 562 RVA: 0x00011EEC File Offset: 0x00011EEC
		private static bool TryExtractCountry(string response, out string country)
		{
			country = null;
			if (string.IsNullOrWhiteSpace(response))
			{
				return false;
			}
			string text = response.Trim();
			if (text.StartsWith("{", StringComparison.Ordinal))
			{
				try
				{
					JObject jobject = JObject.Parse(text);
					foreach (string text2 in new string[]
					{
						"country_name",
						"country",
						"countryName",
						"country.name"
					})
					{
						JToken jtoken = jobject.SelectToken(text2);
						if (jtoken != null)
						{
							string text3 = Extensions.Value<string>(jtoken);
							if (IpApi.IsValidCountry(text3))
							{
								country = text3.Trim();
								return true;
							}
						}
					}
				}
				catch
				{
				}
				return false;
			}
			if (IpApi.IsValidCountry(text))
			{
				country = text;
				return true;
			}
			return false;
		}

		// Token: 0x06000233 RID: 563 RVA: 0x00011FB4 File Offset: 0x00011FB4
		private static bool IsValidCountry(string value)
		{
			return !string.IsNullOrWhiteSpace(value) && value.Trim().Length >= 2;
		}

		// Token: 0x06000234 RID: 564 RVA: 0x00011FD4 File Offset: 0x00011FD4
		private static bool TryFetchIpv4(string endpoint, out string ipv4)
		{
			ipv4 = null;
			try
			{
				using (WebClient webClient = new WebClient())
				{
					string text;
					if (IpApi.TryNormalizeIpv4(webClient.DownloadString(endpoint), out text))
					{
						ipv4 = text;
						return true;
					}
				}
			}
			catch
			{
			}
			return false;
		}

		// Token: 0x06000235 RID: 565 RVA: 0x00012034 File Offset: 0x00012034
		private static bool TryNormalizeIpv4(string value, out string ipv4)
		{
			ipv4 = null;
			if (string.IsNullOrWhiteSpace(value))
			{
				return false;
			}
			string text = value.Trim();
			if (IpApi.TryParseIpv4(text, out ipv4))
			{
				return true;
			}
			using (IEnumerator enumerator = Regex.Matches(text, "\\b(?:\\d{1,3}\\.){3}\\d{1,3}\\b").GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					if (IpApi.TryParseIpv4(((Match)enumerator.Current).Value, out ipv4))
					{
						return true;
					}
				}
			}
			return false;
		}

		// Token: 0x06000236 RID: 566 RVA: 0x000120C0 File Offset: 0x000120C0
		private static bool TryParseIpv4(string value, out string ipv4)
		{
			ipv4 = null;
			IPAddress ipaddress;
			if (IPAddress.TryParse(value, out ipaddress) && ipaddress.AddressFamily == AddressFamily.InterNetwork)
			{
				ipv4 = ipaddress.ToString();
				return true;
			}
			return false;
		}

		// Token: 0x0400019A RID: 410
		private static string _cachedIp;

		// Token: 0x0400019B RID: 411
		private static readonly object _lock = new object();

		// Token: 0x0400019C RID: 412
		private static string _cachedCountry;

		// Token: 0x0400019D RID: 413
		private static readonly object _countryLock = new object();

		// Token: 0x0400019E RID: 414
		private static readonly string[] CountryEndpoints = new string[]
		{
			"https://ipapi.co/json/",
			"https://ipwho.is/"
		};

		// Token: 0x0400019F RID: 415
		private static readonly string[] Ipv4Endpoints = new string[]
		{
			"http://ipv4.icanhazip.com",
			"https://api.ipify.org",
			"https://v4.ident.me"
		};
	}
}
